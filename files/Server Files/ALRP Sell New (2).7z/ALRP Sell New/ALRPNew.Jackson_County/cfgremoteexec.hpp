class CfgRemoteExec
{
	class Functions
	{
		mode = 0;
		jip = 0;
		class fnc_AdminReq { allowedTargets=2; };
		class EPOCH_server_save_vehicles { allowedTargets=2; };
	};
	class Commands
	{
		mode=0;
		jip=0;
	};
};