-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 192.99.16.127
-- Generation Time: Feb 24, 2017 at 06:22 AM
-- Server version: 5.7.12-log
-- PHP Version: 5.6.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `arma3lifetesting`
--

-- --------------------------------------------------------

--
-- Table structure for table `garage`
--

CREATE TABLE `garage` (
  `id` int(11) NOT NULL,
  `license` varchar(45) DEFAULT NULL,
  `class` varchar(45) DEFAULT NULL,
  `color` varchar(45) DEFAULT NULL,
  `finish` varchar(45) DEFAULT NULL,
  `rims` varchar(45) DEFAULT NULL,
  `windows` varchar(45) DEFAULT NULL,
  `lights` varchar(45) DEFAULT NULL,
  `owner` varchar(45) DEFAULT NULL,
  `statuses` varchar(45) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `spoiler` varchar(45) NOT NULL,
  `fuel` varchar(45) NOT NULL,
  `damage` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `general`
--

CREATE TABLE `general` (
  `id` int(11) NOT NULL,
  `key` varchar(255) DEFAULT NULL,
  `value` varchar(10000) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `general`
--

INSERT INTO `general` (`id`, `key`, `value`, `created_at`, `updated_at`) VALUES
(1, 'casinoRate', '5', '2017-02-12 06:32:41', '2017-02-23 16:44:07'),
(2, 'taxRate', '5', '2017-02-12 06:32:41', '2017-02-23 16:44:05'),
(3, 'mafiaStash', '[[[],[]],[[],[]],[[],[]],[[],[]]]', '2017-02-12 19:02:07', '2017-02-23 16:44:20'),
(4, 'bikerStash', '[[[],[]],[[],[]],[[],[]],[[],[]]]', '2017-02-12 19:02:07', '2017-02-23 16:44:30'),
(5, 'mobsterStash', '[[[],[]],[[],[]],[[],[]],[[],[]]]', '2017-02-12 19:02:07', '2017-02-23 16:44:26'),
(6, 'mafiaBank', '0', '2017-02-12 19:02:07', '2017-02-23 16:44:35'),
(7, 'bikerBank', '0', '2017-02-12 19:02:07', '2017-02-23 16:44:38'),
(8, 'mobsterBank', '0', '2017-02-12 19:02:07', '2017-02-23 16:44:42'),
(9, 'currentMayorGUID', '""', '2017-02-12 19:02:07', '2017-02-17 23:41:11'),
(10, 'currentSenatorsGUID', '[]', '2017-02-12 19:02:07', '2017-02-17 23:41:11'),
(11, 'govtBank', '0', '2017-02-12 19:25:30', '2017-02-24 03:00:05'),
(12, 'nightclubRate', '0', '2017-02-17 18:53:18', '2017-02-17 19:00:45'),
(13, 'adminList', '["76561198152842576","76561198018697623","76561198032284536","76561198035719394","76561198088089035","76561198092048500","76561198169421882","76561198076213611","76561197998457615","76561198123255527","76561198126196848","76561197964128158","76561197995364867","76561198047729399","76561197961308838"]', '2017-02-17 19:25:12', '2017-02-21 03:33:25');

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE `logs` (
  `id` int(11) NOT NULL,
  `type` varchar(45) DEFAULT NULL,
  `description` longtext,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `mail`
--

CREATE TABLE `mail` (
  `idmail` int(11) NOT NULL,
  `message` varchar(10000) DEFAULT NULL,
  `title` varchar(145) DEFAULT NULL,
  `sender` varchar(145) DEFAULT NULL,
  `receiver` varchar(45) DEFAULT NULL,
  `readmail` int(11) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `idmessages` int(11) NOT NULL,
  `message` varchar(10000) DEFAULT NULL,
  `title` varchar(145) DEFAULT NULL,
  `sender` varchar(145) DEFAULT NULL,
  `receiver` varchar(45) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `racetimes`
--

CREATE TABLE `racetimes` (
  `id` int(11) NOT NULL,
  `time` varchar(45) DEFAULT NULL,
  `name` varchar(245) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `rallyracetimes`
--

CREATE TABLE `rallyracetimes` (
  `id` int(11) NOT NULL,
  `time` varchar(45) DEFAULT NULL,
  `name` varchar(245) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `bankaccount` int(11) NOT NULL,
  `uid` varchar(50) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `cash` int(13) DEFAULT NULL,
  `bank` int(13) DEFAULT NULL,
  `cop` int(13) DEFAULT NULL,
  `ems` int(13) DEFAULT NULL,
  `mafia` varchar(45) DEFAULT NULL,
  `legal` varchar(45) DEFAULT NULL,
  `fire` varchar(45) DEFAULT NULL,
  `mobster` varchar(45) DEFAULT NULL,
  `biker` varchar(45) DEFAULT NULL,
  `dmv` varchar(45) DEFAULT NULL,
  `doc` varchar(45) DEFAULT NULL,
  `da` varchar(45) DEFAULT NULL,
  `position` varchar(50) DEFAULT NULL,
  `items` varchar(1500) DEFAULT NULL,
  `phoneBackground` varchar(55) DEFAULT NULL,
  `messages` varchar(2500) DEFAULT NULL,
  `statuses` varchar(2500) DEFAULT NULL,
  `houselevel` int(11) DEFAULT NULL,
  `housecontent` varchar(10000) DEFAULT NULL,
  `shopcontent` varchar(10000) DEFAULT NULL,
  `shopname` varchar(45) DEFAULT NULL,
  `prison` varchar(45) DEFAULT NULL,
  `prisonreason` varchar(45) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `wanted`
--

CREATE TABLE `wanted` (
  `caseID` int(10) NOT NULL,
  `suspect` varchar(45) DEFAULT NULL,
  `suspectGUID` varchar(45) DEFAULT NULL,
  `officer` varchar(45) DEFAULT NULL,
  `officerGUID` varchar(45) DEFAULT NULL,
  `approved` varchar(45) DEFAULT NULL,
  `approvedGUID` varchar(45) DEFAULT NULL,
  `charges` varchar(3000) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  `evidence` varchar(45) DEFAULT NULL,
  `active` varchar(45) DEFAULT NULL,
  `jailtime` varchar(45) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `garage`
--
ALTER TABLE `garage`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `vehicleID_UNIQUE` (`id`);

--
-- Indexes for table `general`
--
ALTER TABLE `general`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id_UNIQUE` (`id`);

--
-- Indexes for table `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id_UNIQUE` (`id`);

--
-- Indexes for table `mail`
--
ALTER TABLE `mail`
  ADD PRIMARY KEY (`idmail`),
  ADD UNIQUE KEY `idmail_UNIQUE` (`idmail`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`idmessages`),
  ADD UNIQUE KEY `idmessages_UNIQUE` (`idmessages`);

--
-- Indexes for table `racetimes`
--
ALTER TABLE `racetimes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id_UNIQUE` (`id`);

--
-- Indexes for table `rallyracetimes`
--
ALTER TABLE `rallyracetimes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id_UNIQUE` (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`bankaccount`),
  ADD UNIQUE KEY `uid` (`uid`);

--
-- Indexes for table `wanted`
--
ALTER TABLE `wanted`
  ADD PRIMARY KEY (`caseID`),
  ADD UNIQUE KEY `caseID_UNIQUE` (`caseID`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
