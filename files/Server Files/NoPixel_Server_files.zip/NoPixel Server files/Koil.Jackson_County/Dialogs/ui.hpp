
//yesno box lol


//

class client_loading
   	{
	idd=6969;
	movingEnable=0;
  	fadein=1;
	duration = 1;
  	fadeout=1;
	name="client_loading";
	onLoad = "uiNamespace setVariable ['np_loading', _this select 0];";
	objects[]={};
		
	class controls
	{
		class client_loading_base
		{
			type = 0;
			style = 2096;			
			idc=42349;
			fadein=1;
		  	fadeout=1;
			text = "\np_hudeffect\loading.paa";
			x = 0.271373 * safezoneW + safezoneX;
			y = 0.0996764 * safezoneH + safezoneY;
			w = 0.455142 * safezoneW;
			h = 0.791843 * safezoneH;
			sizeEx=0.01;
			size=0.01;
			font="PuristaLight";
			colorBackground[]={0,0,0,0};
			colorText[] = { 1 , 1 , 1 , 1 };
			shadow=0;
		};
	};
};



	
	class np_hudeffect {
		idd = -1;
		duration = 1;
		fadeIn = 0;
		fadeOut = 1;
		name = "";
		onLoad = "uiNamespace setVariable ['np_hudeffect', _this select 0];";
		
		class Controls {
			class hud_damaged {
				x = "(0.5 * safezoneW + safezoneX)-(0.25  * safezoneW)/2";
				y = "(0.5 * safezoneH + safezoneY)-(0.375  * safezoneH)/2";
				w = "0.25  * safezoneW";
				h = "0.375  * safezoneH";
				idc = 181818;
				text = "np_hudeffect\blood_bl.paa";
				sizeEx = 1;
				type = VSoft;
				style = 48;
				colorBackground[] = {0, 0, 0, 0};
				colorText[] = {1, 1, 1, 1};
				font = "EtelkaNarrowMediumPro";
			};
		};
	};



	class RSC_DOTASK
	{    
		idd = -1;
		fadein=1;
	  	fadeout=1;
		duration = 99999;
		name="RSC_DOTASK";
		onLoad="uiNamespace setVariable ['RSC_DOTASK',_this select 0]";
		objects[]={};
		class controls
		{
			class cg_popup_text_basic7
			{
				type=13;
				style=0x0c+0x02;
				idc=9119;
				x = 0.4 * safezoneW + safezoneX;
				y = 0.700 * safezoneH + safezoneY;
				w = 0.2;
				h = 0.15;
				sizeEx=0.035;
				size=0.035;
				font="PuristaMedium";
				colorBackground[]={0,0,0,0};
				colorText[] = { 1 , 1 , 1 , 1 };
				shadow=0;
				text="";
			};
		};	
	};



	class RSC_horsey1
	{    
		idd = -1;
		fadein=1;
	  	fadeout=1;
		duration = 9999;
		name="RSC_HORSEY1";
		onLoad="uiNamespace setVariable ['RSC_HORSEY1',_this select 0]";
		objects[]={};
		class controls
		{
			class classRSC_horsey1
			{
				type=13;
				style=0x0c+0x02;
				idc=69691;
				x = 0.2 * safezoneW + safezoneX;
				y = 0.800 * safezoneH + safezoneY;
				w = 0.25;
				h = 0.03;
				sizeEx=0.025;
				size=0.025;
				font="PuristaMedium";
				colorBackground[]={0.05,0.05,0.1,0.7};
				colorText[] = { 1 , 1 , 1 , 0.95 };
				shadow=0;
				text="";
			};
		};	
	};

	class RSC_horsey2
	{    
		idd = -1;
		fadein=1;
	  	fadeout=1;
		duration = 9999;
		name="RSC_HORSEY2";
		onLoad="uiNamespace setVariable ['RSC_HORSEY2',_this select 0]";
		objects[]={};
		class controls
		{
			class classRSC_horsey2
			{
				type=13;
				style=0x0c+0x02;
				idc=69692;
				x = 0.2 * safezoneW + safezoneX;
				y = 0.815 * safezoneH + safezoneY;
				w = 0.25;
				h = 0.03;
				sizeEx=0.025;
				size=0.025;
				font="PuristaMedium";
				colorBackground[]={0.05,0.05,0.1,0.4};
				colorText[] = { 1 , 1 , 1 , 0.95 };
				shadow=0;
				text="";
			};
		};	
	};


	class RSC_horsey3
	{    
		idd = -1;
		fadein=1;
	  	fadeout=1;
		duration = 9999;
		name="RSC_HORSEY3";
		onLoad="uiNamespace setVariable ['RSC_HORSEY3',_this select 0]";
		objects[]={};
		class controls
		{
			class classRSC_horsey3
			{
				type=13;
				style=0x0c+0x02;
				idc=69693;
				x = 0.2 * safezoneW + safezoneX;
				y = 0.830 * safezoneH + safezoneY;
				w = 0.25;
				h = 0.03;
				sizeEx=0.025;
				size=0.025;
				font="PuristaMedium";
				colorBackground[]={0.05,0.05,0.1,0.7};
				colorText[] = { 1 , 1 , 1 , 0.95 };
				shadow=0;
				text="";
			};
		};	
	};


	class RSC_horsey4
	{    
		idd = -1;
		fadein=1;
	  	fadeout=1;
		duration = 9999;
		name="RSC_HORSEY4";
		onLoad="uiNamespace setVariable ['RSC_HORSEY4',_this select 0]";
		objects[]={};
		class controls
		{
			class classRSC_horsey4
			{
				type=13;
				style=0x0c+0x02;
				idc=69694;
				x = 0.2 * safezoneW + safezoneX;
				y = 0.845 * safezoneH + safezoneY;
				w = 0.25;
				h = 0.03;
				sizeEx=0.025;
				size=0.025;
				font="PuristaMedium";
				colorBackground[]={0.05,0.05,0.1,0.4};
				colorText[] = { 1 , 1 , 1 , 0.95 };
				shadow=0;
				text="";
			};
		};	
	};

	class RSC_horsey5
	{    
		idd = -1;
		fadein=1;
	  	fadeout=1;
		duration = 9999;
		name="RSC_HORSEY5";
		onLoad="uiNamespace setVariable ['RSC_HORSEY5',_this select 0]";
		objects[]={};
		class controls
		{
			class classRSC_horsey5
			{
				type=13;
				style=0x0c+0x02;
				idc=69695;
				x = 0.2 * safezoneW + safezoneX;
				y = 0.860 * safezoneH + safezoneY;
				w = 0.25;
				h = 0.03;
				sizeEx=0.025;
				size=0.025;
				font="PuristaMedium";
				colorBackground[]={0.05,0.05,0.1,0.7};
				colorText[] = { 1 , 1 , 1 , 0.95 };
				shadow=0;
				text="";
			};
		};	
	};


	class RSC_horsey6
	{    
		idd = -1;
		fadein=1;
	  	fadeout=1;
		duration = 999;
		name="RSC_HORSEY6";
		onLoad="uiNamespace setVariable ['RSC_HORSEY6',_this select 0]";
		objects[]={};
		class controls
		{
			class classRSC_horsey6
			{
				type=13;
				style=0x0c+0x02;
				idc=69696;
				x = 0.2 * safezoneW + safezoneX;
				y = 0.875 * safezoneH + safezoneY;
				w = 0.25;
				h = 0.03;
				sizeEx=0.025;
				size=0.025;
				font="PuristaMedium";
				colorBackground[]={0.05,0.05,0.1,0.4};
				colorText[] = { 1 , 1 , 1 , 0.95 };
				shadow=0;
				text="";
			};
		};	
	};


	class RSC_horsey7
	{    
		idd = -1;
		fadein=1;
	  	fadeout=1;
		duration = 9999;
		name="RSC_HORSEY7";
		onLoad="uiNamespace setVariable ['RSC_HORSEY7',_this select 0]";
		objects[]={};
		class controls
		{
			class classRSC_horsey7
			{
				type=13;
				idc=69697;
				style=ST_MIDDLE;
				x = 0.2 * safezoneW + safezoneX;
				y = 0.890 * safezoneH + safezoneY;
				w = 0.25;	
				h = 0.03;
				sizeEx=0.025;
				size=0.025;
				font="PuristaMedium";
				colorBackground[]={0.05,0.05,0.1,0.7};
				colorText[] = { 1 , 1 , 1 , 0.95 };
				shadow=0;
				text="";
			};
		};	
	};


	class RSC_DOMSG7
	{    
		idd = -1;
		fadein=1;
	  	fadeout=1;
		duration = 4;
		name="RSC_DOMSG7";
		onLoad="uiNamespace setVariable ['RSC_DOMSG7',_this select 0]";
		objects[]={};
		class controls
		{
			class cg_popup_text_basic7
			{
				type=CT_STRUCTURED_TEXT;
				style=ST_LEFT;
				idc=13377;
				x = 0.01 * safezoneW + safezoneX;
				y = 0.200 * safezoneH + safezoneY;
				w = 0.55;
				h = 0.11;
				sizeEx=0.035;
				size=0.035;
				font="PuristaMedium";
				colorBackground[]={0.05,0.05,0.1,0.75};
				colorText[] = { 1 , 1 , 1 , 0 };
				shadow=0;
				text="";
				class Attributes {
					valign = "middle";
    				shadow = 1;
				};
			};
		};	
	};

	class RSC_DOMSG6
	{    
		idd = -1;
		fadein=1;
	  	fadeout=1;
		duration = 7;
		name="RSC_DOMSG6";
		onLoad="uiNamespace setVariable ['RSC_DOMSG6',_this select 0]";
		objects[]={};
		class controls
		{
			class cg_popup_text_basic6
			{
				type=CT_STRUCTURED_TEXT;
				style=ST_LEFT;
				idc=13376;
				x = 0.01 * safezoneW + safezoneX;
				y = 0.350 * safezoneH + safezoneY;
				w = 0.55;
				h = 0.11;
				sizeEx=0.035;
				size=0.035;
				font="PuristaMedium";
				colorBackground[]={0.05,0.05,0.1,0.75};
				colorText[] = { 1 , 1 , 1 , 0 };
				shadow=0;
				text="";
				class Attributes {
					valign = "middle";
    				shadow = 1;
				};
			};

		};	
	};

	class RSC_DOMSG5
	{    
		idd = -1;
		fadein=1;
	  	fadeout=1;
		duration = 7;
		name="RSC_DOMSG5";
		onLoad="uiNamespace setVariable ['RSC_DOMSG5',_this select 0]";
		objects[]={};
		class controls
		{
			class cg_popup_text_basic5
			{
				type=CT_STRUCTURED_TEXT;
				style=ST_LEFT;
				idc=13375;
				x = 0.01 * safezoneW + safezoneX;
				y = 0.420 * safezoneH + safezoneY;
				w = 0.55;
				h = 0.11;
				sizeEx=0.035;
				size=0.035;
				font="PuristaMedium";
				colorBackground[]={0.05,0.05,0.1,0.75};
				colorText[] = { 1 , 1 , 1 , 0 };
				shadow=0;
				text="";
				class Attributes {
					valign = "middle";
    				shadow = 1;
				};
			};

		};	
	};


	class RSC_DOMSG4
	{    
		idd = -1;
		fadein=1;
	  	fadeout=1;
		duration = 7;
		name="RSC_DOMSG4";
		onLoad="uiNamespace setVariable ['RSC_DOMSG4',_this select 0]";
		objects[]={};
		class controls
		{
			class cg_popup_text_basic4
			{
				type=CT_STRUCTURED_TEXT;
				style=ST_LEFT;
				idc=13374;
				x = 0.01 * safezoneW + safezoneX;
				y = 0.490 * safezoneH + safezoneY;
				w = 0.55;
				h = 0.11;
				sizeEx=0.035;
				size=0.035;
				font="PuristaMedium";
				colorBackground[]={0.05,0.05,0.1,0.75};
				colorText[] = { 1 , 1 , 1 , 0 };
				shadow=0;
				text="";
				class Attributes {
					valign = "middle";
    				shadow = 1;
				};
			};

		};	
	};

	class RSC_DOMSG3
	{    
		idd = -1;
		fadein=1;
	  	fadeout=1;
		duration = 7;
		name="RSC_DOMSG3";
		onLoad="uiNamespace setVariable ['RSC_DOMSG3',_this select 0]";
		objects[]={};
		class controls
		{

			class cg_popup_text_basic3
			{
				type=CT_STRUCTURED_TEXT;
				style=ST_LEFT;
				idc=13373;
				x = 0.01 * safezoneW + safezoneX;
				y = 0.560 * safezoneH + safezoneY;
				w = 0.55;
				h = 0.11;
				sizeEx=0.035;
				size=0.035;
				font="PuristaMedium";
				colorBackground[]={0.05,0.05,0.1,0.75};
				colorText[] = { 1 , 1 , 1 , 0 };
				shadow=0;
				text="";
				class Attributes {
					valign = "middle";
    				shadow = 1;
				};
			};

		};	
	};

	class RSC_DOMSG2
	{    
		idd = -1;
		fadein=1;
	  	fadeout=1;
		duration = 7;
		name="RSC_DOMSG2";
		onLoad="uiNamespace setVariable ['RSC_DOMSG2',_this select 0]";
		objects[]={};
		class controls
		{
			class cg_popup_text_basic2
			{
				type=CT_STRUCTURED_TEXT;
				style=ST_LEFT;
				idc=13372;
				x = 0.01 * safezoneW + safezoneX;
				y = 0.630 * safezoneH + safezoneY;
				w = 0.55;
				h = 0.11;
				sizeEx=0.035;
				size=0.035;
				font="PuristaMedium";
				colorBackground[]={0.05,0.05,0.1,0.75};
				colorText[] = { 1 , 1 , 1 , 0 };
				shadow=0;
				text="";
				class Attributes {
					valign = "middle";
    				shadow = 1;
				};
			};
		};	
	};

	class RSC_DOMSG1
	{    
		idd = -1;
		fadein=1;
	  	fadeout=1;
		duration = 7;
		name="RSC_DOMSG1";
		onLoad="uiNamespace setVariable ['RSC_DOMSG1',_this select 0]";
		objects[]={};
		class controls
		{
			class cg_popup_text_basic1
			{
				type=CT_STRUCTURED_TEXT;
				style=ST_LEFT;
				idc=13371;
				x = 0.01 * safezoneW + safezoneX;
				y = 0.700 * safezoneH + safezoneY;
				w = 0.55;
				h = 0.11;
				sizeEx=0.035;
				size=0.035;
				font="PuristaMedium";
				colorBackground[]={0.05,0.05,0.1,0.75};
				colorText[] = { 1 , 1 , 1 , 0 };
				shadow=0;
				text="";
				class Attributes {
					valign = "middle";
    				shadow = 1;
				};
			};
		};	
	};

class HUDhealth1
   	{
	idd=421;
	movingEnable=0;
  	fadein=1;
	duration = 1;
  	fadeout=1;
	name="HUDhealth1";
	onLoad="uiNamespace setVariable ['HUDhealth1',_this select 0]";
	objects[]={};
		
	class controls
	{
		class hud1
		{
			type = 0;
			style = 2096;			
			idc=42369;
			fadein=1;
		  	fadeout=1;
			x = 0.27 * safezoneW + safezoneX;
			y = 0.93 * safezoneH + safezoneY;
			w = 0.1;
			H = 0.1;
			sizeEx=0.01;
			size=0.01;
			font="PuristaLight";
			colorBackground[]={0,0,0,0};
			colorText[] = { 1 , 1 , 1 , 1 };
			shadow=0;
			text = "\np_dialogs1\icons\health1.paa";
		};
	};
};


class HUDhealth2
   	{
	idd=421;
	movingEnable=0;
  	fadein=1;
	duration = 1;
  	fadeout=1;
	name="HUDhealth2";
	onLoad="uiNamespace setVariable ['HUDhealth2',_this select 0]";
	objects[]={};
		
	class controls
	{
		class hud2
		{
			type = 0;
			style = 2096;			
			idc=42369;
			fadein=1;
		  	fadeout=1;
			x = 0.27 * safezoneW + safezoneX;
			y = 0.93 * safezoneH + safezoneY;
			w = 0.1;
			H = 0.1;
			sizeEx=0.01;
			size=0.01;
			font="PuristaLight";
			colorBackground[]={0,0,0,0};
			colorText[] = { 1 , 1 , 1 , 1 };
			shadow=0;
			text = "\np_dialogs1\icons\health2.paa";
		};
	};
};


class HUDhealth3
   	{
	idd=421;
	movingEnable=0;
  	fadein=1;
	duration = 1;
  	fadeout=1;
	name="HUDhealth3";
	onLoad="uiNamespace setVariable ['HUDhealth3',_this select 0]";
	objects[]={};
		
	class controls
	{
		class hud3
		{
			type = 0;
			style = 2096;			
			idc=42369;
			fadein=1;
		  	fadeout=1;
			x = 0.27 * safezoneW + safezoneX;
			y = 0.93 * safezoneH + safezoneY;
			w = 0.1;
			H = 0.1;
			sizeEx=0.01;
			size=0.01;
			font="PuristaLight";
			colorBackground[]={0,0,0,0};
			colorText[] = { 1 , 1 , 1 , 1 };
			shadow=0;
			text = "\np_dialogs1\icons\health3.paa";
		};
	};
};


class HUDFood
   	{
	idd=422;
	movingEnable=0;
  	fadein=1;
	duration = 999999999;
  	fadeout=1;
	name="HUDFood";
	onLoad="uiNamespace setVariable ['HUDFood',_this select 0]";
	objects[]={};
		
	class controls
	{
		class hud2
		{
			type = 0;
			style = 2096;			
			idc=42369;
			fadein=1;
		  	fadeout=1;
			x = 0.3 * safezoneW + safezoneX;
			y = 0.93 * safezoneH + safezoneY;
			w = 0.1;
			H = 0.1;
			sizeEx=0.01;
			size=0.01;
			font="PuristaLight";
			colorBackground[]={0,0,0,0};
			colorText[] = { 1 , 1 , 1 , 1 };
			shadow=0;
			text = "\np_dialogs1\icons\np_hunger.paa";
		};
	};
};


class HUDThirst
   	{
	idd=423;
	movingEnable=0;
  	fadein=1;
	duration = 999999999;
  	fadeout=1;
	name="HUDThirst";
	onLoad="uiNamespace setVariable ['HUDThirst',_this select 0]";
	objects[]={};
		
	class controls
	{
		class hud3
		{
			type = 0;
			style = 2096;			
			idc=42369;
			fadein=1;
		  	fadeout=1;
			x = 0.33 * safezoneW + safezoneX;
			y = 0.93 * safezoneH + safezoneY;
			w = 0.1;
			H = 0.1;
			sizeEx=0.01;
			size=0.01;
			font="PuristaLight";
			colorBackground[]={0,0,0,0};
			colorText[] = { 1 , 1 , 1 , 1 };
			shadow=0;
			text = "\np_dialogs1\icons\np_thirst.paa";
		};
	};
};


class HUDAddiction
   	{
	idd=424;
	movingEnable=0;
  	fadein=1;
	duration = 999999999;
  	fadeout=1;
	name="HUDAddiction";
	onLoad="uiNamespace setVariable ['HUDAddiction',_this select 0]";
	objects[]={};
		
	class controls
	{
		class hud4
		{
			type = 0;
			style = 2096;			
			idc=42469;
			fadein=1;
		  	fadeout=1;
			x = 0.36 * safezoneW + safezoneX;
			y = 0.93 * safezoneH + safezoneY;
			w = 0.1;
			H = 0.1;
			sizeEx=0.01;
			size=0.01;
			font="PuristaLight";
			colorBackground[]={0,0,0,0};
			colorText[] = { 1 , 1 , 1 , 1 };
			shadow=0;
			text = "\np_dialogs1\icons\np_healthiness.paa";
		};
	};
};

class HUDBattery
   	{
	idd=425;
	movingEnable=0;
  	fadein=1;
	duration = 999999999;
  	fadeout=1;
	name="HUDBattery";
	onLoad="uiNamespace setVariable ['HUDBattery',_this select 0]";
	objects[]={};
		
	class controls
	{
		class hud5
		{
			type = 0;
			style = 2096;			
			idc=42569;
			fadein=1;
		  	fadeout=1;
			x = 0.39 * safezoneW + safezoneX;
			y = 0.93 * safezoneH + safezoneY;
			w = 0.1;
			H = 0.1;
			sizeEx=0.01;
			size=0.01;
			font="PuristaLight";
			colorBackground[]={0,0,0,0};
			colorText[] = { 1 , 1 , 1 , 1 };
			shadow=0;
			text = "\np_dialogs1\icons\np_battery.paa";
		};
	};
};

class HUDWork
   	{
	idd=426;
	movingEnable=0;
	duration = 999999;
	name="HUDWork";
	onLoad="uiNamespace setVariable ['HUDWork',_this select 0]";
	objects[]={};
		
	class controls
	{
		class hud6
		{
			type = 0;
			style = 2096;			
			idc=42569;
			fadein=1;
		  	fadeout=1;
			x = 0.42 * safezoneW + safezoneX;
			y = 0.93 * safezoneH + safezoneY;
			w = 0.1;
			H = 0.1;
			sizeEx=0.01;
			size=0.01;
			font="PuristaLight";
			colorBackground[]={0,0,0,0};
			colorText[] = { 1 , 1 , 1 , 1 };
			shadow=0;
			text = "\np_dialogs1\icons\np_work.paa";
		};
	};
};



class HUDseat
   	{
	idd=427;
	movingEnable=0;
  	fadein=1;
	duration = 2;
  	fadeout=1;
	name="HUDseat";
	onLoad="uiNamespace setVariable ['HUDseat',_this select 0]";
	objects[]={};
		
	class controls
	{
		class hud6
		{
			type = 0;
			style = 2096;			
			idc=42569;
			fadein=1;
		  	fadeout=1;
			x = 0.5 * safezoneW + safezoneX;
			y = 0.5 * safezoneH + safezoneY;
			w = 0.1;
			H = 0.1;
			sizeEx=0.01;
			size=0.01;
			font="PuristaLight";
			colorBackground[]={0,0,0,0};
			colorText[] = { 1 , 1 , 1 , 1 };
			shadow=0;
			text = "\np_dialogs1\icons\np_seatbelt.paa";
		};
	};
};


class HUDbleed
   	{
	idd=999;
	movingEnable=0;
  	fadein=1;
	duration = 1;
  	fadeout=1;
	name="HUDbleed";
	onLoad="uiNamespace setVariable ['HUDbleed',_this select 0]";
	objects[]={};
		
	class controls
	{
		class hud6
		{
			type = 0;
			style = 2096;			
			idc=42569;
			fadein=1;
		  	fadeout=1;
			x = 0.6 * safezoneW + safezoneX;
			y = 0.6 * safezoneH + safezoneY;
			w = 0.1;
			H = 0.1;
			sizeEx=0.01;
			size=0.01;
			font="PuristaLight";
			colorBackground[]={0,0,0,0};
			colorText[] = { 1 , 1 , 1 , 1 };
			shadow=0;
			text = "bleed.paa";
		};
	};
};



class HUDgun
   	{
	idd=428;
	movingEnable=0;
  	fadein=0;
	duration = 4;
  	fadeout=1;
	name="HUDgun";
	onLoad="uiNamespace setVariable ['HUDgun',_this select 0]";
	objects[]={};
		
	class controls
	{
		class hud6
		{
			type = 0;
			style = 2096;			
			idc=42569;
			fadein=1;
		  	fadeout=1;
			x = 0.5 * safezoneW + safezoneX;
			y = 0.7 * safezoneH + safezoneY;
			w = 0.1;
			H = 0.1;
			sizeEx=0.01;
			size=0.01;
			font="PuristaLight";
			colorBackground[]={0,0,0,0};
			colorText[] = { 1 , 1 , 1 , 1 };
			shadow=0;
			text = "\np_dialogs1\icons\np_gun.paa";
		};
	};
};



class HUDguncop
   	{
	idd=444;
	movingEnable=0;
  	fadein=1;
	duration = 2;
  	fadeout=1;
	name="HUDguncop";
	onLoad="uiNamespace setVariable ['HUDguncop',_this select 0]";
	objects[]={};
		
	class controls
	{
		class hud6
		{
			type = 0;
			style = 2096;			
			idc=42569;
			fadein=1;
		  	fadeout=1;
			x = 0.3 * safezoneW + safezoneX;
			y = 0.7 * safezoneH + safezoneY;
			w = 0.2;
			H = 0.2;
			sizeEx=0.01;
			size=0.01;
			font="PuristaLight";
			colorBackground[]={0,0,0,0};
			colorText[] = { 1 , 1 , 1 , 1 };
			shadow=0;
			text = "\cg_jobs\icons\usepistol.paa";
		};
	};
};

class HUDtasercop
   	{
	idd=445;
	movingEnable=0;
  	fadein=1;
	duration = 2;
  	fadeout=1;
	name="HUDtasercop";
	onLoad="uiNamespace setVariable ['HUDtasercop',_this select 0]";
	objects[]={};
		
	class controls
	{
		class hud6
		{
			type = 0;
			style = 2096;			
			idc=42569;
			fadein=1;
		  	fadeout=1;
			x = 0.3 * safezoneW + safezoneX;
			y = 0.7 * safezoneH + safezoneY;
			w = 0.2;
			H = 0.2;
			sizeEx=0.01;
			size=0.01;
			font="PuristaLight";
			colorBackground[]={0,0,0,0};
			colorText[] = { 1 , 1 , 1 , 1 };
			shadow=0;
			text = "\cg_jobs\icons\usetaser.paa";
		};
	};
};


class HUDmarijuana
   	{
	idd=429;
	movingEnable=0;
  	fadein=0;
	duration = 300;
  	fadeout=1;
	name="HUDgun";
	onLoad="uiNamespace setVariable ['HUDmarijuana',_this select 0]";
	objects[]={};
		
	class controls
	{
		class hud6
		{
			type = 0;
			style = 2096;			
			idc=42569;
			fadein=1;
		  	fadeout=1;
			x = 0.1 * safezoneW + safezoneX;
			y = 0.1 * safezoneH + safezoneY;
			w = 0.1;
			H = 0.1;
			sizeEx=0.01;
			size=0.01;
			font="PuristaLight";
			colorBackground[]={0,0,0,0};
			colorText[] = { 1 , 1 , 1 , 1 };
			shadow=0;
			text = "\np_dialogs1\icons\np_marijuana.paa";
		};
	};
};


class HUDcocaine
   	{
	idd=430;
	movingEnable=0;
  	fadein=0;
	duration = 300;
  	fadeout=1;
	name="HUDcocaine";
	onLoad="uiNamespace setVariable ['HUDcocaine',_this select 0]";
	objects[]={};
		
	class controls
	{
		class hud6
		{
			type = 0;
			style = 2096;			
			idc=42569;
			fadein=1;
		  	fadeout=1;
			x = 0.13 * safezoneW + safezoneX;
			y = 0.1 * safezoneH + safezoneY;
			w = 0.1;
			H = 0.1;
			sizeEx=0.01;
			size=0.01;
			font="PuristaLight";
			colorBackground[]={0,0,0,0};
			colorText[] = { 1 , 1 , 1 , 1 };
			shadow=0;
			text = "\np_dialogs1\icons\np_cocaine.paa";
		};
	};
};

class HUDmeth
   	{
	idd=431;
	movingEnable=0;
  	fadein=0;
	duration = 300;
  	fadeout=1;
	name="HUDmeth";
	onLoad="uiNamespace setVariable ['HUDmeth',_this select 0]";
	objects[]={};
		
	class controls
	{
		class hud6
		{
			type = 0;
			style = 2096;			
			idc=42569;
			fadein=1;
		  	fadeout=1;
			x = 0.16 * safezoneW + safezoneX;
			y = 0.1 * safezoneH + safezoneY;
			w = 0.1;
			H = 0.1;
			sizeEx=0.01;
			size=0.01;
			font="PuristaLight";
			colorBackground[]={0,0,0,0};
			colorText[] = { 1 , 1 , 1 , 1 };
			shadow=0;
			text = "\np_dialogs1\icons\np_meth.paa";
		};
	};
};



class HUDheroin
   	{
	idd=432;
	movingEnable=0;
  	fadein=0;
	duration = 300;
  	fadeout=1;
	name="HUDheroin";
	onLoad="uiNamespace setVariable ['HUDheroin',_this select 0]";
	objects[]={};
		
	class controls
	{
		class hud6
		{
			type = 0;
			style = 2096;			
			idc=42569;
			fadein=1;
		  	fadeout=1;
			x = 0.19 * safezoneW + safezoneX;
			y = 0.1 * safezoneH + safezoneY;
			w = 0.1;
			H = 0.1;
			sizeEx=0.01;
			size=0.01;
			font="PuristaLight";
			colorBackground[]={0,0,0,0};
			colorText[] = { 1 , 1 , 1 , 1 };
			shadow=0;
			text = "\np_dialogs1\icons\np_heroin.paa";
		};
	};
};

class HUDenergy
   	{
	idd=433;
	movingEnable=0;
  	fadein=0;
	duration = 300;
  	fadeout=1;
	name="HUDenergy";
	onLoad="uiNamespace setVariable ['HUDenergy',_this select 0]";
	objects[]={};
		
	class controls
	{
		class hud6
		{
			type = 0;
			style = 2096;			
			idc=42569;
			fadein=1;
		  	fadeout=1;
			x = 0.22 * safezoneW + safezoneX;
			y = 0.1 * safezoneH + safezoneY;
			w = 0.1;
			H = 0.1;
			sizeEx=0.01;
			size=0.01;
			font="PuristaLight";
			colorBackground[]={0,0,0,0};
			colorText[] = { 1 , 1 , 1 , 1 };
			shadow=0;
			text = "\np_dialogs1\icons\np_energy.paa";
		};
	};
};


	class playerHUD
   	{
		idd=80085;
		movingEnable=0;
	  	fadein=1;
		duration = 999999;
	  	fadeout=1;
		name="playerHUD";
		onLoad="uiNamespace setVariable ['playerHUD',_this select 0]";
		objects[]={};
		
		
		class controls
		{

			class bleedingtext
			{
				type=CT_STRUCTURED_TEXT;
				idc=23570;
				style=ST_LEFT;
				x = 0.834 * safezoneW + safezoneX;
				y = 0.463 * safezoneH + safezoneY;
				w = 0.8; 
				h = 1;
				sizeEx=0.03;
				size=1;
				font="PuristaLight";
				colorBackground[]={0,0,0,0};
				colorText[] = { 1 , 1 , 1 , 1 };
				shadow=1;
				text="";
			};

			class woundedtext
			{
				type=CT_STRUCTURED_TEXT;
				idc=23575;
				style=ST_LEFT;
				x = 0.834 * safezoneW + safezoneX;
				y = 0.503 * safezoneH + safezoneY;
				w = 0.8; 
				h = 1;
				sizeEx=0.03;
				size=1;
				font="PuristaLight";
				colorBackground[]={0,0,0,0};
				colorText[] = { 1 , 1 , 1 , 1 };
				shadow=1;
				text="";
			};	
			class fracturetext
			{
				type=CT_STRUCTURED_TEXT;
				idc=23580;
				style=ST_LEFT;
				x = 0.834 * safezoneW + safezoneX;
				y = 0.543 * safezoneH + safezoneY;
				w = 0.8; 
				h = 1;
				sizeEx=0.03;
				size=1;
				font="PuristaLight";
				colorBackground[]={0,0,0,0};
				colorText[] = { 1 , 1 , 1 , 1 };
				shadow=1;
				text="";
			};	

			class unconcioustext
			{
				type=CT_STRUCTURED_TEXT;
				idc=23585;
				style=ST_LEFT;
				x = 0.834 * safezoneW + safezoneX;
				y = 0.583 * safezoneH + safezoneY;
				w = 0.8; 
				h = 1;
				sizeEx=0.03;
				size=1;
				font="PuristaLight";
				colorBackground[]={0,0,0,0};
				colorText[] = { 1 , 1 , 1 , 1 };
				shadow=1;
				text="";
			};	


			class diseasetext
			{
				type=CT_STRUCTURED_TEXT;
				idc=23590;
				style=ST_LEFT;
				x = 0.834 * safezoneW + safezoneX;
				y = 0.623 * safezoneH + safezoneY;
				w = 0.8; 
				h = 1;
				sizeEx=0.03;
				size=1;
				font="PuristaLight";
				colorBackground[]={0,0,0,0};
				colorText[] = { 1 , 1 , 1 , 1 };
				shadow=1;
				text="";
			};

			class severeinjurytext
			{
				type=CT_STRUCTURED_TEXT;
				idc=23595;
				style=ST_LEFT;
				x = 0.834 * safezoneW + safezoneX;
				y = 0.663 * safezoneH + safezoneY;
				w = 0.8; 
				h = 1;
				sizeEx=0.03;
				size=1;
				font="PuristaLight";
				colorBackground[]={0,0,0,0};
				colorText[] = { 1 , 1 , 1 , 1 };
				shadow=1;
				text="";
			};	
		};   
 	};

 	#define BaseIconID 78001

class client_HUD_nameTags {
	idd = -1;
	duration = 999999;
	fadein=0;
	fadeout=0;
	name = "client_HUD_nameTags";
	onLoad = "uiNamespace setVariable['client_HUD_nameTags',_this select 0]";
	objects[] = {};
	
	class controls
	{
		class BaseIcon
		{
			idc = 78000;
			type = 13;
			style = 0;
			colorText[] = {0,0,0,1};
			colorBackground[] = {0,0,0,0};
			font = "PuristaMedium";
			text = "";
			size = 0.07;
			shadow = 2;
			w = 0; h = 0;
			x = 0.1; y = 0.1;
		};
		
		class p1 : BaseIcon {idc = BaseIconID;};
		class p2 : BaseIcon {idc = BaseIconID + 1;};
		class p3 : BaseIcon {idc = BaseIconID + 2;};
		class p4 : BaseIcon {idc = BaseIconID + 3;};
		class p5 : BaseIcon {idc = BaseIconID + 4;};
		class p6 : BaseIcon {idc = BaseIconID + 5;};
		class p7 : BaseIcon {idc = BaseIconID + 6;};
		class p8 : BaseIcon {idc = BaseIconID + 7;};
		class p9 : BaseIcon {idc = BaseIconID + 8;};
		class p10 : BaseIcon {idc = BaseIconID + 9;};
		class p11 : BaseIcon {idc = BaseIconID + 10;};
		class p12 : BaseIcon {idc = BaseIconID + 11;};
		class p13 : BaseIcon {idc = BaseIconID + 12;};
		class p14 : BaseIcon {idc = BaseIconID + 13;};
		class p15 : BaseIcon {idc = BaseIconID + 14;};
		class p16 : BaseIcon {idc = BaseIconID + 15;};
		class p17 : BaseIcon {idc = BaseIconID + 16;};
		class p18 : BaseIcon {idc = BaseIconID + 17;};
		class p19 : BaseIcon {idc = BaseIconID + 18;};
		class p20 : BaseIcon {idc = BaseIconID + 19;};
		class p21 : BaseIcon {idc = BaseIconID + 20;};
		class p22 : BaseIcon {idc = BaseIconID + 21;};
		class p23 : BaseIcon {idc = BaseIconID + 22;};
		class p24 : BaseIcon {idc = BaseIconID + 23;};
		class p25 : BaseIcon {idc = BaseIconID + 24;};
		class p26 : BaseIcon {idc = BaseIconID + 25;};
		class p27 : BaseIcon {idc = BaseIconID + 26;};
		class p28 : BaseIcon {idc = BaseIconID + 27;};
		class p29 : BaseIcon {idc = BaseIconID + 28;};
		class p30 : BaseIcon {idc = BaseIconID + 29;};
		class p31 : BaseIcon {idc = BaseIconID + 30;};
		class p32 : BaseIcon {idc = BaseIconID + 31;};
		class p33 : BaseIcon {idc = BaseIconID + 32;};
		class p34 : BaseIcon {idc = BaseIconID + 33;};
		class p35 : BaseIcon {idc = BaseIconID + 34;};
		class p36 : BaseIcon {idc = BaseIconID + 35;};
		class p37 : BaseIcon {idc = BaseIconID + 36;};
		class p38 : BaseIcon {idc = BaseIconID + 37;};
		class p39 : BaseIcon {idc = BaseIconID + 38;};
		class p40 : BaseIcon {idc = BaseIconID + 39;};
		class p41 : BaseIcon {idc = BaseIconID + 40;};
		class p42 : BaseIcon {idc = BaseIconID + 41;};
		class p43 : BaseIcon {idc = BaseIconID + 42;};
		class p44 : BaseIcon {idc = BaseIconID + 43;};
		class p45 : BaseIcon {idc = BaseIconID + 44;};
		class p46 : BaseIcon {idc = BaseIconID + 45;};
		class p47 : BaseIcon {idc = BaseIconID + 46;};
		class p48 : BaseIcon {idc = BaseIconID + 47;};
		class p49 : BaseIcon {idc = BaseIconID + 48;};
		class p50 : BaseIcon {idc = BaseIconID + 49;};
		class p51 : BaseIcon {idc = BaseIconID + 50;};
		class p52 : BaseIcon {idc = BaseIconID + 51;};
		class p53 : BaseIcon {idc = BaseIconID + 52;};
		class p54 : BaseIcon {idc = BaseIconID + 53;};
		class p55 : BaseIcon {idc = BaseIconID + 54;};
		class p56 : BaseIcon {idc = BaseIconID + 55;};
		class p57 : BaseIcon {idc = BaseIconID + 56;};
		class p58 : BaseIcon {idc = BaseIconID + 57;};
		class p59 : BaseIcon {idc = BaseIconID + 58;};
		class p60 : BaseIcon {idc = BaseIconID + 59;};
		class p61 : BaseIcon {idc = BaseIconID + 60;};
		class p62 : BaseIcon {idc = BaseIconID + 61;};
		class p63 : BaseIcon {idc = BaseIconID + 62;};
		class p64 : BaseIcon {idc = BaseIconID + 63;};
		class p65 : BaseIcon {idc = BaseIconID + 64;};
		class p66 : BaseIcon {idc = BaseIconID + 65;};
		class p67 : BaseIcon {idc = BaseIconID + 66;};
		class p68 : BaseIcon {idc = BaseIconID + 67;};
		class p69 : BaseIcon {idc = BaseIconID + 68;};
		class p70 : BaseIcon {idc = BaseIconID + 69;};
		class p71 : BaseIcon {idc = BaseIconID + 70;};
		class p72 : BaseIcon {idc = BaseIconID + 71;};
		class p73 : BaseIcon {idc = BaseIconID + 72;};
		class p74 : BaseIcon {idc = BaseIconID + 73;};
		class p75 : BaseIcon {idc = BaseIconID + 74;};
		class p76 : BaseIcon {idc = BaseIconID + 75;};
		class p77 : BaseIcon {idc = BaseIconID + 76;};
		class p78 : BaseIcon {idc = BaseIconID + 77;};
		class p79 : BaseIcon {idc = BaseIconID + 78;};
		class p80 : BaseIcon {idc = BaseIconID + 79;};
		class p81 : BaseIcon {idc = BaseIconID + 80;};
		class p82 : BaseIcon {idc = BaseIconID + 81;};
		class p83 : BaseIcon {idc = BaseIconID + 82;};
		class p84 : BaseIcon {idc = BaseIconID + 83;};
		class p85 : BaseIcon {idc = BaseIconID + 84;};
		class p86 : BaseIcon {idc = BaseIconID + 85;};
		class p87 : BaseIcon {idc = BaseIconID + 86;};
		class p88 : BaseIcon {idc = BaseIconID + 87;};
		class p89 : BaseIcon {idc = BaseIconID + 88;};
		class p90 : BaseIcon {idc = BaseIconID + 89;};
		class p91 : BaseIcon {idc = BaseIconID + 90;};
		class p92 : BaseIcon {idc = BaseIconID + 91;};
		class p93 : BaseIcon {idc = BaseIconID + 92;};
		class p94 : BaseIcon {idc = BaseIconID + 93;};
		class p95 : BaseIcon {idc = BaseIconID + 94;};
		class p96 : BaseIcon {idc = BaseIconID + 95;};
		class p97 : BaseIcon {idc = BaseIconID + 96;};
		class p98 : BaseIcon {idc = BaseIconID + 97;};
		class p99 : BaseIcon {idc = BaseIconID + 98;};
		class p100 : BaseIcon {idc = BaseIconID + 99;};
		class p101 : BaseIcon {idc = BaseIconID + 100;};
		class p102 : BaseIcon {idc = BaseIconID + 101;};
		class p103 : BaseIcon {idc = BaseIconID + 102;};
		class p104 : BaseIcon {idc = BaseIconID + 103;};
		class p105 : BaseIcon {idc = BaseIconID + 104;};
		class p106 : BaseIcon {idc = BaseIconID + 105;};
		class p107 : BaseIcon {idc = BaseIconID + 106;};
		class p108 : BaseIcon {idc = BaseIconID + 107;};
		class p109 : BaseIcon {idc = BaseIconID + 108;};
		class p110 : BaseIcon {idc = BaseIconID + 109;};
	};
};