class CarBought {
    expToAdd = 15;
	message = "You gained 15 EXP for purchasing that!";
};
class carBoughtmedium {
    expToAdd = 45;
	message = "You gained 45 EXP for purchasing that!";
};
class carBoughtexpensive {
    expToAdd = 120;
	message = "You gained 120 EXP for purchasing that!";
};
class delivery {
    expToAdd = 40;
	message = "You gained 40 EXP for delivering that!";
};
class robShop {
    expToAdd = 60;
	message = "You gained 60 EXP for doing that!";
};
class sellbag {
    expToAdd = 135;
	message = "You gained 135 EXP for selling that!";
};
class sendtojail {
    expToAdd = 75;
	message = "You gained 75 EXP for doing that!";
};
class pettycash {
    expToAdd = 125;
	message = "You gained 125 EXP for doing that!";
};
class mining {
    expToAdd = 6;
	message = "You gained 6 EXP for doing that!";
};
class miningextra {
    expToAdd = 8;
	message = "You gained 8 EXP for doing that!";
};
class miningbig {
    expToAdd = 12;
	message = "You gained 12 EXP for doing that!";
};
class miningmore {
    expToAdd = 8;
	message = "You gained 8 EXP for doing that!";
};
class miningextramore {
    expToAdd = 13;
	message = "You gained 13 EXP for doing that!";
};
class miningbigmore {
    expToAdd = 16;
	message = "You gained 16 EXP for doing that!";
};
class processdouble {
    expToAdd = 32;
	message = "You gained 32 EXP for doing that!";
};
class processtriple {
    expToAdd = 48;
	message = "You gained 48 EXP for doing that!";
};
class evidence {
    expToAdd = 10;
	message = "You gained 7 EXP for doing that!";
};
class playing {
    expToAdd = 10;
	message = "You gained 10 EXP!";
};
class playingdouble {
    expToAdd = 30;
	message = "You gained 30 EXP!";
};
class impound {
    expToAdd = 20;
	message = "You gained 20 EXP for impounding that vehicle!";
};
class treating {
    expToAdd = 12;
	message = "You gained 12 EXP for doing that!";
};
