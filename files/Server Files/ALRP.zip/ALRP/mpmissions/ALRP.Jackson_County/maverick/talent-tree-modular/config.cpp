// -- GUI
#include "gui\_master.cpp"

class Maverick_TTM {
	class Actions {
		#include "configuration\actions.hpp"
	};

	class Levels {
		#include "configuration\levels.hpp"
	};

	class Perks {
		#include "configuration\perks.hpp"
	};
};
