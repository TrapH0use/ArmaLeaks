class Maverick_GUI {
	tag = "MAV_gui";
	class functions {
		file = "maverick\gui\functions";
		class openGUI {};
		class initLayer {};
		class destroyLayer {};
		class createLayer {};
	};
};