class mav_ServerRestartEvent_fnc_ServerRestartEvent {
    allowedTargets = 0;
};