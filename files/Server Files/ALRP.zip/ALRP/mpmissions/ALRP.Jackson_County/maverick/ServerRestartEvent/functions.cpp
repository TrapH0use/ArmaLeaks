/*
	Author: Maverick Applications
	Desc: Altis Life ServerRestartEvent
*/

//Do not touch below
class Maverick_ServerRestartEvent {

	tag = "mav_ServerRestartEvent";

	class functions {
		file = "Maverick\ServerRestartEvent\scripts";
        class loadServerRestartEvent {postInit = 1; headerType = -1;};
        class ServerRestartEvent {headerType = -1;};
	};
};