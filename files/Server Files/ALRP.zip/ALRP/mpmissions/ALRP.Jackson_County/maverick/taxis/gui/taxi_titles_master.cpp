/*--------------------------------------------------------------------------
    Author:		Maverick Applications
    Website:	https://maverick-applications.com

    You're not allowed to use this file without permission from the author!
---------------------------------------------------------------------------*/

#include "gui_includes.h"
#include "RscTitleTaxiMeter.cpp"
#include "RscTitleTaxiLargeNotification.cpp"
#include "RscTitleTaxiFareSummary.cpp"