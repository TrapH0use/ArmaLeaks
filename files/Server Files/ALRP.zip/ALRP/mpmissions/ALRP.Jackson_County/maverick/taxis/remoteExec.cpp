class mav_taxi_fnc_serverFareFinished {
    allowedTargets = 2;
};

class mav_taxi_fnc_setDrivenDistance {
    allowedTargets = 1;
};

class mav_taxi_fnc_driverCallerPaid {
    allowedTargets = 1;
};

class mav_taxi_fnc_serverUpdateDestination {
    allowedTargets = 2;
};

class mav_taxi_fnc_serverQueueRequest {
    allowedTargets = 2;
};

class mav_taxi_fnc_serverDequeueRequest {
    allowedTargets = 2;
};

class mav_taxi_fnc_fareCancelled {
    allowedTargets = 1;
};

class mav_taxi_fnc_serverCallAccepted {
    allowedTargets = 2;
};