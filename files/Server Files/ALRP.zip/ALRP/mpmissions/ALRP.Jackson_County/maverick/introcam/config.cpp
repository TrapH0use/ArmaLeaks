/*
	Author: Maverick Applications
	Altis Life Intro Cam
*/

// Map configuration
class Maverick_IntroCam_Jackson_County {
	class Info {
		secondsPerCam 	= 40;
		selectRandom 	= 0;
		music			= 1;
		musicVolume		= 0.8;
		musicName		= "LeadTrack01b_F_EXP";
	};
	class Positions {
		data[] = {
			// Start pos, start target pos, end pos, end target pos, focus
			{{6488.51,4376.49,11.3016}, 	{6543.57,4297.85,1.0965}, 	{6537.99,4306.4,23.5249}, 	{6552.52,4230.71,0}, 5},		// Bridge
			{{5085.68,2937.79,0.351269}, 	{5795.98,2405.5,0}, 		{5237.33,2823.12,35.0571}, 	{5297.63,2918.43,0}, 5}			// Morrison
		};
	};
};
