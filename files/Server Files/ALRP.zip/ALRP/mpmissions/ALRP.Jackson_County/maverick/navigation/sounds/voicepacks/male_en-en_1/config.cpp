/*--------------------------------------------------------------------------
    Author:		Maverick Applications
    Website:	https://maverick-applications.com

    You're not allowed to use this file without permission from the author!
---------------------------------------------------------------------------*/

class male_enen_1 {
	
	displayName = "Torados (English)";

	// Turns
	sound100mLeft			= "gpsvoice_male3_sound100mLeft";
	soundNowLeft			= "gpsvoice_male3_soundNowLeft";
	sound100mRight			= "gpsvoice_male3_sound100mRight";
	soundNowRight			= "gpsvoice_male3_soundNowRight";

	// Destination
	soundOnDestinationRoad	= "gpsvoice_male3_soundOnDestinationRoad";
	soundDestinationReached	= "gpsvoice_male3_soundDestinationReached";

	// General instructions
	soundFollowRoad			= "gpsvoice_male3_soundFollowRoad";
};