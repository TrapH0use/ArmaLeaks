class an_alerts {
	idd = 15;
	movingEnable = 0;
	controls[]=
	{
		an_alert_text
	};

	class an_alert_text: RscStructuredText
	{
		idc = 1100;
		x = -0.7;
		y = -0.14;
		w = 0.4375;
		h = 0.68;
		colorBackground[] = {0,0,0,0};
	};
};
