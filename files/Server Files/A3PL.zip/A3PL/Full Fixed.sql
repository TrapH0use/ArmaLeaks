-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.3.8-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             9.4.0.5125
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Dumping database structure for life
CREATE DATABASE IF NOT EXISTS `life` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `life`;

-- Dumping structure for table life.adminlogs
CREATE TABLE IF NOT EXISTS `adminlogs` (
  `ID` int(255) NOT NULL AUTO_INCREMENT,
  `adminname` varchar(50) NOT NULL,
  `uid` varchar(50) NOT NULL,
  `type` enum('cursortarget','mapmarkers','spectate','factories','globalmessage','mapteleporting','players','objects','vehicles','debug','menu') NOT NULL,
  `data` text NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=22701 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- Data exporting was unselected.
-- Dumping structure for table life.chatlog
CREATE TABLE IF NOT EXISTS `chatlog` (
  `name` tinytext DEFAULT NULL,
  `steamid` tinytext DEFAULT NULL,
  `chatmessage` tinytext DEFAULT NULL,
  `messageinfo` varchar(500) DEFAULT '[``,`#ed7202`,`#B5B5B5`]',
  `date` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- Data exporting was unselected.
-- Dumping structure for table life.factions
CREATE TABLE IF NOT EXISTS `factions` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `leader` varchar(17) NOT NULL,
  `type` varchar(50) NOT NULL,
  `max_rank` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

-- Data exporting was unselected.
-- Dumping structure for table life.faction_ranks
CREATE TABLE IF NOT EXISTS `faction_ranks` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `fid` int(6) NOT NULL,
  `name` varchar(50) NOT NULL,
  `level` int(11) NOT NULL DEFAULT 1,
  `paycheck` int(100) NOT NULL DEFAULT 1000,
  `cap` int(100) NOT NULL DEFAULT 1000,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4;

-- Data exporting was unselected.
-- Dumping structure for table life.faction_vehicle_shop
CREATE TABLE IF NOT EXISTS `faction_vehicle_shop` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `var` varchar(50) NOT NULL,
  `type` enum('fifr','police','uscg','uscg_h','uscg_b','dmv','faa','doj') NOT NULL,
  `stock` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

-- Data exporting was unselected.
-- Dumping structure for table life.government_balances
CREATE TABLE IF NOT EXISTS `government_balances` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `var` varchar(50) DEFAULT NULL,
  `balance` bigint(20) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1 COMMENT='Contains balances for government fund and the current tax rates';

-- Data exporting was unselected.
-- Dumping structure for table life.government_laws
CREATE TABLE IF NOT EXISTS `government_laws` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `law` text NOT NULL,
  `added` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

-- Data exporting was unselected.
-- Dumping structure for table life.houses
CREATE TABLE IF NOT EXISTS `houses` (
  `uid` varchar(50) DEFAULT NULL,
  `location` varchar(50) DEFAULT NULL,
  `doorid` varchar(50) DEFAULT NULL,
  `items` varchar(7000) DEFAULT '[[],[],[]]',
  `vitems` varchar(7000) DEFAULT '[]',
  `pitems` varchar(7000) DEFAULT '[]',
  UNIQUE KEY `location` (`location`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- Data exporting was unselected.
-- Dumping structure for table life.import_export
CREATE TABLE IF NOT EXISTS `import_export` (
  `item` varchar(50) DEFAULT NULL,
  `import` int(25) DEFAULT NULL,
  `export` int(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- Data exporting was unselected.
-- Dumping structure for table life.logs
CREATE TABLE IF NOT EXISTS `logs` (
  `ID` int(255) NOT NULL AUTO_INCREMENT,
  `uid` varchar(50) NOT NULL,
  `type` varchar(50) NOT NULL,
  `data` text NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=35809 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- Data exporting was unselected.
-- Dumping structure for table life.objects
CREATE TABLE IF NOT EXISTS `objects` (
  `aiid` int(11) NOT NULL AUTO_INCREMENT,
  `id` varchar(50) NOT NULL,
  `type` varchar(50) NOT NULL DEFAULT 'object',
  `class` varchar(50) NOT NULL,
  `uid` varchar(50) NOT NULL,
  `plystorage` tinyint(1) NOT NULL DEFAULT 0,
  `spawn` tinyint(1) NOT NULL DEFAULT 0,
  `pos` varchar(50) NOT NULL DEFAULT '[]',
  `vars` varchar(50) NOT NULL DEFAULT '[]',
  `impounded` tinyint(1) NOT NULL DEFAULT 0,
  `fuel` float NOT NULL DEFAULT 1,
  `color` varchar(300) NOT NULL DEFAULT '#(argb,8,8,3)color(1,1,1,1.0,co)',
  PRIMARY KEY (`aiid`),
  UNIQUE KEY `id` (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=749 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- Data exporting was unselected.
-- Dumping structure for table life.persistent_vars
CREATE TABLE IF NOT EXISTS `persistent_vars` (
  `var` varchar(50) DEFAULT NULL,
  `value` varchar(5000) DEFAULT '[]',
  `pv` tinyint(1) DEFAULT 0,
  UNIQUE KEY `var` (`var`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- Data exporting was unselected.
-- Dumping structure for table life.players
CREATE TABLE IF NOT EXISTS `players` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `uid` varchar(50) DEFAULT NULL,
  `name` varchar(50) DEFAULT '',
  `job` varchar(50) DEFAULT 'unemployed',
  `gender` varchar(50) DEFAULT 'male',
  `dob` varchar(50) DEFAULT '1/1/1990',
  `pasportdate` varchar(50) DEFAULT NULL,
  `lastseen` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `cash` int(11) DEFAULT 0,
  `bank` int(11) DEFAULT 500,
  `faction` varchar(50) DEFAULT 'citizen',
  `faction_rank` int(11) NOT NULL DEFAULT 0,
  `position` varchar(50) DEFAULT '[2786.83,5387.44,0.00146484]',
  `userkey` varchar(500) DEFAULT '[]',
  `licenses` varchar(75) DEFAULT '[]',
  `loadout` varchar(3000) DEFAULT '[]',
  `virtualinv` varchar(2000) DEFAULT '[]',
  `player_fstorage` varchar(5000) DEFAULT '[]',
  `jail` int(20) unsigned DEFAULT 0,
  `adminpowers` varchar(750) DEFAULT '[]',
  `stafftitle` varchar(50) NOT NULL,
  `twitterprofile` varchar(500) NOT NULL DEFAULT '[`\\A3PL_Common\\icons\\citizen.paa`,`#ed7202`,`#B5B5B5`,[[`\\A3PL_Common\\icons\\citizen.paa`,`Citizen Tag`]],[[`#ed7202`,`Citizen`]],[[`#B5B5B5`,`Default`]]]',
  PRIMARY KEY (`ID`) USING BTREE,
  UNIQUE KEY `uid` (`uid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=230 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='Admin powers: [`debug`,`spectate`,`players`,`editplayer`,`vehicles`,`cursortarget`,`admintag`,`globalmessage`,`factories`,`mapmarkers`,`mapteleporting`,`twitter`,`createfire`,`removefire`,`mayorvote`]\r\nTwitter Profile: [`DIRECTORTAG`,`#fff200`,[[`DIRECTORTAG`,Director`],[`CIVTAG`,`Civ`]],[]]';

-- Data exporting was unselected.
-- Dumping structure for table life.policedatabase
CREATE TABLE IF NOT EXISTS `policedatabase` (
  `ID` int(20) NOT NULL AUTO_INCREMENT,
  `UID` varchar(50) DEFAULT NULL,
  `Actiontype` varchar(50) DEFAULT NULL,
  `Info` varchar(500) DEFAULT NULL,
  `Time` varchar(50) DEFAULT NULL,
  `Title` varchar(100) DEFAULT NULL,
  `Amount` mediumint(20) unsigned DEFAULT 0,
  `IssuedBy` varchar(50) DEFAULT NULL,
  UNIQUE KEY `ID` (`ID`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=120 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- Data exporting was unselected.
-- Dumping structure for table life.referal_system
CREATE TABLE IF NOT EXISTS `referal_system` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `token` varchar(50) DEFAULT NULL,
  `reward` text DEFAULT NULL,
  `limit` int(11) DEFAULT 0,
  `count` int(11) DEFAULT 0,
  `uid` varchar(50) DEFAULT NULL,
  `rewardCreator` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `token` (`token`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

-- Data exporting was unselected.
-- Dumping structure for table life.shops
CREATE TABLE IF NOT EXISTS `shops` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `shop` varchar(50) NOT NULL DEFAULT 'Shop_Vehicles_Supplies_Vendor',
  `object` varchar(30) NOT NULL DEFAULT '',
  `stock` varchar(500) NOT NULL DEFAULT '[]',
  UNIQUE KEY `id` (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- Data exporting was unselected.
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
