/*
	Author: Conner 'Optix'
	File Name: config.cpp
	Desc:
	- Config for the ServerSide, Sets shit up enit.
*/

class CfgPatches {
	class A3PLS {
		units[] = {};
		weapons[] = {};
		requiredVersion = 1.0;
		requiredAddons[] = {};
	};
};

class CfgFunctions {
	class Bootstrap {
		class ServerFunctions {
			file = "A3PLS";
			class PreInit {preInit = 1;};
		};
	};
};
