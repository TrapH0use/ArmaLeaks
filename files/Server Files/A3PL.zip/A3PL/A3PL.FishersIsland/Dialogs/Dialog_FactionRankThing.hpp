class Dialog_FactionRank
{
	idd = 9969;
	movingEnable = 0;
	enableSimulation = 1;
	onLoad = "";
	onUnload = "";

	class controls
	{
		class RscText_1000: RscText {
			idc = -1;
			x = 0.324687 * safezoneW + safezoneX;
			y = 0.357 * safezoneH + safezoneY;
			w = 0.350625 * safezoneW;
			h = 0.088 * safezoneH;
			colorBackground[] = {0,0,0,0.8};
		};
		class RscEdit_1400: RscCombo {
			idc = 9970;
			x = 0.335 * safezoneW + safezoneX;
			y = 0.379 * safezoneH + safezoneY;
			w = 0.2475 * safezoneW;
			h = 0.044 * safezoneH;
		};
		class RscButton_1600: RscButton {
			idc = 9971;
			text = "Save";
			x = 0.592812 * safezoneW + safezoneX;
			y = 0.379 * safezoneH + safezoneY;
			w = 0.0721875 * safezoneW;
			h = 0.044 * safezoneH;
			action = "[] spawn AFPL_FS_ChangeFactionRank";
		};
	};
};

class Dialog_Referal_Claim
{
	idd = 9999;
	movingEnable = 0;
	enableSimulation = 1;
	onLoad = "";
	onUnload = "";

	class controls
	{
		class RscText_1000: RscText {
			idc = -1;
			x = 0.324687 * safezoneW + safezoneX;
			y = 0.357 * safezoneH + safezoneY;
			w = 0.350625 * safezoneW;
			h = 0.088 * safezoneH;
			colorBackground[] = {0,0,0,0.8};
		};
		class RscEdit_1400: RscEdit {
			idc = 9991;
			x = 0.335 * safezoneW + safezoneX;
			y = 0.379 * safezoneH + safezoneY;
			w = 0.2475 * safezoneW;
			h = 0.044 * safezoneH;
		};
		class RscButton_1600: RscButton {
			idc = 9971;
			text = "Claim";
			x = 0.592812 * safezoneW + safezoneX;
			y = 0.379 * safezoneH + safezoneY;
			w = 0.0721875 * safezoneW;
			h = 0.044 * safezoneH;
			action = "[] spawn AFPL_Referal_Claim";
		};
	};
};

class Dialog_Referal_Claim_Creator
{
	idd = 88888;
	movingEnable = 0;
	enableSimulation = 1;
	onLoad = "";
	onUnload = "";

	class controls
	{
		class RscText_1000: RscText {
			idc = -1;
			x = 0.298906 * safezoneW + safezoneX;
			y = 0.225 * safezoneH + safezoneY;
			w = 0.237187 * safezoneW;
			h = 0.539 * safezoneH;
			colorBackground[] = {0,0,0,0.8};
		};
		class RscEdit_1400: RscListbox {
			idc = 88881;
			x = 0.304062 * safezoneW + safezoneX;
			y = 0.247 * safezoneH + safezoneY;
			w = 0.226875 * safezoneW;
			h = 0.462 * safezoneH;
		};
		class RscButton_1600: RscButton {
			idc = 88871;
			text = "Claim";
			x = 0.304062 * safezoneW + safezoneX;
			y = 0.72 * safezoneH + safezoneY;
			w = 0.226875 * safezoneW;
			h = 0.033 * safezoneH;
			action = "[] spawn AFPL_Referal_Creator_Claim";
		};
	};
};