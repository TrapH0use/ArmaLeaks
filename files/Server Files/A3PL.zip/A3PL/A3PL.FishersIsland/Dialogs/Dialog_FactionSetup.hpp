class Dialog_FactionSetup
{
	idd = 111;
	movingEnable = 0;
	enableSimulation = 1;
	onLoad = "";
	onUnload = "";

	class controlsBackground {
		class RscPicture_1200: RscPicture {
			idc = 1200;
			text = "\A3PL_Common\gui\factionsetup.paa";
			x = 0.273125 * safezoneW + safezoneX;
			y = 0.126 * safezoneH + safezoneY;
			w = 0.463541 * safezoneW;
			h = 0.751593 * safezoneH;
		};
	};

	class controls
	{
		////////////////////////////////////////////////////////
		// GUI EDITOR OUTPUT START (by Cameron, v1.063, #Fasudo)
		////////////////////////////////////////////////////////
		class ranks: RscListbox
		{
			idc = 1501;
			x = 0.325156 * safezoneW + safezoneX;
			y = 0.269815 * safezoneH + safezoneY;
			w = 0.360521 * safezoneW;
			h = 0.456852 * safezoneH;
		};
		class setPayBox: RscEdit
		{
			idc = 1401;
			x = 0.323125 * safezoneW + safezoneX;
			y = 0.73737 * safezoneH + safezoneY;
			w = 0.15375 * safezoneW;
			h = 0.0244445 * safezoneH;
		};
		class withdrawBox: RscEdit
		{
			idc = 1402;
			x = 0.533593 * safezoneW + safezoneX;
			y = 0.736445 * safezoneH + safezoneY;
			w = 0.15375 * safezoneW;
			h = 0.0244445 * safezoneH;
		};
		class RscText_1000: RscText
		{
			idc = 1000;
			text = "BUDGET"; //--- ToDo: Localize;
			x = 0.329843 * safezoneW + safezoneX;
			y = 0.808 * safezoneH + safezoneY;
			w = 0.355781 * safezoneW;
			h = 0.044 * safezoneH;
		};
		class setPay: RscButtonEmpty
		{
			idc = 2403;
			x = 0.321041 * safezoneW + safezoneX;
			y = 0.766555 * safezoneH + safezoneY;
			w = 0.158854 * safezoneW;
			h = 0.0321853 * safezoneH;
		};
		class withdrawBtn: RscButtonEmpty
		{
			idc = 2405;
			x = 0.529792 * safezoneW + safezoneX;
			y = 0.764815 * safezoneH + safezoneY;
			w = 0.158854 * safezoneW;
			h = 0.0321853 * safezoneH;
		};
		////////////////////////////////////////////////////////
		// GUI EDITOR OUTPUT END
		////////////////////////////////////////////////////////
	};
};