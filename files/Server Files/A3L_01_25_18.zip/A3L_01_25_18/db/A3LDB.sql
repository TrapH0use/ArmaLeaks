-- --------------------------------------------------------
-- Host:                         149.56.243.139
-- Server version:               10.2.6-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             9.4.0.5125
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Dumping database structure for maptest
CREATE DATABASE IF NOT EXISTS `maptest` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `maptest`;

-- Dumping structure for table maptest.bans
CREATE TABLE IF NOT EXISTS `bans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `banuid` varchar(50) NOT NULL DEFAULT '',
  `adminuid` varchar(50) NOT NULL DEFAULT '',
  `isperm` int(11) NOT NULL DEFAULT 0,
  `added` varchar(50) NOT NULL DEFAULT '0',
  `time` int(11) NOT NULL DEFAULT 0,
  `reason` varchar(500) NOT NULL DEFAULT '',
  UNIQUE KEY `id` (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table maptest.cellphone
CREATE TABLE IF NOT EXISTS `cellphone` (
  `name` varchar(32) NOT NULL,
  `playerid` varchar(50) NOT NULL,
  `number` int(11) NOT NULL,
  `settings` text NOT NULL,
  `contacts` text NOT NULL,
  `batterylevel` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table maptest.containers
CREATE TABLE IF NOT EXISTS `containers` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `pid` varchar(17) NOT NULL,
  `classname` varchar(32) NOT NULL,
  `pos` varchar(64) DEFAULT NULL,
  `inventory` text NOT NULL,
  `gear` text NOT NULL,
  `dir` varchar(128) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 0,
  `owned` tinyint(1) DEFAULT 0,
  `insert_time` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`,`pid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=123 DEFAULT CHARSET=utf8mb4;

-- Data exporting was unselected.
-- Dumping structure for procedure maptest.deleteDeadVehicles
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `deleteDeadVehicles`()
BEGIN
  DELETE FROM `vehicles` WHERE `alive` = 0;
END//
DELIMITER ;

-- Dumping structure for procedure maptest.deleteOldContainers
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `deleteOldContainers`()
BEGIN
  DELETE FROM `containers` WHERE `owned` = 0;
END//
DELIMITER ;

-- Dumping structure for procedure maptest.deleteOldGangs
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `deleteOldGangs`()
BEGIN
  DELETE FROM `gangs` WHERE `active` = 0;
END//
DELIMITER ;

-- Dumping structure for procedure maptest.deleteOldHouses
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `deleteOldHouses`()
BEGIN
  DELETE FROM `houses` WHERE `owned` = 0;
END//
DELIMITER ;

-- Dumping structure for procedure maptest.deleteOldWanted
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `deleteOldWanted`()
BEGIN
  DELETE FROM `wanted` WHERE `active` = 0;
END//
DELIMITER ;

-- Dumping structure for table maptest.dynmarket
CREATE TABLE IF NOT EXISTS `dynmarket` (
  `id` int(11) NOT NULL DEFAULT 1,
  `prices` text NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- Data exporting was unselected.
-- Dumping structure for table maptest.economy
CREATE TABLE IF NOT EXISTS `economy` (
  `numero` int(12) NOT NULL AUTO_INCREMENT,
  `ressource` varchar(32) NOT NULL,
  `sellprice` int(100) NOT NULL DEFAULT 0,
  `buyprice` int(100) NOT NULL DEFAULT 0,
  `varprice` int(100) NOT NULL,
  `minprice` int(100) NOT NULL,
  `maxprice` int(100) NOT NULL,
  `factor` int(2) NOT NULL DEFAULT 0,
  `shoptype` varchar(32) NOT NULL,
  PRIMARY KEY (`numero`) USING BTREE,
  UNIQUE KEY `ressource` (`ressource`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=90 DEFAULT CHARSET=latin1;

-- Data exporting was unselected.
-- Dumping structure for table maptest.gangareas
CREATE TABLE IF NOT EXISTS `gangareas` (
  `gangarea` int(12) NOT NULL AUTO_INCREMENT,
  `gangname` varchar(50) NOT NULL,
  `gangleader` varchar(50) NOT NULL,
  `areamoney` int(100) NOT NULL DEFAULT 0,
  `specified` varchar(50) NOT NULL,
  `slaves` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`gangarea`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='Specified areas:\r\n-Clothes (50% off all clothes)\r\n-Weapons (';

-- Data exporting was unselected.
-- Dumping structure for table maptest.gangs
CREATE TABLE IF NOT EXISTS `gangs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `owner` varchar(32) DEFAULT NULL,
  `name` varchar(32) DEFAULT NULL,
  `members` text DEFAULT NULL,
  `maxmembers` int(2) DEFAULT 8,
  `bank` int(100) DEFAULT 0,
  `active` tinyint(4) DEFAULT 1,
  `gangshop` text DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `name_UNIQUE` (`name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=30113 DEFAULT CHARSET=latin1;

-- Data exporting was unselected.
-- Dumping structure for table maptest.houses
CREATE TABLE IF NOT EXISTS `houses` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `pid` varchar(17) NOT NULL,
  `pos` varchar(64) DEFAULT NULL,
  `owned` tinyint(4) DEFAULT 0,
  `inventory` text DEFAULT NULL,
  `garage` tinyint(1) NOT NULL DEFAULT 0,
  `insert_time` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`,`pid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=123 DEFAULT CHARSET=utf8mb4;

-- Data exporting was unselected.
-- Dumping structure for table maptest.players
CREATE TABLE IF NOT EXISTS `players` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `pid` varchar(50) NOT NULL,
  `cash` int(100) NOT NULL DEFAULT 0,
  `bankacc` int(100) NOT NULL DEFAULT 0,
  `adminlevel` enum('0','1','2','3','4','5') NOT NULL DEFAULT '0',
  `dojlevel` enum('0','1','2','3','4','5') NOT NULL DEFAULT '0',
  `coplevel` enum('0','1','2','3','4','5','6','7','8','9','10','11','12','13','14','15') NOT NULL DEFAULT '0',
  `mediclevel` enum('0','1','2','3','4','5','6','7','8','9','10','11','12','13','14','15') NOT NULL DEFAULT '0',
  `donorlevel` enum('0','1','2','3','4','5') NOT NULL DEFAULT '0',
  `issupport` enum('0','1') NOT NULL DEFAULT '0',
  `arrested` tinyint(1) NOT NULL DEFAULT 0,
  `aliases` text NOT NULL,
  `cop_licenses` text DEFAULT NULL,
  `med_licenses` text DEFAULT NULL,
  `civ_licenses` text DEFAULT NULL,
  `civ_gear` text NOT NULL,
  `cop_gear` text NOT NULL,
  `med_gear` text NOT NULL,
  `jailtime` int(11) NOT NULL DEFAULT 0,
  `arrestreason` varchar(150) NOT NULL,
  `customcolor` text DEFAULT NULL,
  `blacklist` tinyint(1) NOT NULL DEFAULT 0,
  `civ_alive` tinyint(1) NOT NULL DEFAULT 0,
  `civ_position` varchar(64) NOT NULL DEFAULT '"[]"',
  `playtime` varchar(32) NOT NULL DEFAULT '"[0,0,0]"',
  `civ_stats` varchar(32) NOT NULL DEFAULT '"[100,100,0]"',
  `cop_stats` varchar(32) NOT NULL DEFAULT '"[100,100,0]"',
  `med_stats` varchar(32) NOT NULL DEFAULT '"[100,100,0]"',
  `exp_level` int(11) NOT NULL DEFAULT 0,
  `exp_total` int(11) NOT NULL DEFAULT 0,
  `exp_perkPoints` int(11) NOT NULL DEFAULT 0,
  `exp_perks` text DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `pid` (`pid`) USING BTREE,
  KEY `name` (`name`) USING BTREE,
  KEY `blacklist` (`blacklist`)
) ENGINE=InnoDB AUTO_INCREMENT=1203 DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for procedure maptest.resetLifeVehicles
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `resetLifeVehicles`()
BEGIN
  UPDATE `vehicles` SET `active`= 0;
END//
DELIMITER ;

-- Dumping structure for table maptest.servers
CREATE TABLE IF NOT EXISTS `servers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `ip` varchar(55) DEFAULT NULL,
  `port` varchar(10) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `status` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table maptest.skills
CREATE TABLE IF NOT EXISTS `skills` (
  `name` varchar(50) NOT NULL,
  `playerid` varchar(50) NOT NULL,
  `miningexp` int(12) NOT NULL,
  `farmingexp` int(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table maptest.usertable
CREATE TABLE IF NOT EXISTS `usertable` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `uid` varchar(17) DEFAULT NULL,
  UNIQUE KEY `id` (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table maptest.vehicledata
CREATE TABLE IF NOT EXISTS `vehicledata` (
  `A3L_VehicleID` int(255) NOT NULL AUTO_INCREMENT,
  `A3L_VehicleType` varchar(60) NOT NULL,
  `A3L_VehicleA` varchar(60) NOT NULL,
  `A3L_VehicleS` varchar(60) NOT NULL,
  `A3L_OwnerUID` varchar(60) NOT NULL,
  `A3L_RandIdentity` int(255) NOT NULL,
  PRIMARY KEY (`A3L_VehicleID`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.
-- Dumping structure for table maptest.vehiclemarket
CREATE TABLE IF NOT EXISTS `vehiclemarket` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `side` varchar(15) NOT NULL,
  `classname` varchar(32) NOT NULL,
  `type` varchar(12) NOT NULL,
  `pid` varchar(32) NOT NULL,
  `alive` tinyint(1) NOT NULL DEFAULT 1,
  `active` tinyint(1) NOT NULL DEFAULT 0,
  `plate` int(20) NOT NULL,
  `color` int(20) NOT NULL,
  `inventory` varchar(500) NOT NULL,
  `impounded` tinyint(1) NOT NULL DEFAULT 0,
  `impoundcost` int(32) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `side` (`side`) USING BTREE,
  KEY `pid` (`pid`) USING BTREE,
  KEY `type` (`type`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='9/12/2016 TWO NEW TABLES ADDED\r\n- IMPOUNDED\r\n- IMPOUNDCOST\r\nWill be worked on later the time, Chris forced me to fap on house selling\r\n~Zan';

-- Data exporting was unselected.
-- Dumping structure for table maptest.vehicles
CREATE TABLE IF NOT EXISTS `vehicles` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `side` varchar(16) NOT NULL,
  `classname` varchar(64) NOT NULL,
  `type` varchar(16) NOT NULL,
  `pid` varchar(17) NOT NULL,
  `alive` tinyint(1) NOT NULL DEFAULT 1,
  `blacklist` tinyint(1) NOT NULL DEFAULT 0,
  `active` tinyint(1) NOT NULL DEFAULT 0,
  `plate` int(20) NOT NULL,
  `color` int(20) NOT NULL,
  `inventory` text NOT NULL,
  `gear` text NOT NULL,
  `fuel` double NOT NULL DEFAULT 1,
  `damage` varchar(256) NOT NULL,
  `insert_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `tuning_data` varchar(300) NOT NULL DEFAULT '[]',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `side` (`side`) USING BTREE,
  KEY `pid` (`pid`) USING BTREE,
  KEY `type` (`type`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6923 DEFAULT CHARSET=utf8mb4;

-- Data exporting was unselected.
-- Dumping structure for table maptest.wanted
CREATE TABLE IF NOT EXISTS `wanted` (
  `wantedID` varchar(64) NOT NULL,
  `wantedName` varchar(32) NOT NULL,
  `wantedCrimes` text NOT NULL,
  `wantedBounty` int(100) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 0,
  `insert_time` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`wantedID`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Data exporting was unselected.
-- Dumping structure for table maptest.zanzalogs
CREATE TABLE IF NOT EXISTS `zanzalogs` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `DATE` timestamp NOT NULL DEFAULT current_timestamp(),
  `TYPE` char(50) DEFAULT 'UNKNOWN',
  `NAME` char(50) NOT NULL,
  `PLAYERID` char(50) NOT NULL,
  `ACTION` char(50) DEFAULT 'Faking a log Lmao <3',
  `EXTRA` char(100) NOT NULL DEFAULT 'None',
  PRIMARY KEY (`uid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=18183 DEFAULT CHARSET=latin1 COMMENT='Don''t touch this.';

-- Data exporting was unselected.
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
