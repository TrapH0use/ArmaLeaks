/*
	Author: Maverick Applications
	Desc: Altis Life Shipwreck
*/

//Customize your settings to fit your server setup!
class Maverick_Shipwrecks {

    //How often (in seconds) should a shipwreck spawn, if no wreck is on the map?
    ShipwreckInterval = 900; //1800 = 30min

    //Define the possible locations for your shipwrecks.
    //getPosATL format -> Get the position via: diag_log(getPosATL player) -> replace the [] with {}
	Positions[] = {
        {7987,3752,0},
        {7026,5216,0},
	{8122,5635,0},
	{6733,3930,0},
	{5158,2324,0},
	{4487,2162,0},
	{4592,1697,0},
	{7332,5349,0}
	};

    //Define the radius, in which the wreck randomly spawns around the given center position
    Radius = 5;

    //Define the possible sets of virtual items the user can loot from the wreck.
	ShipLoot[] = {
        {"cellphone","cellphone","cellphone","cellphone","cellphone","cellphone","cellphone","cellphone","cellphone","cellphone","cellphone","cellphone","cellphone","cellphone","batterypack","batterypack","batterypack","batterypack","batterypack","batterypack",},
        {"marijuana","marijuana","marijuana","marijuana","marijuana","marijuana","marijuana","marijuana","marijuana","marijuana","marijuana","marijuana","marijuana","marijuana","marijuana","marijuana","marijuana","marijuana","marijuana","marijuana","marijuana","marijuana","marijuana","marijuana","marijuana","marijuana","marijuana","marijuana","marijuana","marijuana","marijuana","marijuana","marijuana","marijuana","marijuana","marijuana","marijuana","marijuana"},
        {"oilProcessed","oilProcessed","oilProcessed","oilProcessed","oilProcessed","oilProcessed","oilProcessed","oilProcessed","oilProcessed","oilProcessed","oilProcessed","oilProcessed","oilProcessed","oilProcessed","oilProcessed","oilProcessed","oilProcessed","oilProcessed","oilProcessed","oilProcessed","oilProcessed","oilProcessed","oilProcessed","oilProcessed","oilProcessed","oilProcessed","oilProcessed","oilProcessed","oilProcessed","oilProcessed"},
	{"heroinProcessed","heroinProcessed","heroinProcessed","heroinProcessed","heroinProcessed","heroinProcessed","heroinProcessed","heroinProcessed","heroinProcessed","heroinProcessed","heroinProcessed","heroinProcessed","heroinProcessed","heroinProcessed","heroinProcessed","heroinProcessed","heroinProcessed","heroinProcessed","heroinProcessed","heroinProcessed","heroinProcessed","heroinProcessed","heroinProcessed","heroinProcessed","heroinProcessed","heroinProcessed"},
	{"wheat","wheat","wheat","wheat","wheat","wheat","wheat","wheat","wheat","wheat","wheat","wheat","wheat","wheat","wheat","wheat","wheat","wheat","wheat","wheat","wheat","wheat","wheat","wheat","cotton","cotton","cotton","cotton","cotton","cotton","cotton","cotton","cotton","cotton","cotton","cotton","cotton","cotton","corn","corn","corn","corn","corn","corn","corn","corn","corn","corn","corn","corn","corn","corn","corn","corn","corn","corn"},
	{"zoobeer","zoobeer","zoobeer","zoobeer","zoobeer","zoobeer","zoobeer","zoobeer","zoobeer","redgull","redgull","redgull","redgull","redgull","redgull","redgull","redgull","cigarette","cigarette","cigarette","cigarette","cigarette","cigarette","cigarette","Earplugs","Earplugs","Earplugs","Earplugs","Earplugs","rabbit","rabbit","rabbit","rabbit","rabbit","rabbit","rabbit","rabbit","rabbit","rabbit","rabbit","rabbit","rabbit","rabbit","rabbit","rabbit"}
	};

	//What shall be displayed as text to gather the items from the ship? (The text of the addAction ingame)
	ShipLootText = "Retrieve the loot";

    //The message when the user has got all the loot successfully.
    ShipLootSuccess = "You successfully claimed the wreck's loot for you!";

    //The message in case something fails, or the user can not carry all the items.
    ShipLootFail = "You can not carry all the loot. Make some room first!";

	//Define the message, that should appear when a shipwreck spawns (broadcasted to all clients).
	SpawnMSG = "SHIPWRECK\n\nA sunken ship has been located! It may contain important items and it has been marked on your map!";

    //Define the message, that should appear when a shipwreck disappears after a user looted it (broadcasted to all clients).
	DeleteMSG = "SHIPWRECK\n\nThe ship has been successfully looted and has despawned!";
};
