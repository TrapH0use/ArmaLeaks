//New Perks
class Perk2 {
	displayName = "Medic Perks";
	color[] = {1,1,1,1};
	requiredPerkPoints = 1;
	requiredLevel = 1;
	requiredPerk = "";
	limitToSides[] = {"WEST","CIV"};
	subtitle = "Learn the tricks of the medical trade.";
	description = "Unlock access to the medic perk tree by purchasing this for 1 perk point.";
};

class Perk9 {
	displayName = "Quicker Respawn";
	requiredPerkPoints = 5;
	requiredLevel = 3;
	requiredPerk = "Perk2";
	subtitle = "Shorter respawn time!";
	limitToSides[] = {"CIV","WEST"};
	description = "For 5 perk points you can half your respawn timer.";
};

class perk_mandown {
	displayName = "Trained Medic";
	requiredPerkPoints = 7;
	requiredLevel = 4;
	requiredPerk = "Perk2";
	subtitle = "Ignore CPR Limits";
	limitToSides[] = {"CIV","WEST"};
	description = "For 7 perk points you can learn to revive even when there are 3 medics on duty.";
};

class perk_mandown_1 {
	displayName = "CPR Training";
	requiredPerkPoints = 2;
	requiredLevel = 2;
	requiredPerk = "Perk2";
	subtitle = "Level 2 Required, 2 Perk Points";
	description = "For 2 perk points you can learn to be 10% more likely to succesfully CPR downed players!";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_manDown_1.sqf";
	limitToSides[] = {"CIV","WEST"};
	color[] = {1,1,1,1};
};

class perk_mandown_2 {
	displayName = "Advanced CPR Training";
	requiredPerkPoints = 5;
	requiredLevel = 3;
	requiredPerk = "perk_mandown_1";
	subtitle = "Level 3 Required, 5 Perk Points";
	description = "For 5 perk points you can learn to be 25% more likely to succesfully CPR downed players!";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_manDown_2.sqf";
	limitToSides[] = {"CIV","WEST"};
	color[] = {1,1,1,1};
};

class perk_mandown_3 {
	displayName = "Exceptional CPR Training";
	requiredPerkPoints = 7;
	requiredLevel = 4;
	requiredPerk = "perk_mandown_2";
	subtitle = "Level 4 Required, 7 Perk Points";
	description = "For 7 perk points you can learn to be 50% more likely to succesfully CPR downed players!";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_manDown_3.sqf";
	limitToSides[] = {"CIV","WEST"};
	color[] = {1,1,1,1};
};

class perk_mandown_4 {
	displayName = "Expert CPR Training";
	requiredPerkPoints = 10;
	requiredLevel = 6;
	requiredPerk = "perk_mandown_3";
	subtitle = "Level 6 Required, 10 Perk Points";
	description = "For 10 perk points you can learn to be 50% more likely to succesfully CPR downed players!";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_manDown_3.sqf";
	limitToSides[] = {"CIV","WEST"};
	color[] = {1,1,1,1};
};

class perk_mandown_5 {
	displayName = "Phenomenal CPR Training";
	requiredPerkPoints = 11;
	requiredLevel = 17;
	requiredPerk = "perk_mandown_4";
	subtitle = "Level 17 Required, 11 Perk Points";
	description = "Allows CPR without a Defibrillator";
	limitToSides[] = {"CIV","WEST"};
	color[] = {1,1,1,1};
};
//////////////////////////////////////////////////////////////////////////////////////////////////
class Perk3 {
	displayName = "Combat Perks";
	color[] = {1,1,1,1};
	requiredPerkPoints = 4;
	requiredLevel = 1;
	requiredPerk = "";
	limitToSides[] = {"WEST","CIV"};
	subtitle = "Become the expert at combat.";
	description = "Unlock access to the combat perk tree by purchasing this for 4 perk points.";
};


class Perk3_2 {
	displayName = "Caffeine Junky";
	color[] = {1,1,1,1};
	requiredPerkPoints = 5;
	requiredLevel = 3;
	requiredPerk = "Perk3";
	subtitle = "Make redgull more effective!";
	description = "For 5 perk points you can make redgull much more effective and double how long it lasts.";
};

/* Disable recoil perks for now
class Perk3_1 {
	displayName = "5% Lower Recoil";
	color[] = {1,1,1,1};
	requiredPerkPoints = 5;
	requiredLevel = 3;
	requiredPerk = "Perk3";
	subtitle = "Lower your recoil by 5%!";
	description = "For 5 perk points you can improve your handling of recoil so you are 5% less affected by it.";
	initScript = "maverick\talent-tree-modular\modules\example_module\recoil.sqf"; 
};

class Perk3_1_1 {
	displayName = "10% Lower Recoil";
	color[] = {1,1,1,1};
	requiredPerkPoints = 6;
	requiredLevel = 5;
	requiredPerk = "Perk3_1";
	subtitle = "Lower your recoil by 10%!";
	description = "For 6 perk points you can improve your handling of recoil so you are 10% less affected by it.";
	initScript = "maverick\talent-tree-modular\modules\example_module\recoil.sqf"; 
};

class Perk3_1_1_1 {
	displayName = "15% Lower Recoil";
	color[] = {1,1,1,1};
	requiredPerkPoints = 8;
	requiredLevel = 6;
	requiredPerk = "Perk3_1_1";
	subtitle = "Lower your recoil by 15%!";
	description = "For 8 perk points you can improve your handling of recoil so you are 15% less affected by it.";
	initScript = "maverick\talent-tree-modular\modules\example_module\recoil.sqf"; 
};

class Perk3_1_1_1_1 {
	displayName = "25% Lower Recoil";
	color[] = {1,1,1,1};
	requiredPerkPoints = 8;
	requiredLevel = 7;
	requiredPerk = "Perk3_1_1_1";
	subtitle = "Lower your recoil by 25%!";
	description = "For 8 perk points you can improve your handling of recoil so you are 25% less affected by it.";
	initScript = "maverick\talent-tree-modular\modules\example_module\recoil.sqf"; 
};

class Perk3_1_1_1_1_1 {
	displayName = "50% Lower Recoil";
	color[] = {1,1,1,1};
	requiredPerkPoints = 8;
	requiredLevel = 8;
	requiredPerk = "Perk3_1_1_1_1";
	subtitle = "Lower your recoil by 50%!";
	description = "For 8 perk points you can improve your handling of recoil so you are 50% less affected by it.";
	initScript = "maverick\talent-tree-modular\modules\example_module\recoil.sqf"; 
};
*/ //End disabling recoil for now

///////////////////////////////////////////////////
/* Financial perks - Can be added Later
class Perk5 {
	displayName = "Financial Perks";
	color[] = {0,0.56,0.5,1};
	requiredPerkPoints = 4;
	requiredLevel = 2;
	requiredPerk = "";
	subtitle = "Maximize your financial income.";
	description = "Unlock access to the financial perk tree by purchasing this for 4 perk points.";
};

class Perk5_1 {
	displayName = "Double Unemployment Paycheck";
	requiredPerkPoints = 4;
	requiredLevel = 3;
	requiredPerk = "Perk5";
	subtitle = "Double your unemployment cheque";
	description = "For 4 perk points you can double the unemployment paycheck from $100 to $200.";
};

class Perk5_1_1 {
	displayName = "Triple Unemployment Paycheck";
	requiredPerkPoints = 5;
	requiredLevel = 4;
	requiredPerk = "Perk5_1";
	subtitle = "Triple your unemployment cheque";
	description = "For 5 perk points you can double the unemployment paycheck from $100 to $300.";
};

class Perk5_2 {
	displayName = "Cheaper Vehicles";
	requiredPerkPoints = 3;
	requiredLevel = 2;
	requiredPerk = "Perk5";
	subtitle = "Reduce the cost of all new vehicles!";
	description = "For 3 perk points you can lower the price of all new vehicles by 5%.";
};
*/
/////////////////////////////////////////////////////////////////
/* Double/triple XP - Disabled for now
class Perk10 {
	displayName = "General Perks";
	requiredPerkPoints = 2;
	requiredLevel = 1;
	requiredPerk = "";
	subtitle = "Improve your general skills.";
	description = "Unlock access to the general perk tree by purchasing this for 2 perk points.";
};

class Perk10_1 {
	displayName = "Triple EXP";
	requiredPerkPoints = 6;
	requiredLevel = 1;
	requiredPerk = "Perk10";
	subtitle = "Triple the XP you get every 5 minutes!";
	description = "For 4 perk points you can triple the amount of XP you get every 5 minutes.";
};
*/
//Old Perks
// -- Faster processing
class perk_processing_1 {
	displayName = "Processing Speed";
	requiredPerkPoints = 3;
	requiredLevel = 4;
	requiredPerk = "";
	subtitle = "Level 4 Required, 3 Perk Points";
	description = "Learn to process materials more efficiently<br/><br/><t color='#10FF45'>+10% faster processing</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_processSpeed_1.sqf";
	limitToSides[] = {"CIV"};
	color[] = {1,1,1,1};
};

class perk_processing_2 {
	displayName = "Processing Speed 2";
	requiredPerkPoints = 3;
	requiredLevel = 7;
	requiredPerk = "perk_processing_1";
	subtitle = "Level 7 Required, 3 Perk Points";
	description = "Learn to process materials more efficiently<br/><br/><t color='#10FF45'>+15% faster processing</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_processSpeed_2.sqf";
	limitToSides[] = {"CIV"};
	color[] = {1,1,1,1};
};

class perk_processing_3 {
	displayName = "Processing Speed 3";
	requiredPerkPoints = 4;
	requiredLevel = 17;
	requiredPerk = "perk_processing_2";
	subtitle = "Level 17 Required, 4 Perk Points";
	description = "Learn to process materials more efficiently<br/><br/><t color='#10FF45'>+25% faster processing</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_processSpeed_3.sqf";
	limitToSides[] = {"CIV"};
	color[] = {1,1,1,1};
};

// -- Faster lockpicking
class perk_locksmith_1 {
	displayName = "Locksmith";
	requiredPerkPoints = 5;
	requiredLevel = 7;
	requiredPerk = "";
	subtitle = "Level 7 Required, 5 Perk Points";
	description = "Learn to pick locks more efficiently and reduce lockpicking times on vehicles<br/><br/><t color='#10FF45'>+10% faster lockpicking</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_lockpickSpeed_1.sqf";
	limitToSides[] = {"CIV"};
	color[] = {1,1,1,1};
};

class perk_locksmith_2 {
	displayName = "Locksmith 2";
	requiredPerkPoints = 6;
	requiredLevel = 16;
	requiredPerk = "perk_locksmith_1";
	subtitle = "Level 16 Required, 6 Perk Points";
	description = "Learn to pick locks more efficiently and reduce lockpicking times on vehicles<br/><br/><t color='#10FF45'>+15% faster lockpicking</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_lockpickSpeed_2.sqf";
	limitToSides[] = {"CIV"};
	color[] = {1,1,1,1};
};

class perk_locksmith_3 {
	displayName = "Locksmith 3";
	requiredPerkPoints = 4;
	requiredLevel = 28;
	requiredPerk = "perk_locksmith_2";
	subtitle = "Level 28 Required, 4 Perk Points";
	description = "Learn to pick locks more efficiently and reduce lockpicking times on vehicles<br/><br/><t color='#10FF45'>+25% faster lockpicking</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_lockpickSpeed_3.sqf";
	limitToSides[] = {"CIV"};
	color[] = {1,1,1,1};
};

//Engineering - Repair Vehicles
class perk_engineering {
	displayName = "Vehicle Perks";
	requiredPerkPoints = 1;
	requiredLevel = 1;
	requiredPerk = "";
	subtitle = "Level 1 Required, 1 Perk Points";
	description = "Unlock access to the vehicle perk tree by purchasing this for 1 perk point.";
	limitToSides[] = {};
	color[] = {1,1,1,1};
};
class perk_engineering_1 {
	displayName = "Junior Mechanic";
	requiredPerkPoints = 2;
	requiredLevel = 1;
	requiredPerk = "perk_engineering";
	subtitle = "Level 1 Required, 2 Perk Points";
	description = "For 2 perk points you can unlock the junior mechanic perk which allows you to repair cars a little quicker than normal.";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_engineeringSpeed_1.sqf";
	limitToSides[] = {};
	color[] = {1,1,1,1};
};

class perk_engineering_2 {
	displayName = "Standard Mechanic";
	requiredPerkPoints = 4;
	requiredLevel = 2;
	requiredPerk = "perk_engineering_1";
	subtitle = "Level 2 Required, 4 Perk Points";
	description = "For 4 perk points you can unlock the standard mechanic perk which allows you to repair cars even quicker!";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_engineeringSpeed_2.sqf";
	limitToSides[] = {};
	color[] = {1,1,1,1};
};

class perk_engineering_3 {
	displayName = "Senior Mechanic";
	requiredPerkPoints = 9;
	requiredLevel = 4;
	requiredPerk = "perk_engineering_2";
	subtitle = "Level 4 Required, 9 Perk Points";
	description = "For 9 perk points you can unlock the senior mechanic perk which allows you to repair vehicles super quickly.";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_engineeringSpeed_3.sqf";
	limitToSides[] = {};
	color[] = {1,1,1,1};
};

class perk_engineering_4 {
	displayName = "Expert Mechanic";
	requiredPerkPoints = 10;
	requiredLevel = 7;
	requiredPerk = "perk_engineering_3";
	subtitle = "Level 7 Required, 10 Perk Points";
	description = "For 10 perk points you can unlock the expert mechanic perk which allows you to repair vehicles at the fastest rate.";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_engineeringSpeed_4.sqf";
	limitToSides[] = {};
	color[] = {1,1,1,1};
};

//Helping A Mate - Jail
class perk_helpingamate_1 {
	displayName = "Helping A Mate";
	requiredPerkPoints = 5;
	requiredLevel = 5;
	requiredPerk = "";
	subtitle = "Level 5 Required, 5 Perk Points";
	description = "Break into the department of corrections without alerting officers via 911 for an additional<br/><br/><t color='#10FF45'>20 seconds</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_helpingaMate_1.sqf";
	limitToSides[] = {"CIV"};
	color[] = {1,1,1,1};
};

class perk_helpingamate_2 {
	displayName = "Helping A Mate 2";
	requiredPerkPoints = 7;
	requiredLevel = 18;
	requiredPerk = "perk_helpingamate_1";
	subtitle = "Level 18 Required, 7 Perk Points";
	description = "Break into department of corrections without setting off the<br/><br/><t color='#10FF45'>outdoor alarm</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_helpingaMate_2.sqf";
	limitToSides[] = {"CIV"};
	color[] = {1,1,1,1};
};

class perk_helpingamate_3 {
	displayName = "Helping A Mate 3";
	requiredPerkPoints = 9;
	requiredLevel = 30;
	requiredPerk = "perk_helpingamate_2";
	subtitle = "Level 30 Required, 9 Perk Points";
	description = "Break into the department of corrections and decrease the amount of time it takes to hack open the cell doors by up to<br/><br/><t color='#10FF45'>20%</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_helpingaMate_3.sqf";
	limitToSides[] = {"CIV"};
	color[] = {1,1,1,1};
};

//In and Out
class perk_inandout_1 {
	displayName = "In and Out";
	requiredPerkPoints = 5;
	requiredLevel = 5;
	requiredPerk = "";
	subtitle = "Level 5 Required, 5 Perk Points";
	description = "Lockpick the bank doors without alerting officers via 911 for an additional<br/><br/><t color='#10FF45'>20 seconds</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_inandOut_1.sqf";
	limitToSides[] = {"CIV"};
	color[] = {1,1,1,1};
};

class perk_inandout_2 {
	displayName = "In and Out 2";
	requiredPerkPoints = 7;
	requiredLevel = 18;
	requiredPerk = "perk_inandout_1";
	subtitle = "Level 18 Required, 7 Perk Points";
	description = "Learn the skills required to lockpick the bank doors<br/><br/><t color='#10FF45'>30% faster</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_inandOut_2.sqf";
	limitToSides[] = {"CIV"};
	color[] = {1,1,1,1};
};

class perk_inandout_3 {
	displayName = "In and Out 3";
	requiredPerkPoints = 9;
	requiredLevel = 30;
	requiredPerk = "perk_inandout_2";
	subtitle = "Level 30 Required, 9 Perk Points";
	description = "Advance your skills and become a seasoned professional<br/><br/><t color='#10FF45'>gaining $100,000 when grabbing the cash</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_inandOut_3.sqf";
	limitToSides[] = {"CIV"};
	color[] = {1,1,1,1};
};

//Green Thumb
class perk_greenthumb_1 {
	displayName = "Green Thumb";
	requiredPerkPoints = 3;
	requiredLevel = 5;
	requiredPerk = "";
	subtitle = "Level 5 Required, 3 Perk Points";
	description = "You gather resources with an extra<br/><br/><t color='#10FF45'>15% output bonus</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_greenThumb_1.sqf";
	limitToSides[] = {"CIV"};
	color[] = {1,1,1,1};
};

class perk_greenthumb_2 {
	displayName = "Green Thumb 2";
	requiredPerkPoints = 7;
	requiredLevel = 14;
	requiredPerk = "perk_greenthumb_1";
	subtitle = "Level 14 Required, 7 Perk Points";
	description = "You gather resources with an extra<br/><br/><t color='#10FF45'>30% output bonus</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_greenThumb_2.sqf";
	limitToSides[] = {"CIV"};
	color[] = {1,1,1,1};
};

class perk_greenthumb_3 {
	displayName = "Green Thumb 3";
	requiredPerkPoints = 10;
	requiredLevel = 30;
	requiredPerk = "perk_greenthumb_2";
	subtitle = "Level 30 Required, 10 Perk Points";
	description = "You gather resources with an extra<br/><br/><t color='#10FF45'>50% output bonus</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_greenThumb_3.sqf";
	limitToSides[] = {"CIV"};
	color[] = {1,1,1,1};
};