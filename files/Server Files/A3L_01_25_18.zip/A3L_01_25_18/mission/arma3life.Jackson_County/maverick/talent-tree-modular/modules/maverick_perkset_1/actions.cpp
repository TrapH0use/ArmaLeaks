class VehiclePurchased {
    expToAdd = 10;
	message = "Vehicle Purchased";
};

class ItemProcessed {
    expToAdd = 4;
	message = "Items Processed";
};

class VehicleLockpicked {
    expToAdd = 5;
	message = "Vehicle Lockpicked";
};

class VehicleRepaired {
    expToAdd = 6;
	message = "Vehicle Repaired";
};

class BankLockpicked {
    expToAdd = 12;
	message = "Bank Door Lockpicked";
};

class ObjectHarvested {
    expToAdd = 6;
	message = "Plant Harvested";
};

class ResourceMined {
    expToAdd = 6;
	message = "Resource Mined";
};

class VehicleImpounded {
    expToAdd = 4;
	message = "Vehicle Impounded";
};

class Jailed {
    expToAdd = 6;
	message = "Inmate Processed";
};

class Defib {
	expToAdd = 6;
	message = "Defib Sucessful";
};

class Paycheck {
	expToAdd = 4;
	message = "Paycheck Recieved";
};

class Jobtask {
	expToAdd = 10;
	message = "Job Task Complete";
};

class EmsRevive {
	expToAdd = 15;
	message = "Player Revived";
};

class GangAreaCaptured {
	expToAdd = 5;
	message = "Gang Area Captured";
};

class Example {
    expToAdd = 100;
	message = "Customizable Message";
};
