//Made by Life Studios Development Team
class DeathScreen
{
	idd = 7300;
	name = "Life_Death_Screen";
	movingEnabled = false;
	enableSimulation = true;
	
	class controlsBackground
	{
	};
	class Controls
	{
		class DT_MedicsOnline : Life_RscButtonMenu
		{
			idc = 7304;
			text = "Medics: 1";
			x = 0.4 * safezoneW + safezoneX;
			y = 0.745 * safezoneH + safezoneY;
			w = 0.1 * safezoneW;
			h = 0.022 * safezoneH;
			onButtonClick = "";
			colorBackground[] = {0, 0, 0, 0.7};
			class Attributes 
			{
				align = "center";
			};
		};
		
		class DT_MedicNearby : Life_RscButtonMenu
		{
			idc = 7305;
			text = "Nearest: None";
			x = 0.5 * safezoneW + safezoneX;
			y = 0.745 * safezoneH + safezoneY;
			w = 0.1 * safezoneW;
			h = 0.022 * safezoneH;
			onButtonClick = "";
			colorBackground[] = {0, 0, 0, 0.7};
			class Attributes 
			{
				align = "center";
			};
		};
		
		class DT_RespawnButton : Life_RscButtonMenu
		{
			idc = 7302;
			x = 0.5 * safezoneW + safezoneX;
			y = 0.767 * safezoneH + safezoneY;
			w = 0.1 * safezoneW;
			h = 0.022 * safezoneH;
			text = "Respawn";
			onButtonClick = "closeDialog 0; life_respawned = true; [] call life_fnc_spawnMenu;";
			colorBackground[] = {0, 0, 0, 0.7};
			class Attributes 
			{
				align = "center";
			};
		};
		
		class DT_RequestMedic : Life_RscButtonMenu
		{
			idc = 7303;
			x = 0.4 * safezoneW + safezoneX;
			y = 0.767 * safezoneH + safezoneY;
			w = 0.1 * safezoneW;
			h = 0.022 * safezoneH;
			onButtonClick = "[] call life_fnc_requestMedic;";
			text = "Request Medic";
			colorBackground[] = {0, 0, 0, 0.7};
			class Attributes 
			{
				align = "center";
			};
		};
		
		class DT_RespawnTime : Life_RscButtonMenu
		{
			idc = 7301;
			text = "";
			x = 0.4 * safezoneW + safezoneX;
			y = 0.723 * safezoneH + safezoneY;
			w = 0.2 * safezoneW;
			h = 0.022 * safezoneH;
			onButtonClick = "";
			colorBackground[] = {0, 0, 0, 0.7};
			class Attributes
			{
				align = "center";
			};
		};

			class DT_KilledBy : Life_RscButtonMenu
		{
			idc = 7306;
			text = "Killed by: ";
			x = 0.4 * safezoneW + safezoneX;
			y = 0.701 * safezoneH + safezoneY;
			w = 0.2 * safezoneW;
			h = 0.022 * safezoneH;
			onButtonClick = "";
			colorBackground[] = {0, 0, 0, 0.7};
			class Attributes
			{
				align = "center";
			};
		};
	};
};

