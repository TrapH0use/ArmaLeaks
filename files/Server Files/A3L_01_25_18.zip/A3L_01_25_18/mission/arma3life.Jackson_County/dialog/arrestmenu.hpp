class a3l_jail_menu {
	idd = 5546;
	name= "a3l_jail_menu";
	movingEnable = false;
	enableSimulation = true;
	onLoad = "";
	objects[] = { };
	class controls {
////////////////////////////////////////////////////////
// GUI EDITOR OUTPUT START (by Zannaza, v1.337, #YOLO)
////////////////////////////////////////////////////////

class background: RscPicture
{
	idc = 1200;
	text = "\A3L_Client2\images\arrestmenu.paa";
	x = 0.283437 * safezoneW + safezoneX;
	y = 0.15 * safezoneH + safezoneY;
	w = 0.439687 * safezoneW;
	h = 0.7 * safezoneH;
};
class nameofplayer: Life_RscText
{
	idc = 2200;
	x = 0.395 * safezoneW + safezoneX;
	y = 0.332 * safezoneH + safezoneY;
	w = 0.206667 * safezoneW;
	h = 0.0403704 * safezoneH;
};
class jailtime: RscEdit
{
	idc = 2201;
	text = "0";
	x = 0.523334 * safezoneW + safezoneX;
	y = 0.402 * safezoneH + safezoneY;
	w = 0.0775 * safezoneW;
	h = 0.0375926 * safezoneH;
};
class crimescommited: RscEdit
{
	idc = 2202;
	x = 0.395 * safezoneW + safezoneX;
	y = 0.556 * safezoneH + safezoneY;
	w = 0.207188 * safezoneW;
	h = 0.183889 * safezoneH;
};
/*class allcrimes: RscListbox
{
	idc = 2203;
	x = 0.395833 * safezoneW + safezoneX;
	y = 0.487963 * safezoneH + safezoneY;
	w = 0.12401 * safezoneW;
	h = 0.147815 * safezoneH;
};*/
class sendtojail: RscButtonSilent
{
	idc = 2204;
	action = "[] call fnc_arrestbutton;";
	x = 0.526562 * safezoneW + safezoneX;
	y = 0.746333 * safezoneH + safezoneY;
	w = 0.0754167 * safezoneW;
	h = 0.0357408 * safezoneH;
};
};
};

class a3l_arrest_panel {
	idd = 5547;
	name= "a3l_arrest_panel";
	movingEnable = false;
	enableSimulation = true;
	onLoad = "uiNamespace setVariable [""a3l_arrest_panel"", _this select 0];";
	objects[] = { };
	class controls {
////////////////////////////////////////////////////////
// GUI EDITOR OUTPUT START (by James Marks, v1.063, #Duciga)
////////////////////////////////////////////////////////

class background: RscPicture
{
	idc = 2200;

	text = "\A3L_Client2\images\jailmenu.paa";
	x = -7.36 * GUI_GRID_W + GUI_GRID_X;
	y = -3.41 * GUI_GRID_H + GUI_GRID_Y;
	w = 55.5823 * GUI_GRID_W;
	h = 31.8182 * GUI_GRID_H;
};
class nametext: RscStructuredText
{
	idc = 1000;

	x = 23.5 * GUI_GRID_W + GUI_GRID_X;
	y = 6 * GUI_GRID_H + GUI_GRID_Y;
	w = 32.25 * GUI_GRID_W;
	h = 1 * GUI_GRID_H;
};
class reasonedit: RscEdit
{
	idc = 1400;

	x = 7.44 * GUI_GRID_W + GUI_GRID_X;
	y = 15.11 * GUI_GRID_H + GUI_GRID_Y;
	w = 25.9113 * GUI_GRID_W;
	h = 5.62291 * GUI_GRID_H;
};
class hoursedit: RscEdit
{
	idc = 1401;

	x = 14.67 * GUI_GRID_W + GUI_GRID_X;
	y = 5.42 * GUI_GRID_H + GUI_GRID_Y;
	w = 7.04452 * GUI_GRID_W;
	h = 1.45623 * GUI_GRID_H;
};
class minsedit: RscEdit
{
	idc = 1402;

	x = 14.57 * GUI_GRID_W + GUI_GRID_X;
	y = 7.03 * GUI_GRID_H + GUI_GRID_Y;
	w = 7.04452 * GUI_GRID_W;
	h = 1.45623 * GUI_GRID_H;
};
class secondsedit: RscEdit
{
	idc = 1403;

	x = 14.5 * GUI_GRID_W + GUI_GRID_X;
	y = 8.71 * GUI_GRID_H + GUI_GRID_Y;
	w = 7.04452 * GUI_GRID_W;
	h = 1.45623 * GUI_GRID_H;
};
class RscButton_1600: RscButtonSilent
{
	idc = 1600;
	action = "[] call fnc_updatejailtime";

	text = "UPDATE"; //--- ToDo: Localize;
	x = 23.46 * GUI_GRID_W + GUI_GRID_X;
	y = 6.9 * GUI_GRID_H + GUI_GRID_Y;
	w = 9.62343 * GUI_GRID_W;
	h = 1.75084 * GUI_GRID_H;
};
class RscButton_1601: RscButtonSilent
{
	idc = 1601;
	action = "[] call fnc_cufflegs";

	x = 22.17 * GUI_GRID_W + GUI_GRID_X;
	y = 21.34 * GUI_GRID_H + GUI_GRID_Y;
	w = 9.2841 * GUI_GRID_W;
	h = 1.5404 * GUI_GRID_H;
};
class RscButton_1602: RscButtonSilent
{
	idc = 1602;
	action = "[] call fnc_addpickaxe";

	text = "Give/remove pickaxe"; //--- ToDo: Localize;
	x = 9.96 * GUI_GRID_W + GUI_GRID_X;
	y = 23.74 * GUI_GRID_H + GUI_GRID_Y;
	w = 9.2841 * GUI_GRID_W;
	h = 1.5404 * GUI_GRID_H;
};
class RscButton_6352: RscButtonSilent
{
	idc = 6352;
	action = "[prisoner] call life_fnc_unrestrain; closeDialog 0;";

	text = "Unrestrain"; //--- ToDo: Localize;
	x = 9.89 * GUI_GRID_W + GUI_GRID_X;
	y = 21.46 * GUI_GRID_H + GUI_GRID_Y;
	w = 9.2841 * GUI_GRID_W;
	h = 1.5404 * GUI_GRID_H;
};
class RscButton_5251: RscButtonSilent
{
	idc = 5251;

	text = "escort"; //--- ToDo: Localize;
	x = 22.1 * GUI_GRID_W + GUI_GRID_X;
	y = 23.65 * GUI_GRID_H + GUI_GRID_Y;
	w = 9.2841 * GUI_GRID_W;
	h = 1.5404 * GUI_GRID_H;
};
};
};
