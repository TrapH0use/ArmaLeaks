class a3l_cctv_doc_cam1
{
	idd=-1685;
	onUnload = "_this call a3l_fnc_destroycam;";
	movingEnable = 0;

	class controls
	{
		////////////////////////////////////////////////////////
		// GUI EDITOR OUTPUT START (by Oscar Gigsta, v1.063, #Facijy)
		////////////////////////////////////////////////////////

		class A3L_CCTV_Overlay: RscPicture
		{
			idc = 1200;

			text = "\A3L_Client2\images\cam_1.paa";
			x = -0.035425 * safezoneW + safezoneX;
			y = 0.0688 * safezoneH + safezoneY;
			w = 1.06219 * safezoneW;
			h = 0.869 * safezoneH;
		};
		class A3L_CCTV_Prev: RscButton
		{
			idc = 1600;
			x = 0.402031 * safezoneW + safezoneX;
			y = 0.841 * safezoneH + safezoneY;
			w = 0.0773437 * safezoneW;
			h = 0.033 * safezoneH;
			//action = "closedialog 0; [] call A3L_fnc_switchPrevCam;";
			onButtonClick = "closedialog 0; [] call A3L_fnc_switchPrevCam;";
		};
		class A3L_CCTV_Next: RscButton
		{
			idc = 1601;
			x = 0.525781 * safezoneW + safezoneX;
			y = 0.841 * safezoneH + safezoneY;
			w = 0.0773437 * safezoneW;
			h = 0.033 * safezoneH;
			//action = "closedialog 0; [a3l_cam] call A3L_fnc_switchNextCam;";
			onButtonClick = "closedialog 0; [] call A3L_fnc_switchNextCam;";
		};
		class A3L_CCTV_Close: RscButton
		{
			idc = 1602;
			x = 0.484531 * safezoneW + safezoneX;
			y = 0.841 * safezoneH + safezoneY;
			w = 0.0360937 * safezoneW;
			h = 0.033 * safezoneH;
			action = "closedialog 0; [] call A3L_fnc_destroyCam;";
		};
		////////////////////////////////////////////////////////
		// GUI EDITOR OUTPUT END
		////////////////////////////////////////////////////////

	};
};

class a3l_cctv_doc_cam2
{
	idd=-1;
	onUnload = "_this call a3l_fnc_destroycam;";
	movingEnable = 0;

	class controls
	{
		////////////////////////////////////////////////////////
		// GUI EDITOR OUTPUT START (by Oscar Gigsta, v1.063, #Zefehy)
		////////////////////////////////////////////////////////

		class A3L_CCTV_Overlay: RscPicture
		{
			idc = 1200;
			text = "\A3L_Client2\images\cam_2.paa";
			x = -0.035425 * safezoneW + safezoneX;
			y = 0.0688 * safezoneH + safezoneY;
			w = 1.06219 * safezoneW;
			h = 0.869 * safezoneH;
		};
		class A3L_CCTV_Prev: RscButton
		{
			idc = 1600;
			x = 0.402031 * safezoneW + safezoneX;
			y = 0.841 * safezoneH + safezoneY;
			w = 0.0773437 * safezoneW;
			h = 0.033 * safezoneH;
			action = "closedialog 0; [] call A3L_fnc_switchPrevCam;";
		};
		class A3L_CCTV_Next: RscButton
		{
			idc = 1601;
			x = 0.525781 * safezoneW + safezoneX;
			y = 0.841 * safezoneH + safezoneY;
			w = 0.0773437 * safezoneW;
			h = 0.033 * safezoneH;
			action = "closedialog 0; [] call A3L_fnc_switchNextCam;";
		};
		class A3L_CCTV_Close: RscButton
		{
			idc = 1602;
			x = 0.484531 * safezoneW + safezoneX;
			y = 0.841 * safezoneH + safezoneY;
			w = 0.0360937 * safezoneW;
			h = 0.033 * safezoneH;
			action = "closedialog 0; [] call A3L_fnc_destroyCam;";
		};
		////////////////////////////////////////////////////////
		// GUI EDITOR OUTPUT END
		////////////////////////////////////////////////////////
	};
};

class a3l_cctv_doc_cam3
{
	idd=-1;
	onUnload = "_this call a3l_fnc_destroycam;";
	movingEnable = 0;

	class controls
	{
		////////////////////////////////////////////////////////
		// GUI EDITOR OUTPUT START (by Oscar Gigsta, v1.063, #Zefehy)
		////////////////////////////////////////////////////////

		class A3L_CCTV_Overlay: RscPicture
		{
			idc = 1200;
			text = "\A3L_Client2\images\cam_3.paa";
			x = -0.035425 * safezoneW + safezoneX;
			y = 0.0688 * safezoneH + safezoneY;
			w = 1.06219 * safezoneW;
			h = 0.869 * safezoneH;
		};
		class A3L_CCTV_Prev: RscButton
		{
			idc = 1600;
			x = 0.402031 * safezoneW + safezoneX;
			y = 0.841 * safezoneH + safezoneY;
			w = 0.0773437 * safezoneW;
			h = 0.033 * safezoneH;
			action = "closedialog 0; [] call A3L_fnc_switchPrevCam;";
		};
		class A3L_CCTV_Next: RscButton
		{
			idc = 1601;
			x = 0.525781 * safezoneW + safezoneX;
			y = 0.841 * safezoneH + safezoneY;
			w = 0.0773437 * safezoneW;
			h = 0.033 * safezoneH;
			action = "closedialog 0; [] call A3L_fnc_switchNextCam;";
		};
		class A3L_CCTV_Close: RscButton
		{
			idc = 1602;
			x = 0.484531 * safezoneW + safezoneX;
			y = 0.841 * safezoneH + safezoneY;
			w = 0.0360937 * safezoneW;
			h = 0.033 * safezoneH;
			action = "closedialog 0; [] call A3L_fnc_destroyCam;";
		};
		////////////////////////////////////////////////////////
		// GUI EDITOR OUTPUT END
		////////////////////////////////////////////////////////
	};
};

class a3l_cctv_doc_cam4
{
	idd=-1;
	onUnload = "_this call a3l_fnc_destroycam;";
	movingEnable = 0;

	class controls
	{
		////////////////////////////////////////////////////////
		// GUI EDITOR OUTPUT START (by Oscar Gigsta, v1.063, #Zefehy)
		////////////////////////////////////////////////////////

		class A3L_CCTV_Overlay: RscPicture
		{
			idc = 1200;
			text = "\A3L_Client2\images\cam_4.paa";
			x = -0.035425 * safezoneW + safezoneX;
			y = 0.0688 * safezoneH + safezoneY;
			w = 1.06219 * safezoneW;
			h = 0.869 * safezoneH;
		};
		class A3L_CCTV_Prev: RscButton
		{
			idc = 1600;
			x = 0.402031 * safezoneW + safezoneX;
			y = 0.841 * safezoneH + safezoneY;
			w = 0.0773437 * safezoneW;
			h = 0.033 * safezoneH;
			action = "closedialog 0; [] call A3L_fnc_switchPrevCam;";
		};
		class A3L_CCTV_Next: RscButton
		{
			idc = 1601;
			x = 0.525781 * safezoneW + safezoneX;
			y = 0.841 * safezoneH + safezoneY;
			w = 0.0773437 * safezoneW;
			h = 0.033 * safezoneH;
			action = "closedialog 0; [] call A3L_fnc_switchNextCam;";
		};
		class A3L_CCTV_Close: RscButton
		{
			idc = 1602;
			x = 0.484531 * safezoneW + safezoneX;
			y = 0.841 * safezoneH + safezoneY;
			w = 0.0360937 * safezoneW;
			h = 0.033 * safezoneH;
			action = "closedialog 0; [] call A3L_fnc_destroyCam;";
		};
		////////////////////////////////////////////////////////
		// GUI EDITOR OUTPUT END
		////////////////////////////////////////////////////////
	};
};

class a3l_cctv_doc_cam5
{
	idd=-1;
	onUnload = "_this call a3l_fnc_destroycam;";
	movingEnable = 0;

	class controls
	{
		////////////////////////////////////////////////////////
		// GUI EDITOR OUTPUT START (by Oscar Gigsta, v1.063, #Zefehy)
		////////////////////////////////////////////////////////

		class A3L_CCTV_Overlay: RscPicture
		{
			idc = 1200;
			text = "\A3L_Client2\images\cam_5.paa";
			x = -0.035425 * safezoneW + safezoneX;
			y = 0.0688 * safezoneH + safezoneY;
			w = 1.06219 * safezoneW;
			h = 0.869 * safezoneH;
		};
		class A3L_CCTV_Prev: RscButton
		{
			idc = 1600;
			x = 0.402031 * safezoneW + safezoneX;
			y = 0.841 * safezoneH + safezoneY;
			w = 0.0773437 * safezoneW;
			h = 0.033 * safezoneH;
			action = "closedialog 0; [] call A3L_fnc_switchPrevCam;";
		};
		class A3L_CCTV_Next: RscButton
		{
			idc = 1601;
			x = 0.525781 * safezoneW + safezoneX;
			y = 0.841 * safezoneH + safezoneY;
			w = 0.0773437 * safezoneW;
			h = 0.033 * safezoneH;
			action = "closedialog 0; [] call A3L_fnc_switchNextCam;";
		};
		class A3L_CCTV_Close: RscButton
		{
			idc = 1602;
			x = 0.484531 * safezoneW + safezoneX;
			y = 0.841 * safezoneH + safezoneY;
			w = 0.0360937 * safezoneW;
			h = 0.033 * safezoneH;
			action = "closedialog 0; [] call A3L_fnc_destroyCam;";
		};
		////////////////////////////////////////////////////////
		// GUI EDITOR OUTPUT END
		////////////////////////////////////////////////////////
	};
};

class a3l_cctv_doc_cam6
{
	idd=-1;
	onUnload = "_this call a3l_fnc_destroycam;";
	movingEnable = 0;

	class controls
	{
		////////////////////////////////////////////////////////
		// GUI EDITOR OUTPUT START (by Oscar Gigsta, v1.063, #Zefehy)
		////////////////////////////////////////////////////////

		class A3L_CCTV_Overlay: RscPicture
		{
			idc = 1200;
			text = "\A3L_Client2\images\cam_6.paa";
			x = -0.035425 * safezoneW + safezoneX;
			y = 0.0688 * safezoneH + safezoneY;
			w = 1.06219 * safezoneW;
			h = 0.869 * safezoneH;
		};
		class A3L_CCTV_Prev: RscButton
		{
			idc = 1600;
			x = 0.402031 * safezoneW + safezoneX;
			y = 0.841 * safezoneH + safezoneY;
			w = 0.0773437 * safezoneW;
			h = 0.033 * safezoneH;
			action = "closedialog 0; [] call A3L_fnc_switchPrevCam;";
		};
		class A3L_CCTV_Next: RscButton
		{
			idc = 1601;
			x = 0.525781 * safezoneW + safezoneX;
			y = 0.841 * safezoneH + safezoneY;
			w = 0.0773437 * safezoneW;
			h = 0.033 * safezoneH;
			action = "closedialog 0; [] call A3L_fnc_switchNextCam;";
		};
		class A3L_CCTV_Close: RscButton
		{
			idc = 1602;
			x = 0.484531 * safezoneW + safezoneX;
			y = 0.841 * safezoneH + safezoneY;
			w = 0.0360937 * safezoneW;
			h = 0.033 * safezoneH;
			action = "closedialog 0; [] call A3L_fnc_destroyCam;";
		};
		////////////////////////////////////////////////////////
		// GUI EDITOR OUTPUT END
		////////////////////////////////////////////////////////
	};
};

class a3l_cctv_doc_cam7
{
	idd=-1;
	onUnload = "_this call a3l_fnc_destroycam;";
	movingEnable = 0;

	class controls
	{
		////////////////////////////////////////////////////////
		// GUI EDITOR OUTPUT START (by Oscar Gigsta, v1.063, #Zefehy)
		////////////////////////////////////////////////////////

		class A3L_CCTV_Overlay: RscPicture
		{
			idc = 1200;
			text = "\A3L_Client2\images\cam_7.paa";
			x = -0.035425 * safezoneW + safezoneX;
			y = 0.0688 * safezoneH + safezoneY;
			w = 1.06219 * safezoneW;
			h = 0.869 * safezoneH;
		};
		class A3L_CCTV_Prev: RscButton
		{
			idc = 1600;
			x = 0.402031 * safezoneW + safezoneX;
			y = 0.841 * safezoneH + safezoneY;
			w = 0.0773437 * safezoneW;
			h = 0.033 * safezoneH;
			action = "closedialog 0; [] call A3L_fnc_switchPrevCam;";
		};
		class A3L_CCTV_Next: RscButton
		{
			idc = 1601;
			x = 0.525781 * safezoneW + safezoneX;
			y = 0.841 * safezoneH + safezoneY;
			w = 0.0773437 * safezoneW;
			h = 0.033 * safezoneH;
			action = "closedialog 0; [] call A3L_fnc_switchNextCam;";
		};
		class A3L_CCTV_Close: RscButton
		{
			idc = 1602;
			x = 0.484531 * safezoneW + safezoneX;
			y = 0.841 * safezoneH + safezoneY;
			w = 0.0360937 * safezoneW;
			h = 0.033 * safezoneH;
			action = "closedialog 0; [] call A3L_fnc_destroyCam;";
		};
		////////////////////////////////////////////////////////
		// GUI EDITOR OUTPUT END
		////////////////////////////////////////////////////////
	};
};