/*
*    FORMAT:
*        STRING (Conditions) - Must return boolean :
*            String can contain any amount of conditions, aslong as the entire
*            string returns a boolean. This allows you to check any levels, licenses etc,
*            in any combination. For example:
*                "call life_coplevel && license_civ_someLicense"
*            This will also let you call any other function.
*/
class VirtualShops {
    //Virtual Shops
    class market {
        name = "STR_Shops_Market";
        side = "";
        conditions = "";
        items[] = 
        { 
            "cellphone",
            "cigarette", 
            "vapefury", 
            "vaperainbowunicorn", 
            "vapehillaryclinton", 
            "vapegalaxymilk", 
            "vapetwistedberry", 
            "zoobeer",
            "raxrum",
            "waterBottle",
            "rabbit",
            "batterypack",
            "apple",
            "redgull",
            "tbacon",
            "lockpick",
            "blindfold",
            "zipties",
            "pickaxe",
            "fuelFull",
            "peach",
            "boltcutter",
            "storagesmall",
            "storagebig",
            "Earplugs",
            "defibrillator"
        };
    };

    class farmingmarket {
        name = "Farmers Market";
        side = "civ";
        conditions = "";
        items[] = 
        { 
            "wheatseed",
            "sunflowerseed",
            "cornseed",
            "beanseed",
            "cottonseed",
            "pumpkinseed",
            "oliveseed",
            "wheat",
            "sunflower",
            "corn",
            "bean",
            "cotton",
            "pumpkin",
            "olive"
        };
    };

    class TacoBell {
        name = "Taco Bell";
        side = "";
        conditions = "";
        items[] = 
        { 
            "taco",
            "burrito",
            "quesadilla",
            "eddiestacosupreme",
            "mexicanpizza",
            "nachos",
            "olipepper",
            "bajablast"
        };
    };

    class KrispyKreme {
        name = "Krispy Kreme";
        side = "";
        conditions = "";
        items[] = 
        { 
            "Kookies_n_Kreme",
            "Red_Velvet",
            "Chocolate_Iced",
            "Snowman_Donut",
            "Glazed_Donut",
            "Ice_Cream_Slider",
            "Chocolate_MilkShake"
        };
    };

    class butcher {
        name = "Butcher Shop";
        side = "civ";
        conditions = "";
        items[] = 
        { 
            "hen",
            "hen_raw",
            "rooster",
            "rooster_raw",
            "sheep",
            "sheep_raw",
            "goat",
            "goat_raw",
            "rabbit",
            "rabbit_raw"
        };
    };

    class ems {
        name = "STR_Shops_Market";
        side = "med";
        conditions = "";
        items[] = 
        {
            "cellphone",
            "donuts",
            "coffee",
            "waterBottle",
            "rabbit",
            "apple",
            "redgull",
            "vapefury", 
            "vaperainbowunicorn", 
            "vapehillaryclinton", 
            "vapegalaxymilk", 
            "vapetwistedberry", 
            "tbacon",
            "batterypack",
            "peach",
            "Earplugs",
            "fuelFull",
            "jawsoflife",
            "RoadBlockConc",
            "RoadBlockWood",
            "RoadCone",
            "RoadConeStrip",
            "RoadConeB",
            "RoadConeStripB"
        };
    };

    class rebel {
        name = "STR_Shops_Rebel";
        side = "civ";
        conditions = "license_civ_rebel";
        items[] = 
        { 
            "cellphone",
            "cigarette", 
            "vapefury", 
            "vaperainbowunicorn", 
            "vapehillaryclinton", 
            "vapegalaxymilk", 
            "vapetwistedberry",
            "waterBottle",
            "redgull",
            "rabbit",
            "apple",
            "peach",
            "tbacon",
            "batterypack",
            "Earplugs",
            "lockpick",
            "pickaxe",
            "fuelFull",
            "boltcutter",
            "blastingcharge",
            "hackingdevice",
            "blindfold",
            "zipties",
            "storagesmall",
            "storagebig",
            "defibrillator"
        };
    };

    class gang {
        name = "STR_Shops_Gang";
        side = "civ";
        conditions = "";
        items[] = 
        { 
            "cellphone",
            "cigarette", 
            "vapefury", 
            "vaperainbowunicorn", 
            "vapehillaryclinton", 
            "vapegalaxymilk", 
            "vapetwistedberry",
            "waterBottle",
            "redgull",
            "rabbit",
            "apple",
            "peach",
            "tbacon",
            "batterypack",
            "Earplugs",
            "lockpick",
            "pickaxe",
            "fuelFull",
            "boltcutter",
            "blastingcharge",
            "hackingdevice",
            "defibrillator"
        };
    };

    class uranium {
        name = "STR_Shops_Uranium";
        side = "civ";
        conditions = "";
        items[] = { "uranium_refined" };
    };

    class wongs {
        name = "STR_Shops_Wongs";
        side = "civ";
        conditions = "";
        items[] = { "turtle_soup", "turtle_raw" };
    };

    class coffee {
        name = "STR_Shops_Coffee";
        side = "";
        conditions = "";
        items[] = { "coffee", "donuts" };
    };

    class f_station_coffee {
        name = "STR_Shop_Station_Coffee";
        side = "";
        conditions = "";
        items[] = { "coffee", "donuts", "redgull", "toolkit", "fuelFull"};
    };

    class drugdealer {
        name = "STR_Shops_DrugDealer";
        side = "civ";
        conditions = "";
        items[] = { "cocaine_processed", "heroin_processed", "marijuana" };
    };

    class heroin {
        name = "STR_Shops_DrugDealer";
        side = "civ";
        conditions = "";
        items[] = {
                        "cannabisseeds", 
                        "opiumseeds",
                        "heroin_processed", 
                        "marijuana" 
                    };
    };

    class oil {
        name = "STR_Shops_Oil";
        side = "civ";
        conditions = "";
        items[] = { "oil_processed", "pickaxe", "fuelFull" };
    };

    class fishmarket {
        name = "STR_Shops_FishMarket";
        side = "civ";
        conditions = "";
        items[] = { "salema_raw", "salema", "ornate_raw", "ornate", "mackerel_raw", "mackerel", "tuna_raw", "tuna", "mullet_raw", "mullet", "catshark_raw", "catshark" };
    };

    class glass {
        name = "STR_Shops_Glass";
        side = "civ";
        conditions = "";
        items[] = { "glass" };
    };

    class iron  {
        name = "STR_Shops_Minerals";
        side = "civ";
        conditions = "";
        items[] = { "iron_refined", "copper_refined" };
    };

    class diamond {
        name = "STR_Shops_Diamond";
        side = "civ";
        conditions = "";
        items[] = { "diamond_uncut", "diamond_cut" };
    };

    class salt {
        name = "STR_Shops_Salt";
        side = "civ";
        conditions = "";
        items[] = { "salt_refined" };
    };

    class cement {
        name = "STR_Shops_Cement";
        side = "civ";
        conditions = "";
        items[] = { "cement" };
    };

    class gold {
        name = "STR_Shops_Gold";
        side = "civ";
        conditions = "";
        items[] = { "goldbar" };
    };

    class cop {
        name = "STR_Shops_Cop";
        side = "cop";
        conditions = "";
        items[] = 
        { 
            "cellphone",
            "donuts",
            "coffee",
            "cigarette",
            "spikeStrip",
            "waterBottle",
            "batterypack",
            "rabbit",
            "apple",
            "redgull",
            "vapefury", 
            "vaperainbowunicorn", 
            "vapehillaryclinton", 
            "vapegalaxymilk", 
            "vapetwistedberry", 
            "fuelFull",
            "Earplugs",
            "defusekit",
            "BarGate",
            "RoadBlockConc",
            "RoadBlockWood",
            "RoadCone",
            "RoadConeStrip",
            "RoadConeB",
            "RoadConeStripB",
            "huntinglicense",
            "fishinglicense",
            "defibrillator"
        };
    };

    class doj {
        name = "Department of Justice";
        side = "civ";
        conditions = "";
        items[] = 
        { 
            "cellphone",
            "cigarette", 
            "vapefury", 
            "vaperainbowunicorn", 
            "vapehillaryclinton", 
            "vapegalaxymilk", 
            "vapetwistedberry",
            "waterBottle",
            "rabbit",
            "batterypack",
            "apple",
            "redgull",
            "tbacon",
            "pickaxe",
            "fuelFull",
            "peach",
            "Earplugs",
            "defibrillator"
        };
    };

    class resource {
        name = "Resource Trader";
        side = "civ";
        conditions = "";
        items[] = 
        { 
            "normalrock",
            "ironrock",
            "diamondrock",
            "paperlog",
            "olivelog",
            "ficuslog"
        };
    };

    class blackmarket {
        name = "Black Market";
        side = "civ";
        conditions = "";
        items[] = 
        { 
            "kidney"
        };
    };

};

/*
*    CLASS:
*        variable = Variable Name
*        displayName = Item Name
*        weight = Item Weight
*        buyPrice = Item Buy Price
*        sellPrice = Item Sell Price
*        illegal = Illegal Item
*        edible = Item Edible (-1 = Disabled)
*        icon = Item Icon
*        processedItem = Processed Item
*/
class VirtualItems {
    //Virtual Items

    //Tim's Additions
    //Illegal Shit

    class kidney {
        variable = "kidney";
        displayName = "STR_Item_Kidney";
        weight = 5;
        buyPrice = 25000;
        sellPrice = 10000;
        illegal = true;
        edible = -1;
        icon = "\A3L_Client2\icons\ico_rabbitRaw";
    };

    class blastingcharge {
        variable = "blastingCharge";
        displayName = "STR_Item_BCharge";
        weight = 15;
        buyPrice = 25000;
        sellPrice = 15000;
        illegal = true;
        edible = -1;
        icon = "\A3L_Client2\icons\ico_blastingCharge.paa";
    };

    class hackingdevice {
        variable = "hackingdevice";
        displayName = "STR_Item_HackDev";
        weight = 15;
        buyPrice = 25000;
        sellPrice = 15000;
        illegal = true;
        edible = -1;
        icon = "\A3L_Client2\icons\ico_blastingCharge.paa";
    };

    class spikeStrip {
        variable = "spikeStrip";
        displayName = "STR_Item_SpikeStrip";
        weight = 2;
        buyPrice = 250;
        sellPrice = 120;
        illegal = true;
        edible = -1;
        icon = "\A3L_Client2\icons\ico_spikeStrip.paa";
    };

    class lockpick {
        variable = "lockpick";
        displayName = "STR_Item_Lockpick";
        weight = 1;
        buyPrice = 150;
        sellPrice = 75;
        illegal = true;
        edible = -1;
        icon = "\A3L_Client2\icons\ico_lockpick.paa";
    };

    class boltcutter {
        variable = "boltCutter";
        displayName = "STR_Item_BCutter";
        weight = 5;
        buyPrice = 750;
        sellPrice = 100;
        illegal = true;
        edible = -1;
        icon = "\A3L_Client2\icons\ico_boltCutter.paa";
    };

    class blindfold {
        variable = "blindfold";
        displayName = "STR_Item_blindfold";
        weight = 2;
        buyPrice = 500;
        sellPrice = 100;
        illegal = true;
        edible = -1;
        icon = "\A3L_Client2\icons\ico_blindfold.paa";
    };

    class zipties {
        variable = "zipties";
        displayName = "STR_Item_zipties";
        weight = 2;
        buyPrice = 500;
        sellPrice = 100;
        illegal = true;
        edible = -1;
        icon = "\A3L_Client2\icons\ico_zipties.paa";
    };
    
    //Licenses
    class huntinglicense {
        variable = "huntinglicense";
        displayName = "STR_License_Hunting";
        weight = 1;
        buyPrice = 100;
        sellPrice = 10;
        illegal = false;
        edible = -1;
        icon = "";
    };

    class fishinglicense {
        variable = "fishinglicense";
        displayName = "STR_License_Fishing";
        weight = 1;
        buyPrice = 100;
        sellPrice = 10;
        illegal = false;
        edible = -1;
        icon = "";
    };

    //Regular stuff
    class bandage {
        variable = "bandage";
        displayName = "STR_Item_Bandage";
        weight = 1;
        buyPrice = 50;
        sellPrice = 10;
        illegal = false;
        edible = -1;
        icon = "";
    };

    class Earplugs {
        variable = "Earplugs";
        displayName = "STR_Item_EarPlugs";
        weight = 1;
        buyPrice = 50;
        sellPrice = 10;
        illegal = false;
        edible = -1;
        icon = "\A3L_Client2\icons\ico_earplugs.paa";
    };

    class cigarette {
        variable = "cigarette";
        displayName = "STR_Item_Cig";
        weight = 1;
        buyPrice = 25;
        sellPrice = 10;
        illegal = false;
        edible = -1;
        icon = "\A3L_Client2\icons\ico_cigs.paa";
    };

    class batterypack {
        variable = "batterypack";
        displayName = "STR_Item_batterypack";
        weight = 1;
        buyPrice = 100;
        sellPrice = 50;
        illegal = false;
        edible = -1;
        icon = "\A3L_Client2\icons\ico_batterypack.paa";
    };

    class cellphone {
        variable = "cellphone";
        displayName = "STR_Item_Cellphone";
        weight = 1;
        buyPrice = 35;
        sellPrice = 10;
        illegal = false;
        edible = -1;
        icon = "\A3L_Client2\icons\ico_cellphone.paa";
    };

    //Tools
    class pickaxe {
        variable = "pickaxe";
        displayName = "STR_Item_Pickaxe";
        weight = 2;
        buyPrice = 750;
        sellPrice = 350;
        illegal = false;
        edible = -1;
        icon = "\A3L_Client2\icons\ico_pickaxe.paa";
    };

    class toolkit {
        variable = "toolkit";
        displayName = "STR_Item_Toolkit";
        weight = 4;
        buyPrice = 350;
        sellPrice = 100;
        illegal = false;
        edible = -1;
        icon = "\a3\weapons_f\items\data\UI\gear_toolkit_ca.paa";
    };

    class jawsoflife {
        variable = "jawsoflife";
        displayName = "STR_Item_JawsofLife";
        weight = 4;
        buyPrice = 35;
        sellPrice = 10;
        illegal = false;
        edible = -1;
        icon = "\A3l_Client2\icons\ico_jawsoflife.paa";
    };

    class defusekit {
        variable = "defuseKit";
        displayName = "STR_Item_DefuseKit";
        weight = 2;
        buyPrice = 250;
        sellPrice = 200;
        illegal = true;
        edible = -1;
        icon = "\A3L_Client2\icons\ico_defuseKit.paa";
    };

    //Roadblocks and Roadcones
    class BarGate {
        variable = "BarGate";
        displayName = "STR_Item_PoliceBG";
        weight = 5;
        buyPrice = 35;
        sellPrice = 10;
        illegal = false;
        edible = -1;
        icon = "\A3L_Client2\icons\ico_bargate.paa";
    };

    class RoadBlockReb {
        variable = "RoadBlockReb";
        displayName = "STR_Item_RoadBlockR";
        weight = 5;
        buyPrice = 10000;
        sellPrice = 2000;
        illegal = true;
        edible = -1;
        icon = "\A3l_Client2\icons\ico_roadblockreb.paa";
    };

    class RoadBlockConc {
        variable = "RoadBlockConc";
        displayName = "STR_Item_RoadBlockC";
        weight = 25;
        buyPrice = 100;
        sellPrice = 10;
        illegal = false;
        edible = -1;
        icon = "\A3L_Client2\icons\ico_barrierC.paa";
    };

    class RoadBlockWood {
        variable = "RoadBlockWood";
        displayName = "STR_Item_RoadBlockW";
        weight = 15;
        buyPrice = 50;
        sellPrice = 10;
        illegal = false;
        edible = -1;
        icon = "\A3l_Client2\icons\ico_roadblockwood.paa";
    };

    class RoadCone {
        variable = "RoadCone";
        displayName = "STR_Item_RoadCone";
        weight = 2;
        buyPrice = 35;
        sellPrice = 10;
        illegal = false;
        edible = -1;
        icon = "\A3L_Client2\icons\ico_roadcone.paa";
    };

    class RoadConeStrip {
        variable = "RoadConeStrip";
        displayName = "STR_Item_RoadConeStrip";
        weight = 5;
        buyPrice = 50;
        sellPrice = 10;
        illegal = false;
        edible = -1;
        icon = "\A3L_Client2\icons\ico_roadconestrip.paa";
    };

    class RoadConeB {
        variable = "RoadConeB";
        displayName = "STR_Item_RoadConeB";
        weight = 2;
        buyPrice = 35;
        sellPrice = 10;
        illegal = false;
        edible = -1;
        icon = "\A3L_Client2\icons\ico_roadconeB.paa";
    };

     class RoadConeStripB {
        variable = "RoadConeStripB";
        displayName = "STR_Item_RoadConeStripB";
        weight = 5;
        buyPrice = 50;
        sellPrice = 10;
        illegal = false;
        edible = -1;
        icon = "\A3L_Client2\icons\ico_roadconeBstrip.paa";
    };

    //Food
    //Taco Bell Food
     class taco {
        variable = "taco";
        displayName = "STR_Item_VagTaco";
        weight = 1;
        buyPrice = 50;
        sellPrice = 20;
        illegal = false;
        edible = 100;
        icon = "\A3l_Client2\icons\ico_taco.paa";
    };

    class burrito {
        variable = "burrito";
        displayName = "STR_Item_Burrito";
        weight = 1;
        buyPrice = 30;
        sellPrice = 20;
        illegal = false;
        edible = 100;
        icon = "\A3l_Client2\icons\ico_burrito.paa";
    };

    class quesadilla {
        variable = "quesadilla";
        displayName = "STR_Item_Kaysodilla";
        weight = 1;
        buyPrice = 60;
        sellPrice = 20;
        illegal = false;
        edible = 100;
        icon = "\A3l_Client2\icons\ico_quesadilla.paa";
    };

    class eddiestacosupreme {
        variable = "eddiestacosupreme";
        displayName = "STR_Item_TacoSUPREME";
        weight = 1;
        buyPrice = 100;
        sellPrice = 20;
        illegal = false;
        edible = 100;
        icon = "\A3l_Client2\icons\ico_eddiestacosupreme.paa";
    };

    class mexicanpizza {
        variable = "mexicanpizza";
        displayName = "STR_Item_MaxPizza";
        weight = 1;
        buyPrice = 75;
        sellPrice = 20;
        illegal = false;
        edible = 100;
        icon = "\A3l_Client2\icons\ico_mexicanpizza.paa";
    };

    class nachos {
        variable = "nachos";
        displayName = "STR_Item_Notchyos";
        weight = 1;
        buyPrice = 75;
        sellPrice = 20;
        illegal = false;
        edible = 100;
        icon = "\A3l_Client2\icons\ico_nachos.paa";
    };

    class olipepper {
        variable = "olipepper";
        displayName = "STR_Item_OliPepe";
        weight = 1;
        buyPrice = 15;
        sellPrice = 10;
        illegal = false;
        edible = 100;
        icon = "\A3l_Client2\icons\ico_olipepper.paa";
    };

    class bajablast {
        variable = "bajablast";
        displayName = "STR_Item_BajaB";
        weight = 1;
        buyPrice = 15;
        sellPrice = 10;
        illegal = false;
        edible = 100;
        icon = "\A3l_Client2\icons\ico_bajablast.paa";
    };
    
    //KrispyKreme
    class Kookies_n_Kreme {
        variable = "Kookies_n_Kreme";
        displayName = "STR_Item_KK";
        weight = 1;
        buyPrice = 65;
        sellPrice = 50;
        illegal = false;
        edible = 20;
        icon = "\A3l_Client2\icons\ico_kookiesnkreme.paa";
    };

    class Red_Velvet {
        variable = "Red_Velvet";
        displayName = "STR_Item_RedV";
        weight = 1;
        buyPrice = 65;
        sellPrice = 50;
        illegal = false;
        edible = 40;
        icon = "\A3l_Client2\icons\ico_redvelvet.paa";
    };

    class Chocolate_Iced {
        variable = "Chocolate_Iced";
        displayName = "STR_Item_ChocoIce";
        weight = 1;
        buyPrice = 55;
        sellPrice = 30;
        illegal = false;
        edible = 20;
        icon = "\A3l_Client2\icons\ico_chocolateiced.paa";
    };

    class Snowman_Donut {
        variable = "Snowman_Donut";
        displayName = "STR_Item_SnoDo";
        weight = 1;
        buyPrice = 30;
        sellPrice = 10;
        illegal = false;
        edible = 25;
        icon = "\A3l_Client2\icons\ico_snowmandonut.paa";
    };

    class Glazed_Donut {
        variable = "Glazed_Donut";
        displayName = "STR_Item_SnoDo";
        weight = 1;
        buyPrice = 40;
        sellPrice = 10;
        illegal = false;
        edible = 25;
        icon = "\A3l_Client2\icons\ico_glazeddonut.paa";
    };

    class Ice_Cream_Slider {
        variable = "Ice_Cream_Slider";
        displayName = "STR_Item_IceSlide";
        weight = 1;
        buyPrice = 50;
        sellPrice = 10;
        illegal = false;
        edible = 25;
        icon = "\A3l_Client2\icons\ico_icecreamslider.paa";
    };

    class Chocolate_MilkShake {
        variable = "Chocolate_MilkShake";
        displayName = "STR_Item_DarkChocoMLK";
        weight = 1;
        buyPrice = 50;
        sellPrice = 10;
        illegal = false;
        edible = 65;
        icon = "\A3l_Client2\icons\ico_chocmilk.paa.paa";
    };

    //Tree Farming
    class olivelog {
        variable = "olivelog";
        displayName = "STR_Item_olivelog";
        weight = 3;
        buyPrice = -1;
        sellPrice = 1084;
        illegal = false;
        edible = -1;
        icon = "\A3l_Client2\icons\ico_olive_log.paa";
    };

    class paperlog {
        variable = "paperlog";
        displayName = "STR_Item_Paperlog";
        weight = 3;
        buyPrice = -1;
        sellPrice = 1084;
        illegal = false;
        edible = -1;
        icon = "\A3l_Client2\icons\ico_paper_log.paa";
    };

    class ficuslog {
        variable = "ficuslog";
        displayName = "STR_Item_ficuslog";
        weight = 3;
        buyPrice = -1;
        sellPrice = 1084;
        illegal = false;
        edible = -1;
        icon = "\A3l_Client2\icons\ico_fiscus_log.paa";
    };

    //Rock Trader
    class normalrock {
        variable = "normalrock";
        displayName = "Normal Rock";
        weight = 3;
        buyPrice = -1;
        sellPrice = 1604;
        illegal = false;
        edible = -1;
        icon = "\A3l_Client2\icons\ico_norm_rock.paa";
    };

    class copperrock {
        variable = "copperrock";
        displayName = "Copper Rock";
        weight = 3;
        buyPrice = -1;
        sellPrice = 2204;
        illegal = false;
        edible = -1;
        icon = "\A3l_Client2\icons\ico_copper_rock.paa";
    };

    class ironrock {
        variable = "ironrock";
        displayName = "Iron Rock";
        weight = 3;
        buyPrice = -1;
        sellPrice = 3000;
        illegal = false;
        edible = -1;
        icon = "\A3l_Client2\icons\ico_iron_rock.paa";
    };

    class diamondrock {
        variable = "diamondrock";
        displayName = "Diamond Rock";
        weight = 3;
        buyPrice = -1;
        sellPrice = 4000;
        illegal = false;
        edible = -1;
        icon = "\A3l_Client2\icons\ico_diamond_rock.paa";
    };

    //Seeds
    class wheatseed {
        variable = "wheatseed";
        displayName = "STR_Item_wheatseeds";
        weight = 0.5;
        buyPrice = 30;
        sellPrice = 15;
        illegal = false;
        edible = -1;
        icon = "\A3l_Client2\icons\ico_seeds.paa";
    };

    class sunflowerseed {
        variable = "sunflowerseed";
        displayName = "STR_Item_sunflowerseeds";
        weight = 0.5;
        buyPrice = 30;
        sellPrice = 15;
        illegal = false;
        edible = -1;
        icon = "\A3l_Client2\icons\ico_seeds.paa";
    };

    class cornseed {
        variable = "cornseed";
        displayName = "STR_Item_cornseeds";
        weight = 0.5;
        buyPrice = 30;
        sellPrice = 15;
        illegal = false;
        edible = -1;
        icon = "\A3l_Client2\icons\ico_seeds.paa";
    };

    class beanseed {
        variable = "beanseed";
        displayName = "STR_Item_beanseeds";
        weight = 0.5;
        buyPrice = 30;
        sellPrice = 15;
        illegal = false;
        edible = -1;
        icon = "\A3l_Client2\icons\ico_seeds.paa";
    };

    class cottonseed {
        variable = "cottonseed";
        displayName = "STR_Item_cottonseeds";
        weight = 0.5;
        buyPrice = 30;
        sellPrice = 15;
        illegal = false;
        edible = -1;
        icon = "\A3l_Client2\icons\ico_seeds.paa";
    };

    class oliveseed {
        variable = "oliveseed";
        displayName = "STR_Item_oliveseeds";
        weight = 0.5;
        buyPrice = 30;
        sellPrice = 15;
        illegal = false;
        edible = -1;
        icon = "\A3l_Client2\icons\ico_seeds.paa";
    };

    class pumpkinseed {
        variable = "pumpkinseed";
        displayName = "STR_Item_pumpkinseeds";
        weight = 0.5;
        buyPrice = 30;
        sellPrice = 15;
        illegal = false;
        edible = -1;
        icon = "\A3l_Client2\icons\ico_seeds.paa";
    };

    //Legal Plants
    class wheat {
        variable = "wheat";
        displayName = "STR_Item_wheat";
        weight = 1;
        buyPrice = -1;
        sellPrice = 200;
        illegal = false;
        edible = -1;
        icon = "\A3l_Client2\icons\ico_wheat.paa";
    };

    class sunflower {
        variable = "sunflower";
        displayName = "STR_Item_sunflower";
        weight = 1;
        buyPrice = -1;
        sellPrice = 120;
        illegal = false;
        edible = -1;
        icon = "\A3l_Client2\icons\ico_sunflower.paa";
    };

    class corn {
        variable = "corn";
        displayName = "STR_Item_corn";
        weight = 1;
        buyPrice = -1;
        sellPrice = 225;
        illegal = false;
        edible = -1;
        icon = "\A3l_Client2\icons\ico_corn.paa";
    };

    class bean {
        variable = "bean";
        displayName = "STR_Item_bean";
        weight = 1;
        buyPrice = -1;
        sellPrice = 200;
        illegal = false;
        edible = -1;
        icon = "\A3l_Client2\icons\ico_bean.paa";
    };

    class cotton {
        variable = "cotton";
        displayName = "STR_Item_cotton";
        weight = 1;
        buyPrice = -1;
        sellPrice = 180;
        illegal = false;
        edible = -1;
        icon = "\A3l_Client2\icons\ico_cotton.paa";
    };

    class olive {
        variable = "olive";
        displayName = "STR_Item_olive";
        weight = 1;
        buyPrice = -1;
        sellPrice = 160;
        illegal = false;
        edible = -1;
        icon = "\A3l_Client2\icons\ico_olive.paa";
    };

    class pumpkin {
        variable = "pumpkin";
        displayName = "STR_Item_Pumpkin";
        weight = 2;
        buyPrice = -1;
        sellPrice = 350;
        illegal = false;
        edible = -1;
        icon = "\A3l_Client2\icons\ico_pumpkin.paa";
    };

    //End Tim's Additions 

    class defibrillator {
        variable = "defibrillator";
        displayName = "STR_Item_Defibrillator";
        weight = 8;
        buyPrice = 1000;
        sellPrice = 450;
        illegal = false;
        edible = -1;
        icon = "\A3L_Client2\icons\ico_defibrillator.paa";
    };

    class fuelEmpty {
        variable = "fuelEmpty";
        displayName = "STR_Item_FuelE";
        weight = 2;
        buyPrice = -1;
        sellPrice = 10;
        illegal = false;
        edible = -1;
        icon = "\A3L_Client2\icons\ico_fuelEmpty.paa";
    };

    class fuelFull {
        variable = "fuelFull";
        displayName = "STR_Item_FuelF";
        weight = 5;
        buyPrice = 850;
        sellPrice = 500;
        illegal = false;
        edible = -1;
        icon = "\A3L_Client2\icons\ico_fuel.paa";
    };

    class goldbar {
        variable = "goldBar";
        displayName = "STR_Item_GoldBar";
        weight = 12;
        buyPrice = -1;
        sellPrice = 7000;
        illegal = true;
        edible = -1;
        icon = "\A3L_Client2\icons\ico_goldBar.paa";
    };

    //House Storage
    class storagesmall {
        variable = "storageSmall";
        displayName = "STR_Item_StorageBS";
        weight = 5;
        buyPrice = 45000;
        sellPrice = 5000;
        illegal = false;
        edible = -1;
        icon = "\A3L_Client2\icons\ico_storageSmall.paa";
    };

    class storagebig {
        variable = "storageBig";
        displayName = "STR_Item_StorageBL";
        weight = 10;
        buyPrice = 55000;
        sellPrice = 6000;
        illegal = false;
        edible = -1;
        icon = "\A3L_Client2\icons\ico_storageBig.paa";
    };

    //Mined Items

    class uranium_unrefined {
        variable = "uraniumUnrefined";
        displayName = "STR_Item_UraniumOre";
        weight = 4;
        buyPrice = -1;
        sellPrice = 3000;
        illegal = true;
        edible = -1;
        icon = "";
    };

    class uranium_refined {
        variable = "uraniumRefined";
        displayName = "STR_Item_Uranium";
        weight = 4;
        buyPrice = 10000;
        sellPrice = 7250; //Optional Price
        illegal = true;
        edible = -1;
        icon = "";
    };  

    class oil_unprocessed {
        variable = "oilUnprocessed";
        displayName = "STR_Item_OilU";
        weight = 6;
        buyPrice = -1;
        sellPrice = -1;
        illegal = false;
        edible = -1;
        icon = "\A3L_Client2\icons\ico_oilUnprocessed.paa";
    };

    class oil_processed {
        variable = "oilProcessed";
        displayName = "STR_Item_OilP";
        weight = 4;
        buyPrice = -1;
        sellPrice = 1500;
        illegal = false;
        edible = -1;
        icon = "\A3L_Client2\icons\ico_oilProcessed.paa";
    };

    class copper_unrefined {
        variable = "copperUnrefined";
        displayName = "STR_Item_CopperOre";
        weight = 4;
        buyPrice = -1;
        sellPrice = -1;
        illegal = false;
        edible = -1;
        icon = "\A3L_Client2\icons\ico_copperOre.paa";
    };

    class copper_refined {
        variable = "copperRefined";
        displayName = "STR_Item_CopperIngot";
        weight = 3;
        buyPrice = -1;
        sellPrice = 630;
        illegal = false;
        edible = -1;
        icon = "\A3L_Client2\icons\ico_copper.paa";
    };

    class iron_unrefined {
        variable = "ironUnrefined";
        displayName = "STR_Item_IronOre";
        weight = 5;
        buyPrice = -1;
        sellPrice = -1;
        illegal = false;
        edible = -1;
        icon = "\A3L_Client2\icons\ico_ironOre.paa";
    };

    class iron_refined {
        variable = "ironRefined";
        displayName = "STR_Item_IronIngot";
        weight = 3;
        buyPrice = -1;
        sellPrice = 715;
        illegal = false;
        edible = -1;
        icon = "\A3L_Client2\icons\ico_iron.paa";
    };

    class salt_unrefined {
        variable = "saltUnrefined";
        displayName = "STR_Item_Salt";
        weight = 0.4;
        buyPrice = -1;
        sellPrice = -1;
        illegal = false;
        edible = -1;
        icon = "\A3L_Client2\icons\ico_saltUnprocessed.paa";
    };

    class salt_refined {
        variable = "saltRefined";
        displayName = "STR_Item_SaltR";
        weight = 0.2;
        buyPrice = -1;
        sellPrice = 100;
        illegal = false;
        edible = -1;
        icon = "\A3L_Client2\icons\ico_saltProcessed.paa";
    };

    class sand {
        variable = "sand";
        displayName = "STR_Item_Sand";
        weight = 3;
        buyPrice = -1;
        sellPrice = -1;
        illegal = false;
        edible = -1;
        icon = "\A3L_Client2\icons\ico_sand.paa";
    };

    class glass {
        variable = "glass";
        displayName = "STR_Item_Glass";
        weight = 1;
        buyPrice = -1;
        sellPrice = 550;
        illegal = false;
        edible = -1;
        icon = "\A3L_Client2\icons\ico_glass.paa";
    };

    class diamond_uncut {
        variable = "diamondUncut";
        displayName = "STR_Item_DiamondU";
        weight = 5;
        buyPrice = -1;
        sellPrice = 400;
        illegal = false;
        edible = -1;
        icon = "\A3L_Client2\icons\ico_diamondUncut.paa";
    };

    class diamond_cut {
        variable = "diamondCut";
        displayName = "STR_Item_DiamondC";
        weight = 4;
        buyPrice = -1;
        sellPrice = 830;
        illegal = false;
        edible = -1;
        icon = "\A3L_Client2\icons\ico_diamondCut.paa";
    };

    class rock {
        variable = "rock";
        displayName = "STR_Item_Rock";
        weight = 6;
        buyPrice = -1;
        sellPrice = -1;
        illegal = false;
        edible = -1;
        icon = "\A3L_Client2\icons\ico_rock.paa";
    };

    class cement {
        variable = "cement";
        displayName = "STR_Item_CementBag";
        weight = 5;
        buyPrice = -1;
        sellPrice = 580;
        illegal = false;
        edible = -1;
        icon = "\A3L_Client2\icons\ico_cement.paa";
    };

    //Drugs
    class opiumseeds {
        variable = "opiumseeds";
        displayName = "STR_Item_opiumS";
        weight = 1;
        buyPrice = 100;
        sellPrice = -1;
        illegal = true;
        edible = -1;
        icon = "\A3l_Client2\icons\ico_seeds.paa";
    };

    class heroin_unprocessed {
        variable = "heroinUnprocessed";
        displayName = "STR_Item_HeroinU";
        weight = 5;
        buyPrice = -1;
        sellPrice = 1050;
        illegal = true;
        edible = -1;
        icon = "\A3L_Client2\icons\ico_heroinUnprocessed.paa";
        processedItem = "heroin_processed";
    };

    class heroin_processed {
        variable = "heroinProcessed";
        displayName = "STR_Item_HeroinP";
        weight = 4;
        buyPrice = 5100;
        sellPrice = 2550;
        illegal = true;
        edible = -1;
        icon = "\A3L_Client2\icons\ico_heroinProcessed.paa";
    };

    class cannabisseeds {
        variable = "cannabisseeds";
        displayName = "STR_Item_cannabisS";
        weight = 1;
        buyPrice = 100;
        sellPrice = -1;
        illegal = true;
        edible = -1;
        icon = "\A3l_Client2\icons\ico_seeds.paa";
    };

    class cannabis {
        variable = "cannabis";
        displayName = "STR_Item_Cannabis";
        weight = 5;
        buyPrice = -1;
        sellPrice = 980;
        illegal = true;
        edible = -1;
        icon = "\A3L_Client2\icons\ico_cannabis.paa";
        processedItem = "marijuana";
    };

    class marijuana {
        variable = "marijuana";
        displayName = "STR_Item_Marijuana";
        weight = 4;
        buyPrice = 4300;
        sellPrice = 1850;
        illegal = true;
        edible = -1;
        icon = "\A3L_Client2\icons\ico_marijuana.paa";
    };

    class cocaineseeds {
        variable = "cocaineseeds";
        displayName = "STR_Item_cocaineS";
        weight = 1;
        buyPrice = 100;
        sellPrice = -1;
        illegal = true;
        edible = -1;
        icon = "\A3l_Client2\icons\ico_seeds.paa";
    };

    class cocaine_unprocessed {
        variable = "cocaineUnprocessed";
        displayName = "STR_Item_CocaineU";
        weight = 5;
        buyPrice = -1;
        sellPrice = 3280;
        illegal = true;
        edible = -1;
        icon = "\A3L_Client2\icons\ico_cocaineUnprocessed.paa";
        processedItem = "cocaine_processed";
    };

    class cocaine_processed {
        variable = "cocaineProcessed";
        displayName = "STR_Item_CocaineP";
        weight = 4;
        buyPrice = -1;
        sellPrice = 6195;
        illegal = true;
        edible = -1;
        icon = "\A3L_Client2\icons\ico_cocaineProcessed.paa";
    };

    //Drink
    class redgull {
        variable = "redgull";
        displayName = "STR_Item_RedGull";
        weight = 1;
        buyPrice = 50;
        sellPrice = 10;
        illegal = false;
        edible = 100;
        icon = "\A3L_Client2\icons\ico_redgull.paa";
    };

    class coffee {
        variable = "coffee";
        displayName = "STR_Item_Coffee";
        weight = 1;
        buyPrice = 10;
        sellPrice = 5;
        illegal = false;
        edible = 100;
        icon = "\A3L_Client2\icons\ico_coffee.paa";
    };

    class waterBottle {
        variable = "waterBottle";
        displayName = "STR_Item_WaterBottle";
        weight = 1;
        buyPrice = 10;
        sellPrice = 5;
        illegal = false;
        edible = 100;
        icon = "\A3L_Client2\icons\ico_waterBottle.paa";
    };

    //Beer and Alcohol
    class zoobeer {
        variable = "zoobeer";
        displayName = "STR_Item_ZooBeer";
        weight = 1;
        buyPrice = 100;
        sellPrice = 5;
        illegal = true;
        edible = 100;
        icon = "\A3l_Client2\icons\ico_beer.paa";
    };

    class raxrum {
        variable = "raxrum";
        displayName = "STR_Item_RaxRum";
        weight = 1;
        buyPrice = 100;
        sellPrice = 5;
        illegal = true;
        edible = 100;
        icon = "\A3l_Client2\icons\ico_rum.paa";
    };

    //Vape Juices
    class vapefury {
        variable = "vapefury";
        displayName = "STR_Item_VJFury";
        weight = 1;
        buyPrice = 100;
        sellPrice = 50;
        illegal = false;
        edible = -1;
        icon = "\A3l_Client2\icons\ico_vapej.paa";
    };

    class vaperainbowunicorn {
        variable = "vaperainbowunicorn";
        displayName = "STR_Item_VJUni";
        weight = 1;
        buyPrice = 100;
        sellPrice = 50;
        illegal = false;
        edible = -1;
        icon = "\A3l_Client2\icons\ico_vapej.paa";
    };

    class vapehillaryclinton {
        variable = "vapehillaryclinton";
        displayName = "STR_Item_VJHC";
        weight = 1;
        buyPrice = 100;
        sellPrice = 50;
        illegal = false;
        edible = -1;
        icon = "\A3l_Client2\icons\ico_vapej.paa";
    };

    class vapegalaxymilk {
        variable = "vapegalaxymilk";
        displayName = "STR_Item_VJGM";
        weight = 1;
        buyPrice = 100;
        sellPrice = 50;
        illegal = false;
        edible = -1;
        icon = "\A3l_Client2\icons\ico_vapej.paa";
    };

    class vapetwistedberry {
        variable = "vapetwistedberry";
        displayName = "STR_Item_VJTB";
        weight = 1;
        buyPrice = 100;
        sellPrice = 50;
        illegal = false;
        edible = -1;
        icon = "\A3l_Client2\icons\ico_vapej.paa";
    };

    //Food
    class apple {
        variable = "apple";
        displayName = "STR_Item_Apple";
        weight = 1;
        buyPrice = 65;
        sellPrice = 15;
        illegal = false;
        edible = 10;
        icon = "\A3L_Client2\icons\ico_apple.paa";
    };

    class peach {
        variable = "peach";
        displayName = "STR_Item_Peach";
        weight = 1;
        buyPrice = 68;
        sellPrice = 55;
        illegal = false;
        edible = 10;
        icon = "\A3L_Client2\icons\ico_peach.paa";
    };

    class tbacon {
        variable = "tbacon";
        displayName = "STR_Item_TBacon";
        weight = 1;
        buyPrice = 55;
        sellPrice = 25;
        illegal = false;
        edible = 40;
        icon = "\A3L_Client2\icons\ico_tBacon.paa";
    };

    class donuts {
        variable = "donuts";
        displayName = "STR_Item_Donuts";
        weight = 1;
        buyPrice = 50;
        sellPrice = 20;
        illegal = false;
        edible = 30;
        icon = "\A3L_Client2\icons\ico_donuts.paa";
    };

    class rabbit_raw {
        variable = "rabbitRaw";
        displayName = "STR_Item_RabbitRaw";
        weight = 1;
        buyPrice = -1;
        sellPrice = 890;
        illegal = false;
        edible = -1;
        icon = "\A3L_Client2\icons\ico_rabbitRaw.paa";
    };

    class rabbit {
        variable = "rabbit";
        displayName = "STR_Item_Rabbit";
        weight = 1;
        buyPrice = 350;
        sellPrice = -1;
        illegal = false;
        edible = 20;
        icon = "\A3L_Client2\icons\ico_rabbit.paa";
    };

    class salema_raw {
        variable = "salemaRaw";
        displayName = "STR_Item_SalemaRaw";
        weight = 1;
        buyPrice = -1;
        sellPrice = 365;
        illegal = false;
        edible = -1;
        icon = "\A3L_Client2\icons\ico_salemaRaw.paa";
    };

    class salema {
        variable = "salema";
        displayName = "STR_Item_Salema";
        weight = 1;
        buyPrice = -1;
        sellPrice = 600;
        illegal = false;
        edible = 30;
        icon = "\A3L_Client2\icons\ico_cookedFish.paa";
    };

    class ornate_raw {
        variable = "ornateRaw";
        displayName = "STR_Item_OrnateRaw";
        weight = 1;
        buyPrice = -1;
        sellPrice = 460;
        illegal = false;
        edible = -1;
        icon = "\A3L_Client2\icons\ico_ornateRaw.paa";
    };

    class ornate {
        variable = "ornate";
        displayName = "STR_Item_Ornate";
        weight = 2;
        buyPrice = -1;
        sellPrice = 775;
        illegal = false;
        edible = 25;
        icon = "\A3L_Client2\icons\ico_cookedFish.paa";
    };

    class mackerel_raw {
        variable = "mackerelRaw";
        displayName = "STR_Item_MackerelRaw";
        weight = 1;
        buyPrice = -1;
        sellPrice = 390;
        illegal = false;
        edible = -1;
        icon = "\A3L_Client2\icons\ico_mackerelRaw.paa";
    };

    class mackerel {
        variable = "mackerel";
        displayName = "STR_Item_Mackerel";
        weight = 2;
        buyPrice = -1;
        sellPrice = 750;
        illegal = false;
        edible = 30;
        icon = "\A3L_Client2\icons\ico_cookedFish.paa";
    };

    class tuna_raw {
        variable = "tunaRaw";
        displayName = "STR_Item_TunaRaw";
        weight = 2;
        buyPrice = -1;
        sellPrice = 1500;
        illegal = false;
        edible = -1;
        icon = "\A3L_Client2\icons\ico_tunaRaw.paa";
    };

    class tuna {
        variable = "tuna";
        displayName = "STR_Item_Tuna";
        weight = 3;
        buyPrice = -1;
        sellPrice = 1500;
        illegal = false;
        edible = 100;
        icon = "\A3L_Client2\icons\ico_cookedFish.paa";
    };

    class mullet_raw {
        variable = "mulletRaw";
        displayName = "STR_Item_MulletRaw";
        weight = 2;
        buyPrice = -1;
        sellPrice = 521;
        illegal = false;
        edible = -1;
        icon = "\A3L_Client2\icons\ico_mulletRaw.paa";
    };

    class mullet {
        variable = "mullet";
        displayName = "STR_Item_Mullet";
        weight = 2;
        buyPrice = -1;
        sellPrice = 1125;
        illegal = false;
        edible = 80;
        icon = "\A3L_Client2\icons\ico_cookedFish.paa";
    };

    class catshark_raw {
        variable = "catsharkRaw";
        displayName = "STR_Item_CatSharkRaw";
        weight = 3;
        buyPrice = -1;
        sellPrice = 653;
        illegal = false;
        edible = -1;
        icon = "\A3L_Client2\icons\ico_catsharkRaw.paa";
    };

    class catshark {
        variable = "catshark";
        displayName = "STR_Item_CatShark";
        weight = 3;
        buyPrice = -1;
        sellPrice = 1485;
        illegal = false;
        edible = 100;
        icon = "\A3L_Client2\icons\ico_cookedFish.paa";
    };

    class turtle_raw {
        variable = "turtleRaw";
        displayName = "STR_Item_TurtleRaw";
        weight = 3;
        buyPrice = -1;
        sellPrice = 5427;
        illegal = true;
        edible = -1;
        icon = "\A3L_Client2\icons\ico_turtleRaw.paa";
    };

    class turtle_soup {
        variable = "turtleSoup";
        displayName = "STR_Item_TurtleSoup";
        weight = 2;
        buyPrice = 1000;
        sellPrice = 750;
        illegal = false;
        edible = 100;
        icon = "\A3L_Client2\icons\ico_turtleSoup.paa";
    };

    class hen_raw {
        variable = "henRaw";
        displayName = "STR_Item_HenRaw";
        weight = 1;
        buyPrice = -1;
        sellPrice = 925;
        illegal = false;
        edible = -1;
        icon = "\A3L_Client2\icons\ico_wholeChickenRaw.paa";
    };

    class hen {
        variable = "hen";
        displayName = "STR_Item_Hen";
        weight = 2;
        buyPrice = 350;
        sellPrice = -1;
        illegal = false;
        edible = 65;
        icon = "\A3L_Client2\icons\ico_wholeChicken.paa";
    };

    class rooster_raw {
        variable = "roosterRaw";
        displayName = "STR_Item_RoosterRaw";
        weight = 1;
        buyPrice = -1;
        sellPrice = 980;
        illegal = false;
        edible = -1;
        icon = "\A3L_Client2\icons\ico_chickenDrumstickRaw.paa";
    };

    class rooster {
        variable = "rooster";
        displayName = "STR_Item_Rooster";
        weight = 2;
        buyPrice = 320;
        sellPrice = -1;
        illegal = false;
        edible = 45;
        icon = "\A3L_Client2\icons\ico_chickenDrumstick.paa";
    };

    class sheep_raw {
        variable = "sheepRaw";
        displayName = "STR_Item_SheepRaw";
        weight = 2;
        buyPrice = -1;
        sellPrice = 1650;
        illegal = false;
        edible = -1;
        icon = "\A3L_Client2\icons\ico_lambChopRaw.paa";
    };

    class sheep {
        variable = "sheep";
        displayName = "STR_Item_Sheep";
        weight = 2;
        buyPrice = 390;
        sellPrice = -1;
        illegal = false;
        edible = 100;
        icon = "\A3L_Client2\icons\ico_lambChop.paa";
    };

    class goat_raw {
        variable = "goatRaw";
        displayName = "STR_Item_GoatRaw";
        weight = 2;
        buyPrice = -1;
        sellPrice = 2150;
        illegal = true;
        edible = -1;
        icon = "\A3L_Client2\icons\ico_muttonLegRaw.paa";
    };

    class goat {
        variable = "goat";
        displayName = "STR_Item_Goat";
        weight = 2;
        buyPrice = 485;
        sellPrice = -1;
        illegal = true;
        edible = 100;
        icon = "\A3L_Client2\icons\ico_muttonLeg.paa";
    };
};
