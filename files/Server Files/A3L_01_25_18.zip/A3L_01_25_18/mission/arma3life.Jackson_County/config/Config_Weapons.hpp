/*
*    FORMAT:
*        STRING (Conditions) - Must return boolean :
*            String can contain any amount of conditions, aslong as the entire
*            string returns a boolean. This allows you to check any levels, licenses etc,
*            in any combination. For example:
*                "call life_coplevel && license_civ_someLicense"
*            This will also let you call any other function.
*            
*
*    ARRAY FORMAT:
*        0: STRING (Classname): Item Classname
*        1: STRING (Nickname): Nickname that will appear purely in the shop dialog
*        2: SCALAR (Buy price)
*        3: SCALAR (Sell price): To disable selling, this should be -1
*        4: STRING (Conditions): Same as above conditions string
*
*    Weapon classnames can be found here: https://community.bistudio.com/wiki/Arma_3_CfgWeapons_Weapons
*    Item classnames can be found here: https://community.bistudio.com/wiki/Arma_3_CfgWeapons_Items
*
*/
class WeaponShops {
    //Armory Shops
    class gun {
        name = "Billy Joe's Firearms";
        side = "civ";
        conditions = "license_civ_fcl";
        items[] = {
            { "RH_g17", "", 11000, -1, "" },
            { "RH_vp70", "", 7500, -1, "" },
            { "RH_bull", "", 22500, -1, "" },
            { "RH_m9", "", 14500, -1, "" },
            { "RH_m1911", "", 16250, -1, "" },
            { "KA_Px4", "", 16250, -1, "" }
        };
        mags[] = {
            { "RH_17Rnd_9x19_g17", "", 300, -1, "" },
            { "RH_18Rnd_9x19_VP", "", 300, -1, "" },
            { "RH_6Rnd_454_Mag", "", 300, -1, "" },
            { "RH_15Rnd_9x19_M9", "", 300, -1, "" },
            { "RH_7Rnd_45cal_m1911", "", 300, -1, "" },
            { "KA_Px4_17Rnd_9x19_FMJ_Mag", "", 300, -1, "" }
        };
        accs[] = {};
    };

    class rebel {
        name = "Mohammed's Jihadi Shop";
        side = "civ";
        conditions = "license_civ_rebel";
        items[] = {
            { "Binocular", "", 200, -1, "" },
            { "ItemGPS", "", 100, -1, "" },
            { "ItemMap", "", 50, -1, "" },
            { "ItemCompass", "", 50, -1, "" },
            { "ItemWatch", "", 50, -1, "" },
            { "FirstAidKit", "", 150, -1, "" },
            { "ToolKit", "", 750, -1, "" },
            { "tf_anprc148jem", "", 200, -1, "" },
            { "RH_gsh18", "", 15000, -1, "" },
            { "RH_g18", "", 17500, -1, "" },
            { "BP_SA61", "", 22500, -1, "" },
            { "KA_FMG9", "", 22500, -1, "" },
            { "BP_m9Tac", "", 22500, -1, "" },
            { "RH_kimber", "", 22500, -1, "" },
            { "RH_kimber_nw", "", 22500, -1, "" },
            { "RH_bull", "", 25000, -1, "" },
            { "RH_bullb", "", 25000, -1, "" },
            { "RH_fn57", "", 16000, -1, "" },
            { "RH_tec9", "", 22750, -1, "" },
            { "RH_vz61", "", 13500, -1, "" },
            { "RH_muzi", "", 13500, -1, "" },
            { "KA_MP7_Rifle_Black_40Rnd", "", 39500, -1, "" },
            { "KA_UMP45_P", "", 42700, -1, "" },
            { "KA_Vityaz", "", 49550, -1, "" },
            { "FHQ_smg_p90_black", "", 65000, -1, "" },
            { "hlc_rifle_ak12", "", 95000, -1, "" },
            { "hlc_rifle_ak74", "", 95000, -1, "" },
            { "hlc_rifle_aks74", "", 95000, -1, "" },
            { "KA_Mx4_Black", "", 75000, -1, "" },
            { "KA_RO991", "", 75000, -1, "" },
            { "FHQ_arifle_M4std_short_blk", "", 100500, -1, "" },
            { "KA_SG_552_Black", "", 100500, -1, "" },
            { "hlc_rifle_CQBR", "", 110000, -1, "" },
            { "rh_m4a1_ris", "", 125000, -1, "" },
            { "RH_Hk416s", "", 129000, -1, "" },
            { "RH_M16A3", "", 115000, -1, "" },
            { "RH_SFM952V", "", 950, -1, "" },
            { "RH_LTdocter", "", 950, -1, "" },
            { "RH_LTdocterl", "", 950, -1, "" },
            { "RH_zpoint", "", 950, -1, "" },
            { "RH_eotexps3", "", 950, -1, "" },
            { "RH_cmore", "", 950, -1, "" },
            { "FHQ_optic_MicroCCO", "", 950, -1, "" },
            { "RH_barska_rds", "", 950, -1, "" },
            { "hlc_optic_kobra", "", 950, -1, "" },
            { "A3L_RedDot", "", 950, -1, "" },
            { "FHQ_optic_AC11704", "", 950, -1, "" }
        };
        mags[] = {
            { "RH_18Rnd_9x19_gsh", "", 485, -1, "" },
            { "RH_33Rnd_9x19_g18", "", 485, -1, "" },
            { "BP_20Rnd_765x17", "", 485, -1, "" },
            { "KA_33Rnd_9x19_FMJ_Mag", "", 485, -1, "" },
            { "KA_25Rnd_45ACP_High_Presure_Mag", "", 485, -1, "" },
            { "KA_FAMAS_25rnd_SS109_FMJ_mag", "", 485, -1, "" },
            { "FHQ_50Rnd_57x28_Mag", "", 485, -1, "" },
            { "BP_33Rnd_9x19OVP", "", 485, -1, "" },
            { "RH_7Rnd_45cal_m1911", "", 485, -1, "" },
            { "RH_6Rnd_454_Mag", "", 485, -1, "" },
            { "RH_20Rnd_57x28_FN", "", 485, -1, "" },
            { "KA_32Rnd_9x19_FMJ_Mag", "", 485, -1, "" },
            { "RH_32Rnd_9x19_tec", "", 485, -1, "" },
            { "RH_20Rnd_32cal_vz61", "", 485, -1, "" },
            { "RH_30Rnd_9x19_UZI", "", 485, -1, "" },
            { "KA_40Rnd_46x30_FMJ", "", 485, -1, "" },
            { "KA_Mx4_30Rnd_9x19_FMJ_Mag", "", 755, -1, "" },
            { "hlc_30Rnd_545x39_B_AK", "", 755, -1, "" },
            { "30Rnd_556x45_Stanag", "", 755, -1, "" },
            { "KA_SIG_30rnd_Mk318_SOST_mag", "", 755, -1, "" },
            { "SA_30Rnd_556x45_M855A1_Stanag", "", 755, -1, "" }

        };
        accs[] = {};
    };

    class gang {
        name = "Hideout Armament";
        side = "civ";
        conditions = "";
        items[] = {
            { "Binocular", "", 1000, -1, "" },
            { "ItemGPS", "", 100, -1, "" },
            { "ItemMap", "", 50, -1, "" },
            { "ItemCompass", "", 50, -1, "" },
            { "ItemWatch", "", 50, -1, "" },
            { "FirstAidKit", "", 150, -1, "" },
            { "ToolKit", "", 750, -1, "" },
            { "A3L_Vape", "", 100, -1, "" },
            { "tf_anprc148jem", "", 1000, -1, "" },

            { "RH_Deagleg", "", 80000, -1, "" },
            { "CSW_Desert_Eagle", "", 68500, -1, "" },
            { "CSW_M500", "", 120500, -1, "" },
            { "RH_usp", "", 37500, -1, "" },
            { "RH_mateba", "", 48500, -1, "" },
            { "hlc_rifle_akm", "", 200000, -1, "" },
            { "A3L_AK47sgold", "", 245000, -1, "" },
            { "RH_m4_moe", "", 100000, -1, "" },
            { "RH_m4_moe_g", "", 100000, -1, "" },
            { "RH_M16A4_des", "", 110000, -1, "" },
            { "RH_M16A4_wdl", "", 110000, -1, "" },
            { "KA_FAMAS_F1", "", 135000, -1, "" },
            { "CSW_LVOA_C_Sand_TOB", "", 145000, -1, "" },
            { "FHQ_arifle_M4std_long_dsrt", "", 145000, -1, "" },
            { "FHQ_arifle_ACR_blk", "", 150000, -1, "" },
            { "FHQ_arifle_ACR_snw", "", 150000, -1, "" },
            { "hlc_rifle_bcmjack", "", 155000, -1, "" },
            { "AN94_MTK83", "", 155000, -1, "" },
            { "hlc_rifle_vendimus", "", 155000, -1, "" },
            { "RH_compM2", "", 1000, -1, "" },
            { "RH_compM2l", "", 1000, -1, "" },
            { "RH_compm4s", "", 1000, -1, "" },
    	    { "FHQ_optic_HWS", "", 1000, -1, "" },
            { "RH_SFM952V", "", 1000, -1, "" },
            { "RH_LTdocter", "", 1000, -1, "" },
            { "RH_LTdocterl", "", 1000, -1, "" },
            { "RH_zpoint", "", 1000, -1, "" },
            { "RH_eotexps3", "", 1000, -1, "" },
            { "RH_cmore", "", 1000, -1, "" },
            { "FHQ_optic_MicroCCO", "", 1000, -1, "" },
            { "RH_barska_rds", "", 1000, -1, "" },
            { "hlc_optic_kobra", "", 1000, -1, "" },
            { "A3L_RedDot", "", 1000, -1, "" },
            { "FHQ_optic_AC11704", "", 3000, -1, "" }
        };
        mags[] = {
            { "RH_7Rnd_50_AE", "", 550, -1, "" },
            { "CSW_7Rnd_127x33_AE", "", 550, -1, "" },
            { "RH_12Rnd_45cal_usp", "", 550, -1, "" },
            { "RH_6Rnd_44_Mag", "", 550, -1, "" },

            { "hlc_30Rnd_762x39_b_ak", "", 550, -1, "" },
            { "A3L_AK47sMag", "", 550, -1, "" },
            { "KA_FAMAS_25rnd_Subsonic_mag", "", 550, -1, "" },
            { "30Rnd_556x45_Stanag", "", 550, -1, "" },
            { "FHQ_rem_30Rnd_680x43_ACR", "", 550, -1, "" },
            { "KA_30rnd_7N6M_FMJ_HSC_mag", "", 550, -1, "" },
            { "29rnd_300BLK_STANAG", "", 550, -1, "" },
            { "RH_30Rnd_556x45_M855A1", "", 550, -1, "" }
        };
        accs[] = {};
    };

    //Basic Shops

    //EMS Shop
    class med_basic {
        name = "EMS Shop";
        side = "med";
        conditions = "";
        items[] = {
            { "Binocular", "", 150, -1, "" },
            { "Rangefinder", "", 100, -1, "" },
            { "ItemGPS", "", 100, -1, "" },
            { "ItemMap", "", 50, -1, "" },
            { "ItemCompass", "", 50, -1, "" },
            { "ItemWatch", "", 50, -1, "" },
            { "FirstAidKit", "", 150, -1, "" },
            { "Medikit", "", 100, -1, "" },
            { "ToolKit", "", 100, -1, "" },
            { "pmc_earpiece", "", 100, -1, "" },
            { "A3L_Vape", "", 100, -1, "" },
            { "A3L_Extinguisher", "", 100, -1, "" },
            { "tf_anprc152", "", 100, -1, "" }
        };
        mags[] = {
            { "30Rnd_test_mag_Tracer", "", 100, -1, "" }
        };
        accs[] = {};
    };

    class genstore {
        name = "General Store";
        side = "";
        conditions = "";
        items[] = {
            { "Binocular", "", 100, -1, "" },
            { "ItemGPS", "", 100, -1, "" },
            { "ItemMap", "", 50, -1, "" },
            { "ItemCompass", "", 50, -1, "" },
            { "ItemWatch", "", 50, -1, "" },
            { "tf_anprc148jem", "", 1000, -1, "" },
            { "FirstAidKit", "", 150, -1, "" },
            { "ToolKit", "", 750, -1, "" },
            { "CG_BAT", "", 5000, -1, "" },
            { "NVGoggles", "", 900, -1, "" },
            { "NVGoggles_OPFOR", "", 900, -1, "" },
            { "NVGoggles_INDEP", "", 900, -1, "" },
            { "Chemlight_red", "", 300, 150, "" },
            { "Chemlight_yellow", "", 300, 150, "" },
            { "Chemlight_green", "", 300, 150, "" },
            { "Chemlight_blue", "", 300, 150, "" }
        };
        mags[] = {
            { "nonlethal_swing", "", 500, -1, "" }
        };
        accs[] = {};
    };

    class mining {
        name = "Mining Shop";
        side = "civ";
        conditions = "";
        items[] = {};
        mags[] = {};
        accs[] = {};
    };

    class rifle {
        name = "Rifle Shop";
        side = "civ";
        conditions = "license_civ_rifle";
        items[] = {
            { "A3L_CZ550", "", 55600, -1, "" },
            { "RH_ar10", "", 62550, -1, "" },
            { "BP_Ruger", "", 37500, -1, "" },
            { "BP_1866", "", 41955, -1, "" },
            { "BP_Kar98z", "", 65900, -1, "" },
            { "A3L_CZ550Scope", "", 1000, -1, "" }
        };
        mags[] = {
            { "A3L_CZ550mag", "", 480, -1, "" },
            { "BP_25Rnd_22_Mag", "", 480, -1, "" },
            { "BP_7Rnd_45acp", "", 480, -1, "" },
            { "BP_5Rnd_Mauser_Mag", "", 480, -1, "" },
            { "RH_20Rnd_762x51_AR10", "", 480, -1, "" }
        };
        accs[] = {};
    };

    class f_station_store {
        name = "Altis Fuel Station Store";
        side = "";
        conditions = "";
        items[] = {
            { "Binocular", "", 750, 75, "" },
            { "ItemGPS", "", 500, 50, "" },
            { "ItemMap", "", 250, 25, "" },
            { "ItemCompass", "", 250, 25, "" },
            { "ItemWatch", "", 250, 25, "" },
            { "FirstAidKit", "", 750, 75, "" },
            { "NVGoggles", "", 900, 1000, "" },
            { "Chemlight_red", "", 1500, 150, "" },
            { "Chemlight_yellow", "", 1500, 150, "" },
            { "Chemlight_green", "", 1500, 150, "" },
            { "Chemlight_blue", "", 1500, 150, "" }
        };
        mags[] = {};
        accs[] = {};
    };

    //Cop Shops
    class cop_basic {
        name = "Cadet Shop";
        side = "cop";
        conditions = "call life_coplevel >= 1";
        items[] = {
            { "Binocular", "", 150, -1, "" },
            { "ItemGPS", "", 100, -1, "" },
            { "ItemMap", "", 50, -1, "" },
            { "ItemCompass", "", 50, -1, "" },
            { "ItemWatch", "", 50, -1, "" },
            { "FirstAidKit", "", 150, -1, "" },
            { "ToolKit", "", 100, -1, "" },
            { "pmc_earpiece", "", 100, -1, "" },
            { "A3L_Vape", "", 100, -1, "" },
            { "tf_anprc152", "", 100, -1, "" },

            { "Taser_26_tw", "", 250, -1, "" },
            { "prpl_benelli", "", 1000, -1, "" },

            { "CG_BATON", "", 250, -1, "" },

            { "RH_g22", "", 500, -1, "" },
            { "RH_p220", "", 500, -1, "" },
            { "RH_m9", "", 500, -1, "" },
            { "RH_m1911", "", 500, -1, "" },
            { "KA_Px4", "", 500, -1, "" },

            { "RH_M4sbr", "", 500, -1, "" },
            { "RH_sbr9", "", 500, -1, "" },

            { "RH_cmore", "", 100, -1, "" },
            { "RH_barska_rds", "", 100, -1, "" },

            { "RH_M6X", "", 100, -1, "" },
            { "RH_X300", "", 100, -1, "" }
        };
        mags[] = {
            { "26_cartridge_b", "", 50, -1, "" },
            { "prpl_8Rnd_12Gauge_taser", "", 50, -1, "" },

            { "nonlethal_swing", "", 50, -1, "" },

            { "RH_17Rnd_40SW_g22", "", 50, -1, "" },
            { "RH_15Rnd_45ACP_SIG", "", 50, -1, "" },
            { "RH_15Rnd_9x19_M9", "", 50, -1, "" },
            { "RH_7Rnd_45cal_m1911", "", 50, -1, "" },
            { "KA_Px4_17Rnd_9x19_FMJ_Mag", "", 50, -1, "" },

            { "RH_30Rnd_556x45_M855A1", "", 50, -1, "" },
            { "RH_32Rnd_9mm_M822", "", 50, -1, "" }
        };
        accs[] = {};
    };

    class cop_patrol {
        name = "Officer Shop";
        side = "cop";
        conditions = "call life_coplevel >= 2";
        items[] = {
            { "Binocular", "", 150, -1, "" },
            { "ItemGPS", "", 100, -1, "" },
            { "ItemMap", "", 50, -1, "" },
            { "ItemCompass", "", 50, -1, "" },
            { "ItemWatch", "", 50, -1, "" },
            { "FirstAidKit", "", 150, -1, "" },
            { "ToolKit", "", 100, -1, "" },
            { "pmc_earpiece", "", 100, -1, "" },
            { "A3L_Vape", "", 100, -1, "" },
            { "tf_anprc152", "", 100, -1, "" },

            { "Taser_26_tw", "", 250, -1, "" },
            { "prpl_benelli", "", 1000, -1, "" },

            { "CG_BATON", "", 100, -1, "" },

            { "RH_g22", "", 500, -1, "" },
            { "RH_p220", "", 500, -1, "" },
            { "RH_m9", "", 500, -1, "" },
            { "RH_m1911", "", 500, -1, "" },
            { "KA_Px4", "", 500, -1, "" },

            { "RH_sbr9", "", 1200, -1, "" },

            { "RH_M4sbr", "", 1200, -1, "" },
            { "RH_M4A1_ris", "", 1200, -1, "" },
            { "hlc_rifle_M4", "", 1200, -1, "" },
            { "Mossberg_590", "", 1200, -1, "" },

            { "RH_cmore", "", 100, -1, "" },
            { "RH_barska_rds", "", 100, -1, "" },
            { "RH_eotexps3", "", 100, -1, "" },
            { "FHQ_optic_AC11704", "", 100, -1, "" },
            { "optic_Aco", "", 100, -1, "" },
            { "optic_ACO_grn", "", 100, -1, "" },
            { "RH_eotech553_tan", "", 100, -1, "" },
            { "RH_eotech553", "", 100, -1, "" },
            { "RH_LTdocter", "", 100, -1, "" },
            { "RH_zpoint", "", 100, -1, "" },
            { "RH_compm4s", "", 100, -1, "" },
            { "RH_compM2", "", 100, -1, "" },
            { "RH_compM2l", "", 100, -1, "" },
            { "FHQ_optic_HWS", "", 100, -1, "" },
            { "RH_t1", "", 100, -1, "" },
            { "FHQ_optic_MicroCCO", "", 100, -1, "" },
            { "FHQ_optic_AC12136", "", 100, -1, "" },

            { "RH_zpoint", "", 100, -1, "" },
            { "RH_SFM952V", "", 100, -1, "" },
            { "RH_M6X", "", 100, -1, "" },
            { "RH_X300", "", 100, -1, "" }
        };
        mags[] = {
            { "26_cartridge_b", "", 50, -1, "" },
            { "prpl_8Rnd_12Gauge_taser", "", 50, -1, "" },

            { "nonlethal_swing", "", 50, -1, "" },

            { "RH_17Rnd_40SW_g22", "", 50, -1, "" },
            { "RH_15Rnd_45ACP_SIG", "", 50, -1, "" },
            { "RH_15Rnd_9x19_M9", "", 50, -1, "" },
            { "RH_7Rnd_45cal_m1911", "", 50, -1, "" },
            { "KA_Px4_17Rnd_9x19_FMJ_Mag", "", 50, -1, "" },

            { "RH_32Rnd_9mm_M822", "", 50, -1, "" },

            { "RH_30Rnd_556x45_M855A1", "", 50, -1, "" },
            { "hlc_30rnd_556x45_EPR", "", 50, -1, "" },
            { "8Rnd_Mossberg_590_Pellets", "", 50, -1, "" },
        };
        accs[] = {};
    };

     class cop_corporal {
        name = "Corporal Shop";
        side = "cop";
        conditions = "call life_coplevel >= 3";
        items[] = {
            { "Binocular", "", 150, -1, "" },
            { "ItemGPS", "", 100, -1, "" },
            { "ItemMap", "", 50, -1, "" },
            { "ItemCompass", "", 50, -1, "" },
            { "ItemWatch", "", 50, -1, "" },
            { "FirstAidKit", "", 150, -1, "" },
            { "ToolKit", "", 100, -1, "" },
            { "pmc_earpiece", "", 100, -1, "" },
            { "A3L_Vape", "", 100, -1, "" },
            { "tf_anprc152", "", 100, -1, "" },

            { "Taser_26_tw", "", 250, -1, "" },
            { "prpl_benelli", "", 1000, -1, "" },

            { "CG_BATON", "", 100, -1, "" },

            { "RH_g22", "", 500, -1, "" },
            { "RH_p220", "", 500, -1, "" },
            { "RH_m9", "", 500, -1, "" },
            { "RH_m1911", "", 500, -1, "" },
            { "RH_bull", "", 500, -1, "" },

            { "RH_M4sbr", "", 1200, -1, "" },
            { "RH_M4A1_ris", "", 1200, -1, "" },
            { "hlc_rifle_M4", "", 1200, -1, "" },
            { "RH_M16A4", "", 1200, -1, "" },
            { "FHQ_arifle_M4std_long_blk", "", 1200, -1, "" },
            { "Mossberg_590", "", 1200, -1, "" },


            { "RH_cmore", "", 100, -1, "" },
            { "RH_barska_rds", "", 100, -1, "" },
            { "RH_eotexps3", "", 100, -1, "" },
            { "FHQ_optic_AC11704", "", 100, -1, "" },
            { "optic_Aco", "", 100, -1, "" },
            { "optic_ACO_grn", "", 100, -1, "" },
            { "RH_eotech553_tan", "", 100, -1, "" },
            { "RH_eotech553", "", 100, -1, "" },
            { "RH_LTdocter", "", 100, -1, "" },
            { "RH_zpoint", "", 100, -1, "" },
            { "RH_compm4s", "", 100, -1, "" },
            { "RH_compM2", "", 100, -1, "" },
            { "RH_compM2l", "", 100, -1, "" },
            { "FHQ_optic_HWS", "", 100, -1, "" },
            { "RH_t1", "", 100, -1, "" },
            { "FHQ_optic_MicroCCO", "", 100, -1, "" },
            { "FHQ_optic_AC12136", "", 100, -1, "" },

            { "RH_zpoint", "", 100, -1, "" },
            { "RH_SFM952V", "", 100, -1, "" },
            { "RH_M6X", "", 100, -1, "" },
            { "RH_X300", "", 100, -1, "" }
        };
        mags[] = {
            { "26_cartridge_b", "", 50, -1, "" },
            { "prpl_8Rnd_12Gauge_taser", "", 50, -1, "" },

            { "nonlethal_swing", "", 50, -1, "" },

            { "RH_17Rnd_40SW_g22", "", 50, -1, "" },
            { "RH_15Rnd_45ACP_SIG", "", 50, -1, "" },
            { "RH_15Rnd_9x19_M9", "", 50, -1, "" },
            { "RH_7Rnd_45cal_m1911", "", 50, -1, "" },
            { "RH_6Rnd_454_Mag", "", 50, -1, "" },

            { "RH_30Rnd_556x45_M855A1", "", 50, -1, "" },
            { "hlc_30rnd_556x45_EPR", "", 50, -1, "" },
            { "30Rnd_556x45_Stanag", "", 50, -1, "" },
            { "8Rnd_Mossberg_590_Pellets", "", 50, -1, "" }
        };
        accs[] = {};
    };

    class cop_sergeant {
        name = "Sgt. Shop";
        side = "cop";
        conditions = "call life_coplevel >= 4";
        items[] = {
            { "Binocular", "", 150, -1, "" },
            { "ItemGPS", "", 100, -1, "" },
            { "ItemMap", "", 50, -1, "" },
            { "ItemCompass", "", 50, -1, "" },
            { "ItemWatch", "", 50, -1, "" },
            { "FirstAidKit", "", 150, -1, "" },
            { "ToolKit", "", 100, -1, "" },
            { "pmc_earpiece", "", 100, -1, "" },
            { "tf_anprc152", "", 100, -1, "" },
            { "Taser_26_tw", "", 250, -1, "" },
            { "RH_g22", "", 500, -1, "" },
            { "RH_p220", "", 500, -1, "" },
            { "RH_m9", "", 500, -1, "" },
            { "RH_m1911", "", 500, -1, "" },
            { "RH_fn57", "", 500, -1, "" },
            { "RH_bull", "", 500, -1, "" },

            { "RH_M4sbr", "", 1200, -1, "" },
            { "RH_M16A4", "", 1200, -1, "" },
            { "RH_M4A1_ris", "", 1200, -1, "" },
            { "hlc_rifle_M4", "", 1200, -1, "" },
            { "RH_Hk416c", "", 1200, -1, "" },
            { "FHQ_arifle_M4std_long_blk", "", 1200, -1, "" },
            { "Mossberg_590", "", 1200, -1, "" },

            { "RH_cmore", "", 100, -1, "" },
            { "RH_barska_rds", "", 100, -1, "" },
            { "RH_eotexps3", "", 100, -1, "" },
            { "FHQ_optic_AC11704", "", 100, -1, "" },
            { "optic_Aco", "", 100, -1, "" },
            { "optic_ACO_grn", "", 100, -1, "" },
            { "RH_eotech553_tan", "", 100, -1, "" },
            { "RH_eotech553", "", 100, -1, "" },
            { "RH_LTdocter", "", 100, -1, "" },
            { "RH_zpoint", "", 100, -1, "" },
            { "RH_compm4s", "", 100, -1, "" },
            { "RH_compM2", "", 100, -1, "" },
            { "RH_compM2l", "", 100, -1, "" },
            { "FHQ_optic_HWS", "", 100, -1, "" },
            { "RH_t1", "", 100, -1, "" },
            { "FHQ_optic_MicroCCO", "", 100, -1, "" },
            { "FHQ_optic_AC12136", "", 100, -1, "" },

            { "RH_zpoint", "", 100, -1, "" },
            { "RH_SFM952V", "", 100, -1, "" },
            { "RH_M6X", "", 100, -1, "" },
            { "RH_X300", "", 100, -1, "" }
        };
        mags[] = {
            { "26_cartridge_b", "", 50, -1, "" },
            { "prpl_8Rnd_12Gauge_taser", "", 50, -1, "" },

            { "nonlethal_swing", "", 50, -1, "" },

            { "RH_17Rnd_40SW_g22", "", 50, -1, "" },
            { "RH_15Rnd_45ACP_SIG", "", 50, -1, "" },
            { "RH_15Rnd_9x19_M9", "", 50, -1, "" },
            { "RH_7Rnd_45cal_m1911", "", 50, -1, "" },
            { "RH_20Rnd_57x28_FN", "", 50, -1, "" },
            { "RH_15Rnd_45cal_fnp", "", 50, -1, "" },
            { "RH_6Rnd_454_Mag", "", 50, -1, "" },

            { "RH_30Rnd_556x45_M855A1", "", 500, -1, "" },
            { "hlc_30rnd_556x45_EPR", "", 500, -1, "" },
            { "30Rnd_556x45_Stanag", "", 500, -1, "" },
            { "8Rnd_Mossberg_590_Pellets", "", 500, -1, "" }
        };
        accs[] = {};
    };

    class cop_pCmd {
        name = "Command Shop";
        side = "cop";
        conditions = "call life_coplevel >= 5";
        items[] = {
            { "Binocular", "", 150, -1, "" },
            { "Rangefinder", "", 100, -1, "" },
            { "ItemGPS", "", 100, -1, "" },
            { "ItemMap", "", 50, -1, "" },
            { "ItemCompass", "", 50, -1, "" },
            { "ItemWatch", "", 50, -1, "" },
            { "FirstAidKit", "", 150, -1, "" },
            { "ToolKit", "", 100, -1, "" },
            { "pmc_earpiece", "", 100, -1, "" },
            { "A3L_Vape", "", 100, -1, "" },
            { "tf_anprc152", "", 100, -1, "" },

            { "Taser_26_tw", "", 250, -1, "" },
            { "prpl_benelli", "", 1000, -1, "" },

            { "RH_g22", "", 500, -1, "" },
            { "RH_p220", "", 500, -1, "" },
            { "RH_m9", "", 500, -1, "" },
            { "RH_m1911", "", 500, -1, "" },
            { "RH_fn57", "", 500, -1, "" },
            { "RH_fnp45", "", 500, -1, "" },
            { "RH_uspm", "", 500, -1, "" },
            { "RH_bull", "", 500, -1, "" },

            { "RH_M16A4", "", 1200, -1, "" },
            { "RH_M4A1_ris", "", 1200, -1, "" },
            { "hlc_rifle_M4", "", 1200, -1, "" },
            { "RH_Hk416c", "", 1200, -1, "" },
            { "RH_Hk416", "", 1200, -1, "" },
            { "RH_M16A4_m", "", 1200, -1, "" },
            { "FHQ_arifle_M4std_long_blk", "", 1200, -1, "" },

            { "hlc_smg_mp510", "", 1350, -1, "" },
            { "hlc_smg_mp5a4", "", 1350, -1, "" },

            { "A3L_CZ550", "", 1500, -1, "" },

            { "RH_cmore", "", 100, -1, "" },
            { "RH_barska_rds", "", 100, -1, "" },
            { "RH_eotexps3", "", 100, -1, "" },
            { "FHQ_optic_AC11704", "", 100, -1, "" },
            { "optic_Aco", "", 100, -1, "" },
            { "optic_ACO_grn", "", 100, -1, "" },
            { "RH_eotech553_tan", "", 100, -1, "" },
            { "RH_eotech553", "", 100, -1, "" },
            { "RH_LTdocter", "", 100, -1, "" },
            { "RH_zpoint", "", 100, -1, "" },
            { "RH_compm4s", "", 100, -1, "" },
            { "RH_compM2", "", 100, -1, "" },
            { "RH_compM2l", "", 100, -1, "" },
            { "FHQ_optic_HWS", "", 100, -1, "" },
            { "RH_t1", "", 100, -1, "" },
            { "FHQ_optic_MicroCCO", "", 100, -1, "" },
            { "FHQ_optic_AC12136", "", 100, -1, "" },

            { "RH_zpoint", "", 100, -1, "" },
            { "RH_peq15b", "", 100, -1, "" },
            { "RH_SFM952V", "", 100, -1, "" },
            { "RH_M6X", "", 100, -1, "" },
            { "RH_X300", "", 100, -1, "" },

            { "A3L_CZ550Scope", "", 500, -1, "" },
            { "A3L_CZ550EHScope", "", 500, -1, "" }
        };
        mags[] = {
            { "26_cartridge_b", "", 100, -1, "" },
            { "prpl_8Rnd_12Gauge_taser", "", 100, -1, "" },

            { "RH_17Rnd_40SW_g22", "", 100, -1, "" },
            { "RH_15Rnd_45ACP_SIG", "", 100, -1, "" },
            { "RH_15Rnd_9x19_M9", "", 100, -1, "" },
            { "RH_7Rnd_45cal_m1911", "", 100, -1, "" },
            { "RH_20Rnd_57x28_FN", "", 100, -1, "" },
            { "RH_15Rnd_45cal_fnp", "", 100, -1, "" },
            { "RH_16Rnd_40cal_usp", "", 100, -1, "" },
            { "RH_6Rnd_454_Mag", "", 100, -1, "" },

            { "RH_30Rnd_556x45_M855A1", "", 100, -1, "" },
            { "hlc_30rnd_556x45_EPR", "", 100, -1, "" },
            { "30Rnd_556x45_Stanag", "", 100, -1, "" },

            { "hlc_30Rnd_10mm_B_MP5", "", 100, -1, "" },
            { "hlc_30Rnd_9x19_GD_MP5", "", 100, -1, "" },

            { "A3L_CZ550mag", "", 250, -1, "" }
        };
        accs[] = {};
    };

    class cop_swat {
        name = "SWAT/SERT Shop";
        side = "cop";
        conditions = "call life_coplevel >= 7";
        items[] = {
            { "Binocular", "", 150, -1, "" },
            { "Rangefinder", "", 100, -1, "" },
            { "ItemGPS", "", 100, -1, "" },
            { "ItemMap", "", 50, -1, "" },
            { "ItemCompass", "", 50, -1, "" },
            { "ItemWatch", "", 50, -1, "" },
            { "FirstAidKit", "", 150, -1, "" },
            { "ToolKit", "", 100, -1, "" },
            { "pmc_earpiece", "", 100, -1, "" },
            { "A3L_Vape", "", 100, -1, "" },
            { "tf_anprc152", "", 100, -1, "" },

            { "A3L_Tactical_Shield", "", 1500, -1, "" },
            //{ "KA_FNP45", "", 5000, -1, "" },

            { "Taser_26_tw", "", 250, -1, "" },
            { "prpl_benelli", "", 1000, -1, "" },

            { "RH_g22", "", 500, -1, "" },
            { "RH_p220", "", 500, -1, "" },
            { "RH_m9", "", 500, -1, "" },
            { "RH_m1911", "", 500, -1, "" },
            { "RH_kimber_nw", "", 500, -1, "" },
            { "RH_ttracker", "", 500, -1, "" },
            { "RH_fn57", "", 500, -1, "" },
            { "RH_fnp45", "", 500, -1, "" },
            { "RH_uspm", "", 500, -1, "" },
            { "RH_bull", "", 500, -1, "" },

            { "RH_M4sbr", "", 1200, -1, "" },
            { "RH_M16A4", "", 1200, -1, "" },
            { "RH_M4A1_ris", "", 1200, -1, "" },
            { "hlc_rifle_M4", "", 1200, -1, "" },
            { "RH_Hk416c", "", 1200, -1, "" },
            { "RH_M16A4_m", "", 1200, -1, "" },
            { "RH_M4m", "", 1200, -1, "" },
            { "hlc_rifle_bcmjack", "", 1200, -1, "" },
            { "hlc_rifle_RU556", "", 1200, -1, "" },
            { "FHQ_arifle_M4_long_blk", "", 1200, -1, "" },
            { "CSW_LVOA_C_Black_TOB", "", 1200, -1, "" },

            { "hlc_smg_mp510", "", 1350, -1, "" },
            { "hlc_smg_mp5a4", "", 1350, -1, "" },

            { "A3L_CZ550", "", 1500, -1, "" },

            { "RH_cmore", "", 100, -1, "" },
            { "RH_barska_rds", "", 100, -1, "" },
            { "RH_eotexps3", "", 100, -1, "" },
            { "FHQ_optic_AC11704", "", 100, -1, "" },
            { "optic_Aco", "", 100, -1, "" },
            { "optic_ACO_grn", "", 100, -1, "" },
            { "RH_eotech553_tan", "", 100, -1, "" },
            { "RH_eotech553", "", 100, -1, "" },
            { "RH_LTdocter", "", 100, -1, "" },
            { "RH_zpoint", "", 100, -1, "" },
            { "RH_compm4s", "", 100, -1, "" },
            { "RH_compM2", "", 100, -1, "" },
            { "RH_compM2l", "", 100, -1, "" },
            { "FHQ_optic_HWS", "", 100, -1, "" },
            { "RH_t1", "", 100, -1, "" },
            { "FHQ_optic_MicroCCO", "", 100, -1, "" },
            { "FHQ_optic_AC12136", "", 100, -1, "" },

            { "RH_peq15b", "", 100, -1, "" },
            { "RH_SFM952V", "", 100, -1, "" },
            { "RH_M6X", "", 100, -1, "" },
            { "RH_X300", "", 100, -1, "" },

            { "A3L_CZ550Scope", "", 500, -1, "" },
            { "A3L_CZ550EHScope", "", 1500, -1, "" }
        };
        mags[] = {
            { "26_cartridge_b", "", 100, -1, "" },
            { "prpl_8Rnd_12Gauge_taser", "", 100, -1, "" },

            //{ "KA_15Rnd_45ACP_Mag", "", 500, -1, "" },

            { "RH_17Rnd_40SW_g22", "", 100, -1, "" },
            { "RH_15Rnd_45ACP_SIG", "", 100, -1, "" },
            { "RH_15Rnd_9x19_M9", "", 100, -1, "" },
            { "RH_7Rnd_45cal_m1911", "", 100, -1, "" },
            { "RH_6Rnd_45ACP_Mag", "", 100, -1, "" },
            { "RH_20Rnd_57x28_FN", "", 100, -1, "" },
            { "RH_15Rnd_45cal_fnp", "", 100, -1, "" },
            { "RH_16Rnd_40cal_usp", "", 100, -1, "" },
            { "RH_6Rnd_454_Mag", "", 100, -1, "" },

            { "RH_30Rnd_556x45_M855A1", "", 100, -1, "" },
            { "hlc_30rnd_556x45_EPR", "", 100, -1, "" },
            { "30Rnd_556x45_Stanag", "", 100, -1, "" },

            { "hlc_30Rnd_10mm_B_MP5", "", 100, -1, "" },
            { "hlc_30Rnd_9x19_GD_MP5", "", 100, -1, "" },

            { "A3L_CZ550mag", "", 500, -1, "" }
        };
        accs[] = {};
    };

    class cop_swat_cmd {
        name = "SWAT/SERT Command Shop";
        side = "cop";
        conditions = "call life_coplevel >= 8";
        items[] = {
            { "Binocular", "", 150, -1, "" },
            { "Rangefinder", "", 100, -1, "" },
            { "ItemGPS", "", 100, -1, "" },
            { "ItemMap", "", 50, -1, "" },
            { "ItemCompass", "", 50, -1, "" },
            { "ItemWatch", "", 50, -1, "" },
            { "FirstAidKit", "", 150, -1, "" },
            { "ToolKit", "", 100, -1, "" },
            { "pmc_earpiece", "", 100, -1, "" },
            { "A3L_Vape", "", 100, -1, "" },
            { "tf_anprc152", "", 100, -1, "" },

            { "SmokeShellYellow", "", 1000, -1, "" },
            { "SUPER_flash", "", 1000, -1, "" },

            { "A3L_Tactical_Shield", "", 5000, -1, "" },
            //{ "KA_FNP45", "", 5000, -1, "" },

            { "Taser_26_tw", "", 1000, -1, "" },
            { "prpl_benelli", "", 15000, -1, "" },

            { "RH_g22", "", 500, -1, "" },
            { "RH_p220", "", 500, -1, "" },
            { "RH_m9", "", 500, -1, "" },
            { "RH_m1911", "", 500, -1, "" },
            { "RH_kimber_nw", "", 500, -1, "" },
            { "RH_ttracker", "", 500, -1, "" },
            { "RH_fn57", "", 500, -1, "" },
            { "RH_fnp45", "", 500, -1, "" },
            { "RH_uspm", "", 500, -1, "" },
            { "RH_bull", "", 500, -1, "" },
            { "RH_Deaglem", "", 500, -1, "" },

            { "RH_M4sbr", "", 1200, -1, "" },
            { "RH_M16A4", "", 1200, -1, "" },
            { "RH_M4A1_ris", "", 1200, -1, "" },
            { "hlc_rifle_M4", "", 1200, -1, "" },
            { "RH_Hk416c", "", 1200, -1, "" },
            { "RH_Hk416", "", 1200, -1, "" },
            { "RH_M16A4_m", "", 1200, -1, "" },
            { "RH_M4m", "", 1200, -1, "" },
            { "hlc_rifle_bcmjack", "", 1200, -1, "" },
            { "hlc_rifle_bcmblackjack", "",2000, -1, "" },
            { "RH_M4A6", "", 2000, -1, "" },
            { "hlc_rifle_RU556", "", 1200, -1, "" },
            { "FHQ_arifle_M4_long_blk", "", 1200, -1, "" },

            { "hlc_smg_mp510", "", 1350, -1, "" },
            { "hlc_smg_mp5a4", "", 1350, -1, "" },

            { "A3L_CZ550", "", 1500, -1, "" },

            //{ "KA_red", "", 500, -1, "" },
            //{ "KA_FNP45_shield2", "", 500, -1, "" },
            { "RH_Deflash", "", 500, -1, "" },

            { "RH_cmore", "", 100, -1, "" },
            { "RH_barska_rds", "", 100, -1, "" },
            { "RH_eotexps3", "", 100, -1, "" },
            { "FHQ_optic_AC11704", "", 100, -1, "" },
            { "optic_Aco", "", 100, -1, "" },
            { "optic_ACO_grn", "", 100, -1, "" },
            { "RH_eotech553_tan", "", 100, -1, "" },
            { "RH_eotech553", "", 100, -1, "" },
            { "RH_LTdocter", "", 100, -1, "" },
            { "RH_zpoint", "", 100, -1, "" },
            { "RH_compm4s", "", 100, -1, "" },
            { "RH_compM2", "", 100, -1, "" },
            { "RH_compM2l", "", 100, -1, "" },
            { "FHQ_optic_HWS", "", 100, -1, "" },
            { "RH_t1", "", 100, -1, "" },
            { "FHQ_optic_MicroCCO", "", 100, -1, "" },
            { "FHQ_optic_AC12136", "", 100, -1, "" },

            { "RH_peq15b", "", 100, -1, "" },
            { "RH_SFM952V", "", 100, -1, "" },
            { "RH_M6X", "", 100, -1, "" },
            { "RH_X300", "", 100, -1, "" },

            { "A3L_CZ550Scope", "", 500, -1, "" },
            { "A3L_CZ550EHScope", "", 1500, -1, "" }
        };
        mags[] = {
            { "26_cartridge_b", "", 100, -1, "" },
            { "prpl_8Rnd_12Gauge_taser", "", 100, -1, "" },

            //{ "KA_15Rnd_45ACP_Mag", "", 500, -1, "" },

            { "RH_17Rnd_40SW_g22", "", 100, -1, "" },
            { "RH_15Rnd_45ACP_SIG", "", 100, -1, "" },
            { "RH_15Rnd_9x19_M9", "", 100, -1, "" },
            { "RH_7Rnd_45cal_m1911", "", 100, -1, "" },
            { "RH_6Rnd_45ACP_Mag", "", 100, -1, "" },
            { "RH_20Rnd_57x28_FN", "", 100, -1, "" },
            { "RH_15Rnd_45cal_fnp", "", 100, -1, "" },
            { "RH_16Rnd_40cal_usp", "", 100, -1, "" },
            { "RH_6Rnd_454_Mag", "", 100, -1, "" },
            { "RH_7Rnd_50_AE", "", 100, -1, "" },

            { "RH_30Rnd_556x45_M855A1", "", 100, -1, "" },
            { "hlc_30rnd_556x45_EPR", "", 100, -1, "" },
            { "29rnd_300BLK_STANAG", "", 100, -1, "" },
            { "RH_30Rnd_68x43_FMJ", "", 100, -1, "" },
            { "30Rnd_556x45_Stanag", "", 100, -1, "" },

            { "hlc_30Rnd_10mm_B_MP5", "", 100, -1, "" },
            { "hlc_30Rnd_9x19_GD_MP5", "", 100, -1, "" },

            { "A3L_CZ550mag", "", 100, -1, "" }
        };
        accs[] = {};
    };

    class cop_FBI {
        name = "FBI Weapon Shop";
        side = "cop";
        conditions = "call life_coplevel >= 5";
        items[] = {
            { "Binocular", "", 150, -1, "" },
            { "Rangefinder", "", 100, -1, "" },
            { "ItemGPS", "", 100, -1, "" },
            { "ItemMap", "", 50, -1, "" },
            { "ItemCompass", "", 50, -1, "" },
            { "ItemWatch", "", 50, -1, "" },
            { "FirstAidKit", "", 150, -1, "" },
            { "ToolKit", "", 100, -1, "" },
            { "pmc_earpiece", "", 100, -1, "" },
            { "A3L_Vape", "", 100, -1, "" },
            { "tf_anprc152", "", 100, -1, "" },

            { "Taser_26_tw", "", 250, -1, "" },
            { "prpl_benelli", "", 1000, -1, "" },

            { "RH_g22", "", 500, -1, "" },
            { "RH_p220", "", 500, -1, "" },
            { "RH_m9", "", 500, -1, "" },
            { "RH_m1911", "", 500, -1, "" },
            { "RH_fn57", "", 500, -1, "" },
            { "RH_fnp45", "", 500, -1, "" },
            { "RH_uspm", "", 500, -1, "" },
            { "RH_bull", "", 500, -1, "" },

            { "RH_M16A4", "", 1200, -1, "" },
            { "RH_M4A1_ris", "", 1200, -1, "" },
            { "hlc_rifle_M4", "", 1200, -1, "" },
            { "RH_Hk416c", "", 1200, -1, "" },
            { "RH_Hk416", "", 1200, -1, "" },
            { "RH_M16A4_m", "", 1200, -1, "" },
            { "FHQ_arifle_M4std_long_blk", "", 1200, -1, "" },

            { "hlc_smg_mp510", "", 1350, -1, "" },
            { "hlc_smg_mp5a4", "", 1350, -1, "" },

            { "A3L_CZ550", "", 1500, -1, "" },

            { "RH_cmore", "", 100, -1, "" },
            { "RH_barska_rds", "", 100, -1, "" },
            { "RH_eotexps3", "", 100, -1, "" },
            { "FHQ_optic_AC11704", "", 100, -1, "" },
            { "optic_Aco", "", 100, -1, "" },
            { "optic_ACO_grn", "", 100, -1, "" },
            { "RH_eotech553_tan", "", 100, -1, "" },
            { "RH_eotech553", "", 100, -1, "" },
            { "RH_LTdocter", "", 100, -1, "" },
            { "RH_zpoint", "", 100, -1, "" },
            { "RH_compm4s", "", 100, -1, "" },
            { "RH_compM2", "", 100, -1, "" },
            { "RH_compM2l", "", 100, -1, "" },
            { "FHQ_optic_HWS", "", 100, -1, "" },
            { "RH_t1", "", 100, -1, "" },
            { "FHQ_optic_MicroCCO", "", 100, -1, "" },
            { "FHQ_optic_AC12136", "", 100, -1, "" },

            { "RH_zpoint", "", 100, -1, "" },
            { "RH_peq15b", "", 100, -1, "" },
            { "RH_SFM952V", "", 100, -1, "" },
            { "RH_M6X", "", 100, -1, "" },
            { "RH_X300", "", 100, -1, "" },

            { "A3L_CZ550Scope", "", 500, -1, "" },
            { "A3L_CZ550EHScope", "", 500, -1, "" }
        };
        mags[] = {
            { "26_cartridge_b", "", 100, -1, "" },
            { "prpl_8Rnd_12Gauge_taser", "", 100, -1, "" },

            { "RH_17Rnd_40SW_g22", "", 100, -1, "" },
            { "RH_15Rnd_45ACP_SIG", "", 100, -1, "" },
            { "RH_15Rnd_9x19_M9", "", 100, -1, "" },
            { "RH_7Rnd_45cal_m1911", "", 100, -1, "" },
            { "RH_20Rnd_57x28_FN", "", 100, -1, "" },
            { "RH_15Rnd_45cal_fnp", "", 100, -1, "" },
            { "RH_16Rnd_40cal_usp", "", 100, -1, "" },
            { "RH_6Rnd_454_Mag", "", 100, -1, "" },

            { "RH_30Rnd_556x45_M855A1", "", 100, -1, "" },
            { "hlc_30rnd_556x45_EPR", "", 100, -1, "" },
            { "30Rnd_556x45_Stanag", "", 100, -1, "" },

            { "hlc_30Rnd_10mm_B_MP5", "", 100, -1, "" },
            { "hlc_30Rnd_9x19_GD_MP5", "", 100, -1, "" },

            { "A3L_CZ550mag", "", 250, -1, "" }
        };
        accs[] = {};
    };

    class ems_flares {
        name = "EMS Flare Shop";
        side = "med";
        conditions = "";
        items[] = {
            { "hgun_Pistol_Signal_F", "", 150, -1, "" }
        };
        mags[] = {
            { "6Rnd_GreenSignal_F", "", 100, -1, "" },
            { "6Rnd_RedSignal_F", "", 100, -1, "" },
        };
        accs[] = {};
    };

    class dive {
        name = "Dive Shop";
        side = "civ";
        conditions = "license_civ_dive";
        items[] = {
            { "arifle_SDAR_F", "", 35000, -1, "" }
        };
        mags[] = {
            { "20Rnd_556x45_UW_mag", "", 1000, -1, "" }
        };
        accs[] = {};
    };
    class doj_gear {
        name = "DOJ Weapon Shop";
        side = "civ";
        conditions = "call life_dojlevel >= 1 && license_civ_fcl";
        items[] = {
            { "Binocular", "", 150, -1, "" },
            { "Rangefinder", "", 100, -1, "" },
            { "ItemGPS", "", 100, -1, "" },
            { "ItemMap", "", 50, -1, "" },
            { "ItemCompass", "", 50, -1, "" },
            { "ItemWatch", "", 50, -1, "" },
            { "FirstAidKit", "", 150, -1, "" },
            { "ToolKit", "", 100, -1, "" },
            { "pmc_earpiece", "", 100, -1, "" },
            { "A3L_Vape", "", 100, -1, "" },
            { "tf_anprc152", "", 100, -1, "" },
            
            { "RH_g17", "", 15000, -1, "" },
            { "RH_vp70", "", 15000, -1, "" },
            { "RH_bull", "", 15000, -1, "" },
            { "RH_m9", "", 15000, -1, "" },
            { "RH_m1911", "", 15000, -1, "" }
        };
        mags[] = {
            { "RH_17Rnd_9x19_g17", "", 850, -1, "" },
            { "RH_18Rnd_9x19_VP", "", 850, -1, "" },
            { "RH_6Rnd_454_Mag", "", 850, -1, "" },
            { "RH_15Rnd_9x19_M9", "", 850, -1, "" },
            { "RH_7Rnd_45cal_m1911", "", 850, -1, "" },
            { "KA_8Rnd_45ACP_Mag", "", 850, -1, "" }
        };
        accs[] = {};
    };

};
