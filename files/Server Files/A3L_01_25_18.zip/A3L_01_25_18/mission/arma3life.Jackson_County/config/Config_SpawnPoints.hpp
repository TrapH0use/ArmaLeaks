/*
*    Format:
*        3: STRING (Conditions) - Must return boolean :
*            String can contain any amount of conditions, aslong as the entire
*            string returns a boolean. This allows you to check any levels, licenses etc,
*            in any combination. For example:
*                "call life_coplevel && license_civ_someLicense"
*            This will also let you call any other function.
*
*/
class CfgSpawnPoints {

    class Jackson_County {
        class Civilian {
            class LSCivSpawn {
                displayName = "Lakeside";
                spawnMarker = "LS_Civ_Spawn";
                icon = "\a3\ui_f\data\map\MapControl\watertower_ca.paa";
                conditions = "";
            };

            class MTCivSpawn {
                displayName = "Morrison Town";
                spawnMarker = "MT_Civ_Spawn";
                icon = "\a3\ui_f\data\map\MapControl\watertower_ca.paa";
                conditions = "";
            };

            class OWCivSpawn {
                displayName = "Oli Wood";
                spawnMarker = "LD_Civ_Spawn";
                icon = "\a3\ui_f\data\map\MapControl\watertower_ca.paa";
                conditions = "";
            };

            class SCCivSpawn {
                displayName = "San Cristobal";
                spawnMarker = "SC_Civ_Spawn";
                icon = "\a3\ui_f\data\map\MapControl\watertower_ca.paa";
                conditions = "";
            };

            class DOJCivSpawn {
                displayName = "Lakeside Courthouse";
                spawnMarker = "DOJ_Spawn_1";
                icon = "\a3\ui_f\data\map\MapControl\watertower_ca.paa";
                conditions = "call life_dojlevel >= 1";
            };

            class RBCivSpawn {
                displayName = "Rebel";
                spawnMarker = "Reb_Civ_Spawn";
                icon = "\a3\ui_f\data\map\MapControl\watertower_ca.paa";
                conditions = "license_civ_rebel";
            };
        };

        class Cop {
             class LSCopSO {
                displayName = "Lakeside SO";
                spawnMarker = "LS_Cop_Spawn";
                icon = "\a3\ui_f\data\map\MapControl\watertower_ca.paa";
                conditions = "";
            };

            class OWCopSO {
                displayName = "Oli Wood Substation";
                spawnMarker = "LD_cop_spawn";
                icon = "\a3\ui_f\data\map\MapControl\watertower_ca.paa";
                conditions = "";
            };

            class DOCCopSO {
                displayName = "Department of Corrections";
                spawnMarker = "hcf_cop_spawn";
                icon = "\a3\ui_f\data\map\MapControl\watertower_ca.paa";
                conditions = "";
            };

            class FBICopSO {
                displayName = "FBI Spawn";
                spawnMarker = "LS_FBI_Shop";
                icon = "\a3\ui_f\data\map\MapControl\watertower_ca.paa";
                conditions = "call life_coplevel >= 9";
            };
        };

        class Medic {
            class LSFD {
                displayName = "Lakeside Fire Station";
                spawnMarker = "LS_Med_Spawn";
                icon = "\a3\ui_f\data\map\MapControl\watertower_ca.paa";
                conditions = "";
            };

            class APFD {
                displayName = "Airport Fire Station";
                spawnMarker = "LS_Med_Spawn_2";
                icon = "\a3\ui_f\data\map\MapControl\watertower_ca.paa";
                conditions = "";
            };

            class MTFS {
                displayName = "Fort Hood Hospital";
                spawnMarker = "MTFD_Med_Spawn";
                icon = "\a3\ui_f\data\map\MapControl\watertower_ca.paa";
                conditions = "";
            };

            class SRBase {
                displayName = "S&R Base";
                spawnMarker = "SnR_Med_Spawn";
                icon = "\a3\ui_f\data\map\MapControl\watertower_ca.paa";
                conditions = "";
            };

            class LSHospital {
                displayName = "Lakeside Hospital";
                spawnMarker = "LS_Med_Spawn_1";
                icon = "\a3\ui_f\data\map\MapControl\watertower_ca.paa";
                conditions = "";
            };
        };

    };

};
