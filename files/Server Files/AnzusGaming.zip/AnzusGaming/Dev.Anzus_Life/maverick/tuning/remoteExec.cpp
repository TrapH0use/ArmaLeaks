/*--------------------------------------------------------------------------
    Author:		Bytex Digital
    Website:	https://bytex.digital

    You're not allowed to use this file without permission from the author!
---------------------------------------------------------------------------*/

class mav_tuning_fnc_saveTuningToDB {
    allowedTargets = 2;
};
class mav_tuning_fnc_disableLight {
    allowedTargets = 1;
};
class mav_tuning_fnc_enableLight {
    allowedTargets = 1;
};
class mav_tuning_fnc_hide {
    allowedTargets = 2;
};