/*--------------------------------------------------------------------------
    Author:		Bytex Digital
    Website:	https://bytex.digital

    You're not allowed to use this file without permission from the author!
---------------------------------------------------------------------------*/

//Do not touch below
class Maverick_SpeedCameras {

	tag = "mav_SpeedCameras";

	class functions {

		file = "Maverick\SpeedCameras\scripts";
        class loadSpeedCameras {postInit = 1; headerType = -1;};

	};

};