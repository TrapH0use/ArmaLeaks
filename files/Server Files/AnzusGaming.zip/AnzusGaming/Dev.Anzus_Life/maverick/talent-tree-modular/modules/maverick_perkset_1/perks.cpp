class perk_civilian_master {
	displayName = "Civilian Perks";
	requiredPerkPoints = 1;
	requiredLevel = 1;
	requiredPerk = "";
	subtitle = "1 point required to unlock this tree";
	description = "Learn and improve on civilian specific perks";
	initScript = "";
	limitToSides[] = {"CIV"};
	color[] = {0,0.6,0,1};
};
