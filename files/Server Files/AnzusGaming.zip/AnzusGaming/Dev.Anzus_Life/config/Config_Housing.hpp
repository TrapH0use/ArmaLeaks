#define true 1
#define false 0

class Housing {
	class Anzus_Life {

	class Land_HouseA {
		price = 150000;
		numberCrates = 2;
    restrictedPos[] = {};
    canGarage = true;
    garageSpawnPos[] = {};
    garageSpawnDir = 0;
    garageBlacklists[] = {};
		lightPos[] = {0,-2,3.8};
    };

	class Land_HouseA1 {
		price = 150000;
		numberCrates = 2;
    restrictedPos[] = {};
    canGarage = true;
    garageSpawnPos[] = {};
    garageSpawnDir = 0;
    garageBlacklists[] = {};
		lightPos[] = {0,-2,3.8};
    };

	class Land_HouseA1_L {
		price = 150000;
		numberCrates = 2;
    restrictedPos[] = {};
    canGarage = true;
    garageSpawnPos[] = {};
    garageSpawnDir = 0;
    garageBlacklists[] = {};
		lightPos[] = {0,-2,3.8};
    };

	class Land_HouseC_R {
		price = 150000;
		numberCrates = 2;
  	restrictedPos[] = {};
    canGarage = true;
    garageSpawnPos[] = {};
    garageSpawnDir = 0;
    garageBlacklists[] = {};
		lightPos[] = {0,-2,3.8};
    };

	class Land_HouseDoubleAL2 {
		price = 500000;
		numberCrates = 3;
    restrictedPos[] = {};
    canGarage = true;
		garageSpawnPos[] = {};
    garageSpawnDir = 0;
    garageBlacklists[] = {};
		lightPos[] = {0,-2,3.8};
    };

	class Land_HouseDoubleAL {
		price = 500000;
		numberCrates = 3;
    restrictedPos[] = {};
    canGarage = true;
    garageSpawnPos[] = {};
    garageSpawnDir = 0;
    garageBlacklists[] = {};
		lightPos[] = {0,-2,3.8};
    };

	class Land_HouseC1_L {
		price = 300000;
		numberCrates = 3;
    restrictedPos[] = {};
    canGarage = true;
    garageSpawnPos[] = {};
    garageSpawnDir = 0;
    garageBlacklists[] = {};
		lightPos[] = {0,-2,3.8};
    };

	class Land_HouseB1 {
		price = 300000;
		numberCrates = 3;
    restrictedPos[] = {};
    canGarage = true;
    garageSpawnPos[] = {};
    garageSpawnDir = 0;
    garageBlacklists[] = {};
		lightPos[] = {0,-2,3.8};
    };

	class Land_HouseB {
		price = 300000;
		numberCrates = 3;
    restrictedPos[] = {};
    canGarage = true;
    garageSpawnPos[] = {};
    garageSpawnDir = 0;
    garageBlacklists[] = {};
		lightPos[] = {0,-2,3.8};
    };


	class Land_aus2storyhouse {
      price = 2000000;
	    numberCrates = 5;
      restrictedPos[] = {};
      canGarage = true;
      garageSpawnPos[] = {};
      garageSpawnDir = 0;
      garageBlacklists[] = {};
	    lightPos[] = {0,7,10};
    };

	class Land_greyhirise {
      price = 10000000;
	    numberCrates = 8;
      restrictedPos[] = {};
      canGarage = true;
      garageSpawnPos[] = {};
      garageSpawnDir = 0;
      garageBlacklists[] = {};
	    //player setPosATL (cursorObject modelToWorld [6.5,-2,35]);
	    lightPos[] = {0,0,34};
    };

	class Land_greyhouse {
      price = 5000000;
	    numberCrates = 7;
      restrictedPos[] = {};
      canGarage = true;
      garageSpawnPos[] = {};
      garageSpawnDir = 0;
      garageBlacklists[] = {};
		  lightPos[] = {0,7,10};
    };

	class Land_o_casa_alcalde {
      price = 1700000;
	    numberCrates = 4;
      restrictedPos[] = {};
      canGarage = true;
      garageSpawnPos[] = {};
      garageSpawnDir = 0;
      garageBlacklists[] = {};
	    lightPos[] = {0,7,10};
    };

	class Land_squarehouse {
      price = 1200000;
	    numberCrates = 4;
      restrictedPos[] = {};
      canGarage = true;
      garageSpawnPos[] = {};
      garageSpawnDir = 0;
      garageBlacklists[] = {};
	    lightPos[] = {0,-2,3.8};
    };

	class Land_M_house1 {
      price = 50000000;
	    numberCrates = 1;
      restrictedPos[] = {};
      canGarage = true;
      garageSpawnPos[] = {};
      garageSpawnDir = 0;
      garageBlacklists[] = {};
	    lightPos[] = {0,-2,3.8};
    };
	
	class Land_ivory_trailer_01 {
      price = 50000;
	    numberCrates = 1;
      restrictedPos[] = {};
      canGarage = true;
      garageSpawnPos[] = {};
      garageSpawnDir = 0;
      garageBlacklists[] = {};
	    lightPos[] = {0,-2,3.8};
    };

	class Land_ivory_trailer_02 {
      price = 50000;
	    numberCrates = 1;
      restrictedPos[] = {};
      canGarage = true;
      garageSpawnPos[] = {};
      garageSpawnDir = 0;
      garageBlacklists[] = {};
	    lightPos[] = {0,-2,3.8};
    };

	class Land_ivory_trailer_03 {
      price = 50000;
	   	numberCrates = 1;
      restrictedPos[] = {};
      canGarage = true;
      garageSpawnPos[] = {};
      garageSpawnDir = 0;
      garageBlacklists[] = {};
	    lightPos[] = {0,-2,3.8};
    };

	class Land_ivory_trailer_04 {
      price = 50000;
	    numberCrates = 1;
      restrictedPos[] = {};
      canGarage = true;
      garageSpawnPos[] = {};
      garageSpawnDir = 0;
      garageBlacklists[] = {};
	    lightPos[] = {0,-2,3.8};
    };

	class Land_ivory_trailer_05 {
      price = 50000;
	    numberCrates = 1;
      restrictedPos[] = {};
      canGarage = true;
      garageSpawnPos[] = {};
      garageSpawnDir = 0;
      garageBlacklists[] = {};
	    lightPos[] = {0,-2,3.8};
    };

	class Land_ivory_trailer_06 {
      price = 50000;
	    numberCrates = 1;
      restrictedPos[] = {};
      canGarage = true;
      garageSpawnPos[] = {};
      garageSpawnDir = 0;
      garageBlacklists[] = {};
	    lightPos[] = {0,-2,3.8};
    };
	
	class Land_mpx_bikerbar {
      price = 1;
	    numberCrates = 1;
      restrictedPos[] = {};
      canGarage = true;
      garageSpawnPos[] = {};
      garageSpawnDir = 0;
      garageBlacklists[] = {};
	    lightPos[] = {0,-2,3.8};
    };



    //GANG SHED
     class Land_i_Shed_Ind_F {
      price = 5000000;
      numberCrates = 1;
      lightPos[] = {0,-2,3.8};
    };

    };
};
