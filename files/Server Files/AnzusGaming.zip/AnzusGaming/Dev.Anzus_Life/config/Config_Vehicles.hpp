class CarShops {
    class civ_car {
        conditions = "playerside isEqualTo civilian || call(life_copdept) in [6,7,8]";
        vehicles[] = {
            { "d3s_crown_98", "" }
        };
       };


    };

   class LifeCfgVehicles {

       class Default {
           vItemSpace = -1;
           conditions = "";
           price = -1;
           textures[] = {};
       };


        class B_supplyCrate_F { vItemSpace = 700; conditions = ""; price = -1; textures[] = {}; };
        class B_CargoNet_01_ammo_F { vItemSpace = 1000; conditions = ""; price = -1; textures[] = {}; };
        class Box_IND_Grenades_F { vItemSpace = 350; conditions = ""; price = -1; textures[] = {}; };
        class Land_WoodenCrate_01_F { vItemSpace = 50; conditions = ""; price = -1; textures[] = {}; };
        class Land_CargoBox_V1_F { vItemSpace = 100; conditions = ""; price = -1; textures[] = {}; };

        //AIR
     
        
};