/*
*    Format:
*        3: STRING (Conditions) - Must return boolean :
*            String can contain any amount of conditions, aslong as the entire
*            string returns a boolean. This allows you to check any levels, licenses etc,
*            in any combination. For example:
*                "call life_coplevel && license_civ_someLicense"
*            This will also let you call any other function.
*
*/
class CfgSpawnPoints {
	class Anzus_Life {
        class Civilian {
			class Kamdan {
                displayName = "Kamdan Central";
                description = "Kamdan Central: The Main city of the island and the capitol of Kamdan County.";
                spawnMarker[] = {"civ_spawn_metropolis","civ_spawn_metropolis_1","civ_spawn_metropolis_2"};
                icon = "\AnzusLifeCore\images\displays\displaySpawns\TreeIcons\spawn.paa";
                conditions = "";
            };
        };

        class Cop {
            class KamdanHQ {
                displayName = "Kamdan State Police HQ";
                description = "Main Police Headquarters";
                spawnMarker = "cop_spawn_1";
                icon = "\AnzusLifeCore\images\displays\displaySpawns\TreeIcons\safehouse.paa";
                conditions = "";
            };
        };

        class Medic {
            class KamdanHospital {
                displayName = "Kamdan Hospital";
                description = "Main hospital of Kamdan";
                spawnMarker = "medic_spawn_1";
                icon = "\AnzusLifeCore\images\displays\displaySpawns\TreeIcons\safehouse.paa";
                conditions = "";
            };
        };
    };
};
