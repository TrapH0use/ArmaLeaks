class CfgPatches {
    class AnzusLife_BackEnd {
        units[] = {};
        weapons[] = {};
        requiredAddons[] = {};
        fileName = "AnzusLife_BackEnd.pbo";
        author = "Travis Butts & The Pro Anti Hack Dev";
    };
};