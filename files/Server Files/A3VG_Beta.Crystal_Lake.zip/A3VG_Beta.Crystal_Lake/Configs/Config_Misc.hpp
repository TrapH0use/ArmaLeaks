class Misc {
	class CriminalCode {
		felonies[] = {
			{"Murder","60 Minutes (+30 minutes per aggravating circumstance)","Directly or indirectly causing the death of a person with intent (not revived by EMS). Aggravated: (i) The victim was a LEO or a government official."},
			{"Attempted Murder","45 Minutes (+15 minutes per aggravating circumstance)","Directly or indirectly causing the death of a person where the person was able to be revived by EMS. Aggravated: (i) The victim was a LEO or a government official (cannot stack)"},
			{"Manslaughter","25 Minutes","Causing the death or injury of a person without intent. The crime of killing a human being without malice aforethought, or otherwise in circumstances not amounting to murder."},
			{"Weapon Stockpiling","30 Minutes + 5 Minutes Per Weapon","Possession of 9 or more Class 2 Firearms in a place of storage. (Class 1 without a License) (i) Convicted Felon"},
			{"Weapon Caching","20 Minutes + 5 Minutes Per Weapon","Possession of 1-8 class 2 firearms in a place of storage (Class 1 without a license), (i) Convicted Felon"},
			{"Weapons Distribution","30 Minutes","Sale of Weapons without a license, Sale of Illegal weapons"},
			{"Possession of Explosives","40 Minutes","Possession of a regulated explosive device."},
			{"Possession of a Class 2 Firearm","20 Minutes","Possession of a Class 2 Firearm. Aggravated: (i) by a Convicted Felon."},
			{"Possession of a Class 1 Firearm","15 Minutes","Possession of a Class 1 Firearm without a license. Aggravated: (i) by a Convicted Felon."},
			{"Unlawful Discharge of a Firearm","15 Minutes","Discharging a Class 1 or Class 2 firearm without a lawful reason. (Does not stack with Murder, Atempted Murder, or Battery.)"},
			{"Battery (1st Degree)","20 Minutes. Aggravated: +5 minutes per (max 2)","Direct application of force where if, completed could have resulted in bolidly harm or death. Aggravated: (i) The victim was a LEO or a government official. (ii) Assault with a deadly weapon. (hitting with a gun or axe etc)"},
			{"Battery (2nd Degree)","15 Minutes. Aggravated: +5 minutes per (max 2)","Direct application of force where if, completed could have resulted in bolidly harm. Aggravated: (i) The victim was a LEO or a government official. (ii) Assault with a deadly weapon. (hitting with a gun or axe etc)"},
			{"Bank robbery","30 Minutes. Aggravated: +5 Minutes per","Removing property from the vault of a bank. Aggravated: (i) Possessing a deadly weapon in the commission of the offence."},
			{"Robbery","15  Minutes. Aggravated: +5 Minutes per","The taking of property from a person against their will by violence or intimidation. Aggravated: (i) Robbery with a deadly weapon. (ii) If the robbery involves the robbery of pharmaceuticals from a pharmacy"},
			{"Kidnapping","20 Minutes. Aggravated: +10 minutes per",""},
			{"Organ Harvesting","20 Minutes","The act of removing or possesing human organs (non stackable)"},
			{"Drug Cultivation and Manufacturing","20 minutes","The planting, harvesting, or processing of controlled substances. (15 or more seeds is Intent to Cultivate = 1/2 time)"},
			{"Class 2 Drug Distribution / Trafficking","20 minutes. Additional Charge: +5 minutes per","Possession of more than six Class 2 Drugs on a person, in a place of residence, or vehicle. Additional Charge: (i) Per additional 20 units"},
			{"Class 2 Drug Possession","15 minutes","Possession of 5 or less units of Class 2 Drugs."},
			{"Class 1 Drug Distribution / Trafficking","15 minutes","Possession of more than twenty Class 1 Drugs on a person, in a place of residence, or vehicle."},
			{"Uranium Possesion","25 minutes","Possesion of any form or quantity of nuclear material."},
			{"Grand Theft Auto","20 minutes","Operation of a motor vehicle without the permission of the registered owner (excluding ATVs, go karts, and motorcycles) (or theft by tow truck or other means). Proof of permission can be evidenced by presenting the keys of the vehicle."},
			{"Felony Evading","15 minutes","Operating a motor vehicle with the intent to evade LEO acting lawfully or otherwise attempting to elude or evade pursuing LEO. (Cannot stack with Fleeing and Eluding.)"},
			{"Violation of No Fly Zone","20 minutes","Flying over regulated airspace, including the DOC, LEO Facilities, and landing within City Limits."},
			{"Felony Improper operation of a motor vehicle","20 minutes","Erratic or excessive speeding (60+ km/h over the Lawful Speed) without lawful justification, endangering the public or occurring in the city. Or with wanton disregard for public safety."},
			{"Felony Driving Under the Influence","20 minutes","Operating a motor vehicle after having received three previous DUI convictions."},
			{"Impersonating a Lawyer or Government Official.","15 minutes","Intentionally or negligently misrepresenting themselves to be a Bar Certified Lawyer or Government Official, including by operating a LEO vehicle or making assertions."},
			{"Corruption","45 minutes","A breach of public trust and/or abuse of a government position with or without private sector accomplices."},
			{"Resisting Arrest","10 minutes","Preventing or attempting to prevent an LEO from lawfully effecting an arrest (with or without a warrant) against any person."},
			{"Burglary","15 minutes","Unlawfully entering into a residential address illegally and/or removing personal property."},
			{"Racketeering / RICO","Forfeiture of Assets depending on severity. RICO: +10 minutes per count","Racketeer Influenced and Corrupt Organizations Clause, commonly referred to as RICO provides for extended criminal penalties and a civil cause of action for acts performed in support of or part of an ongoing criminal organization. RICO: Allows leaders of the racket to be tried for ordering the crime even without conducting it themselves."},
			{"Extortion","15 minutes","Unlawfully obtaining property (both tangible and intangible) through the use of force or threats."},
			{"Hate Crime","5 minutes per charge (added on to another charge)","Criminal acts that are seen to have been motivated by bias against one or more protected Class of individuals."},
			{"Escaping Custody","15 Minutes","Fleeing the lawful custody of LEOs (Detainment, Arrest, or Confinement)"},
			{"Fleeing & Eluding","10 minutes","Willfully fleeing with the intent to evade LEO acting lawfully or otherwise attempting to elude or evade pursuing LEO."},
			{"Accessory to Escape","5 minutes","Aiding, assisting or otherwise facilitating the escape of a detained or incarcerated person or persons."},
			{"Contempt of Court","20 minutes","Offense of being belligerent, disobedient to or disrespectful towards a court of law and its officers in the form of behavior that opposes or defies authority, justice, and dignity of the court especially where imminent danger exists. Lawyers may be disbarred for this offense. Failure to follow the courts order you could be held in jail until you comply with the orders."},
			{"Obstruction of Justice","20 minutes","Unlawfully hindering the discovery, apprehension, conviction, defense or punishment of anyone who has committed a crime or of evidence or bribery, murder, intimidation, and the use of physical force against a witnesses, law enforcement officers or court officials to prevent justice from being served."},
			{"Conspiracy","15 minutes","The planning of a crime between 2 or more persons. (i) If conspiring to murder add an additional 15 minutes (Placing a bounty on individuals.)"},
			{"Embezzlement","15 minutes","Theft or misappropriation of funds placed in one's trust."},
			{"Money Laundering","30 minutes","Transforming the proceeds of crime are into legitimate money or other assets."},
			{"Poaching","20 minutes +$80 per meat","Killing of animals outside of the hunting grounds (hunting grounds are defined by a green zone on the map). The charge will be at the discretion of the officer on scene. (ii) Killing, or capturing of protected wildlife (Turtle). (Possession of Turtle Meat)"},
			{"Possession of Stolen Goods","5 minutes","Having bought, been given, or acquired stolen goods. (including guns from a Police armory)"},
			{"Perjury","10 minutes","Submitting a false statement while under oath."},
			{"Jailbreak","35 minutes","The act of an individual, or a group of individuals, using means of aggression, lethal force or other acts to attempt to or successfully coerce the release of; or forcefully gain access and remove; an individual who is serving an active sentence at the Department of Corrections."},
			{"Attempted commission of an offence/crime","50% of prescribed time for each listed charge (round up)","Attempting to commit an offence listed under this Act. Attempting means performing the necessary steps in the commission of an offence however, having not committed the offence itself. It is irrelevant if the offence was not committed due to intervention by LEO, a sudden change of mind after the necessary steps had been carried out or any other intervening factor preventing its commission."}


		};
		misdemeanors[] = {
			{"Battery (3rd Degree)","10 minutes","Direct application of force which casued bodily injury. Upgrades to Felony if: (i) If the victim was a LEO or a government official, the charge will upgrade to Battery of the 2nd Degree."},
			{"Aiding & Abetting / Accessory to X charge","5 minutes","Helping or allowing a crime to succeed."},
			{"Class 1 Drug Possession (more than 5)","10 minutes","Possession of 5 or more Class 1 drugs. (See Definitions of Class 1 Drugs)"},
			{"Drug Paraphernalia","5 minutes","Seeds of the Opium and/or Cannabis plant. (More than 15 seeds = Drug Cultivation and Manufacturing Felony)"},
			{"False Report","5 minutes","False statements and 911 dispatch messages."},
			{"Contempt of Court","10 minutes","The charge of Contempt of Court shall carry with it a punishment of imprisonment of up to 20 minutes in Jail and/or a fine of up to $4,000. Sufficient warning shall be required to be issued to the offender prior to levying such a penalty. A defendant may only be charged once for Contempt. If the offender continues to create a disturbance that impedes the functionality of the court, they shall be deemed hostile, and either (1) waive their 9th Amendment right for the current case, their plea converted to No-Contest, and a Default Judgment ordered. OR (2) removed from the area and their Lawyer proceed without the defendant being present."},
			{"DUI / DWI","20 minutes","Driving under the influence of legal or illegal drugs or Alcohol."},
			{"Firearms (Discharged w/ Lic)","10 minutes","Unlawful firing of a firearm, such as a pistol or shotgun, but they may also apply to other weapons such as paintball guns"},
			{"Public Intoxication","5 minutes","Being visibly drunk or under the influence of drugs in public."},
			{"Plotting to X ","10 minutes","Plotting to (Kidnap a Government Official/LEO, rob a bank etc.)"},
			{"Trespassing (House or Car)","5 minutes","Unauthorized entry upon the soil of a restricted area, Especially when causing a disruption. (300M radius of the Jail, and within 50M of other City property lines (ex PD, Courthouse, or where posted.) i) Fleeting Tresspass (if a vehcile is involved) "},
			{"Bribery/Accepting a Bribe","15 minutes","Persuading someone to commit an illegal act in exchange for a gift of money, service or other item.or Accepting the same."},
			{"Illegal Ammunition","5 minutes","Possession of a Magazine of a Class II Firearm Ammunition (Each magazine counts for one charge of Illegal Ammunition, up to 5 max (Unless in a residence)) or Possession of a Magazine of a Class I Firearm Ammunition (Each magazine counts for one charge of Illegal Ammunition, up to 5 max without a valid Firearm or Rifle License(unless in a residence))"},
			{"Indecent Exposure","5 minutes","Not wearing clothing"},
			{"Prostitution","5 minutes","Solicitation of money, goods, or services, for sexual favors"},
			{"Stalking","5 minutes","Unwanted or obsessive attention by an individual or group toward another person with or without the intention to harm."},
			{"Improper operation of a motor vehicle","10 minutes","Erratic (out of lane) or excessive speeding (25+ km/h over the Lawful Speed) with wanton disregard for public safety. (i.e. Using a forklift in a manner dangerous to the public, driving in reverse with or against the flow of traffic)"},
			{"Hit and Run","5 minutes","The act of causing (or contributing to) a traffic accident (such as colliding with a person or a fixture), and failing to stop and identify oneself afterwards and resolving it with the police."},
			{"Failure to identify","Indefinite Detainment","You are legally required to identify yourself  if being detained on reasonable suspicion you  committed, are committing, or are about to commit an offence. In addition in a traffic stop you are legally required to provide your name and licence if you are the driver of a motor vehicle, regardless if an offence is committed or not. Failure to do so is an offence."},
			{"Obstructing Traffic","$1000 fine","Creating an unsafe or obstructed driving environment. (like standing or placing objects in the roadway)"},
			{"False Representation of Identity","5 minutes","Providing a fake ID or false name to a LEO while detained."},
			{"Possession of contraband","5 minutes","Bolt Cutters (anytime), Lock picks (without driving a tow truck), Turtle Soup, Police equipment (GTA may apply as well if a vehicle applies), Zip Ties (unless a registered Bounty Hunter), Taser Guns (unless a registered Bounty Hunter (i)), Bean Bag Shotguns (unless a registered Bounty Hunter(ii)), Inmate Jumpsuit is government property. None of this applies to DOJ/SO unless used to commit a crime. May only be charged with 1 count of contraband (even with multiple items)"},
			{"Disorderly Conduct","5 minutes","The wilful violation of a lawful order from an LEO or the inciting of violence through words or actions"},
			{"Solicitation","5 minutes","A crime, an inchoate offense that consists of a person offering money or inducing another to commit a crime with the specific intent that the person solicited commit the crime"},
			{"Assault","10 minutes","An attempt or threat to initiate bodily harm against a person or persons. (Reasonable belief the threat could have been carried out) Aggravated: (i) Threat was against an LEO or government official."},
			{"Destruction of Property","5 minutes","Through intentional or negligent action causing the destruction of property. Aggravated: (i) Government property; (not limited to) Blasting jail and bank doors; damaging government vehicles, structures, or records."},
			{"Harassment","10 minutes","Unwanted, unwelcome, and uninvited behavior that demeans or threatens the victim and results in a hostile environment for the victim."},
			{"Theft","10 minutes. Grand Theft: +5 minutes","The taking of property from a person against their will. Property may includes services (ie. repair services, transportation services, ect) Grand Theft: (i) Theft of property stolen exceeds $10,000 (Becomes a Class 6 Felony)"},
			{"Petty Theft","5 minutes + Fine equal to value of property","Taking of property from a person against their will. Value of stolen property must be equal or less than $1000. Property may includes services (ie. repair services, transportation services, ect)"}

		};
		infractions[] = {
			{"Brandishing a Firearm","$4,000 + Removal of Weapon","Improper exhibition, unlawful display or threatening action with a firearm, wave or flourish (something, especially a weapon) as a threat or in anger or excitement."},
			{"Reckless Driving (25 km/h over)","$3,000 + Impound","Erratic (out of lane/sidewalk) or excessive speeding (25+ km/h over the Lawful Speed)."},
			{"Speeding 15-25 km/h","$2,000","Speeding 15-25 km/h over the Lawful Speed."},
			{"Speeding 10-15 km/h","$750","Speeding 10-15 km/h over the Lawful Speed."},
			{"Aggressive Driving","$1,000","Swerving in lane, cutting corners, tailgating or endangering/impeding the safe flow of traffic."},
			{"Unsafe work environment (OSHA)","$2,500","Any mining/processing,or other work area, where vehicles may be precariously operated or parked to cause a danger to the workers or the public. (i.e. work trucks, forklifts, dump trucks)"},
			{"Disturbing the Peace","$1,000","Engaging in some form of disorderly conduct, such as fighting or threatening to fight in public, causing excessively loud noise, by shouting, playing loud music, honking of horns."},
			{"Failure to Yield to emergency vehicles","$800","Failure to yield right-of-way to emergency vehicles with active siren and/or lights."},
			{"Unlawful Solicitation","$500","Act of offering to sell, or attempting to purchase illegal goods or services."},
			{"Failure to Stop","$500","Failure to come to a complete stop at a posted Stop Sign or steady beam Red Light(does not apply to broken and/or malfunctioning Traffic Lights)"},
			{"Operation of a non street legal vehicle","$750 + Impound","Driving an ATV, Race Cart, Prowler, Qilin or Forklift at any time, on city streets."},
			{"Operating a vehicle without a license.","$1,000 + Impound","Driving any street vehicle without a proper licence. (Standard Vehicle = Driver License, Truck = Truck License, Aircraft = Pilot License) (Arrestable as Improper Operation of a Motor Vehicle after 3rd Offence)"},
			{"Illegal parking","$250","Parking improperly, in a lane, on a sidewalk or any area deemed to be a hazard to include restricted zones."},
			{"Excessive Vehicle Noise","$500","Horns, music or revving of engines that cause a public nuisance."},
			{"Failure to Yield","$800","Failure to yield right-of-way at a posted yield sign, pedestrians in crosswalk, or Right turn on steady beam Red Light."},
			{"Jaywalking","$500","Crossing the street without using a crosswalk (only applicable when the citizen causes a danger for vehicles on the road)"},
			{"Driving without proper use of headlights.","$750","Driving without headlights from Dusk to Dawn. (even if NVGs are being used)"},
			{"Loitering","$500","Act of remaining in a particular public place without an apparent purpose and being given a lawful order to disperse by an LEO."},
			{"Operation of a Motorcycle without a helmet","$1000","Operating any type of motorcycle whilst not wearing a helmet. (Arrestable as Improper Operation of a Motor Vehicle after 3rd Offence)"}

		};
		definitions[] = {
			{"Drug Paraphernalia","Seeds of the (Opium, Cannabis, or Coca plant) (Seeds of All Class 1 & 2 drugs)"},
			{"Class 1 Drug","Cannabis plant, Marijuana or Gamma Hydroxybutyrate (Commonly known as GHB)"},
			{"Class 2 Drug","Opium Flowers, Heroin, Coca Plant, Cocaine, Psuedoephedrine, Benzodiazepin, Amphetamine or any drug not defined as a Class 1 drug."},
			{"Class 1 Firearm","Any semi automatic pistol, revolver (or semi-automatic rifle or shotgun legally purchased such as the AR-10, AR-15, Kar 98, Mossberg 590 and SDAR with appropriate licensure detailed below)"},
			{"Class 2 Firearm","Any long rifle or long gun (except the Kar 98, AR-10, AR-15, and Mossberg 590 if a rifle license is possessed in conjunction with a firearms license or the SDAR when possessed on conjunction with a rifle license, firearms license and diving license), sub machine gun, fully automatic capable, or larger than .45 caliber weapon (except the .454)."},
			{"Bail","Money needed for a suspect to be released from custody to await trial. Max Sentence X$2000"},
			{"Bond","Money covered by someone else (a certified bail bondsman) providing a sureity bond to the court. (bailing someone else out) Max Sentence X$3000"},
			{"Reasonable suspicion (identify/detain)","LEOs need no justification to stop someone on a public street and ask questions, and individuals are completely entitled to refuse to answer any such questions and go about their business (unless detained.) However, a police officer may only search people and vehicles when the officer has probable cause. They may reasonably suspect a person or persons have been, is, or is about to be engaged in criminal activity; it depends upon the totality of circumstances, and can result from a combination of particular facts, even if each is individually innocuous."},
			{"Probable Cause (warrants/arrest/Search and Seizure)","Reasonable belief, based on facts that can be articulated, that a particular person has committed a crime, especially to justify making a search or pressing charges. (The statements made by the drug dealers can be used as probable cause for a search of a suspect and their vehicular property during an investigation."},
			{"Detained","A suspect can be detained at any location (for no more than 60 minutes) if a police officer believes you may be involved in a crime and has reasonable suspicion. (includes transportation time by LEO. Ex. From Location of detainment to PD or Hospital to PD)"},
			{"Clothing subject to search","Any civilians wearing masks or concealing their identity within the cities of Crystal Lake can be subject to a stop and search by an LEO (City limits are shown in the pictures under the second tab). Other items which could trigger an immediate stop and search include police/government accoutrements such as gas masks or police issued gear/uniforms."},
			{"Right to Representation","A LEO must attempt in good faith to contact a bar certified lawyer if one is requested (for no less than 10 minutes) (Defendants may self represent if they choose to go to court with a Judge.)"},
			{"Plea Bargain (Optional)","An agreement in a criminal case between the prosecutor (or LEO) and defendant (with a lawyer) whereby the defendant agrees to plead guilty to a certain charges in return for some concession from the prosecutor/LEO."},
			{"Aggrivated Circumstances","Can be applied to any crime of felony nature if violent circumstances exist during the commision of the felony (unless otherwise stated)."},
			{"Maximum Punishment","The maximum time that can be assigned by a member of the Sheriff's department, DOC, or DA's office to a guilty party for a single incident is 90 minutes. This time may be increased with a judge's order, or thru a sentencing phase in trial."},
			{"Statute of limitations","The Statute of Limitations is 30 days from the last crime being charged to obtain the warrant."},
			{"Protected Speech","A person's words alone will rarely, if ever, rise to the level of Disobeying a Lawful Order of Police. Rather the words must usually be accompanied by obstructive physical conduct to support a conviction for Disobeying a Lawful Order of Police."},
			{"Speed Limits","Dirt Pathways shall have no posted limit; Unsafe maneuvering, swerving, or impeding oncoming traffic shall result in a Class 21e Misdemeanour ‘Improper Operation of a Motor Vehicle’. Two Lane Roads shall be limited to a Maximum Allowed Speed of 120 km/h. Four Lane Highways shall be limited to a Maximum Allowed Speed of 160 km/h. Exceptions shall be made for Roads that directly touch the outskirts of a town. Roads that directly touch the outskirts of a town shall be limited to a Maximum Allowed Speed of 50 km/h."},
			{"Probable Cause for Terry Stop","In order to pull over a suspect you must have probable cause. Probable cause will rely on the evidence obtained in an investigation (whether a police report is filed or an officer witnesses a crime i.e. Person is in the exact outfit with exact Vehicle being reported). An officer would have the right to search a person if the crime reported was a violent crime and is acting in a manner to ensure public safety. However, in order to search a vehicle or passengers, a new threshold of Probable Cause would need to be reached. In order for a search or seizure, the officer MUST have articulable facts as to why he/she would need to search the vehicle/persons."},
			{"Exigent Circumstance","Exigent Circumstances as: An emergency situation requiring swift action to prevent imminent danger to life or serious damage to property, or to forestall the imminent escape of a suspect, or destruction of evidence. These circumstances should be seen as only viable in extraordinary situations, and not used in everyday investigations. If a judge or Justice is available this cannot be used to circumnavigate the warrant application process. Abuse of this will not be tolerated. (This applies only when your suspect not within or near his/her vehicle)."},
			{"Inteligence Leaks","Leaking of sensitive information (Frequencies, Warrants, operational intel) that obstructs justice may be fined up to $40,000 with a reward paid for information leading to an arrest - up to the fine amount."},
			{"Convicted Felon","A Convicted felon is anyone who has been charged and found guilty of a felony within the last 3 days."},
			{"Impound / Inventory of Vehicles","Any vehicle that is materially or criminally involved in a crime or police incident that meets the criteria of being impounded per the criminal code shall first be inventoried."}
		};
	};

	class Items {
		Wheat_Seed = "active_seed = 'Wheat_Seed'; [format['You have selected %1 as your active seed.',active_seed]] call DT_fnc_notify";
		olive_Seed = "active_seed = 'olive_Seed'; [format['You have selected %1 as your active seed.',active_seed]] call DT_fnc_notify";
		cotton_Seed = "active_seed = 'cotton_Seed'; [format['You have selected %1 as your active seed.',active_seed]] call DT_fnc_notify";
		pumpkin_Seed = "active_seed = 'pumpkin_Seed'; [format['You have selected %1 as your active seed.',active_seed]] call DT_fnc_notify";
		corn_Seed = "active_seed = 'corn_Seed'; [format['You have selected %1 as your active seed.',active_seed]] call DT_fnc_notify";
		sunflower_Seed = "active_seed = 'sunflower_Seed'; [format['You have selected %1 as your active seed.',active_seed]] call DT_fnc_notify";
		opium_seed = "active_seed = 'opium_seed'; [format['You have selected %1 as your active seed.',active_seed]] call DT_fnc_notify";
		weed_seed = "active_seed = 'weed_seed'; [format['You have selected %1 as your active seed.',active_seed]] call DT_fnc_notify";
		coca_seed = "active_seed = 'coca_seed'; [format['You have selected %1 as your active seed.',active_seed]] call DT_fnc_notify";
		D_GoPro_i = "client_goPro = !client_goPro";
		D_Battery_i = "player setVariable ['phoneBattery',((player getVariable ['phoneBattery',100]) + 50) min 100,[clientOwner,2]]; ['You successfully charged your phone.','green'] call DT_fnc_notify; [{player removeItem 'D_Battery_i'}] call CBA_fnc_execNextFrame";
		D_WaterBottle_i = "['D_WaterBottle_i',100] call DT_fnc_handleDrink; [{player removeItem 'D_WaterBottle_i'}] call CBA_fnc_execNextFrame";
		D_Redgul_i = "['D_Redgul_i',75] call DT_fnc_handleDrink; [{player removeItem 'D_Redgul_i'}] call CBA_fnc_execNextFrame";
		D_Coffee_i = "['D_Coffee_i',75] call DT_fnc_handleDrink; [{player removeItem 'D_Coffee_i'}] call CBA_fnc_execNextFrame";
		D_Franta_i = "['D_Franta_i',75] call DT_fnc_handleDrink; [{player removeItem 'D_Franta_i'}] call CBA_fnc_execNextFrame";
		D_Can_SuperstarEnergy_i = "['D_Can_SuperstarEnergy_i',75] call DT_fnc_handleDrink; [{player removeItem 'D_Can_SuperstarEnergy_i'}] call CBA_fnc_execNextFrame";
		D_Can_Pepsi_i = "['D_Can_Pepsi_i',75] call DT_fnc_handleDrink; [{player removeItem 'D_Can_Pepsi_i'}] call CBA_fnc_execNextFrame";
		D_Can_Monster_i = "['D_Can_Monster_i',75] call DT_fnc_handleDrink; [{player removeItem 'D_Can_Monster_i'}] call CBA_fnc_execNextFrame";
		D_Can_DrPepper_i = "['D_Can_DrPepper_i',75] call DT_fnc_handleDrink; [{player removeItem 'D_Can_DrPepper_i'}] call CBA_fnc_execNextFrame";
		D_Can_7UP_i = "['D_Can_7UP_i',75] call DT_fnc_handleDrink; [{player removeItem 'D_Can_7UP_i'}] call CBA_fnc_execNextFrame";
		D_TacticalBacon_i = "['D_TacticalBacon_i',60] call DT_fnc_handleFood; [{player removeItem 'D_TacticalBacon_i'}] call CBA_fnc_execNextFrame";
		D_Sausages_i = "['D_Sausages_i',60] call DT_fnc_handleFood; [{player removeItem 'D_Sausages_i'}] call CBA_fnc_execNextFrame";
		D_FoodCan_DicksSausage_i = "['D_FoodCan_DicksSausage_i',60] call DT_fnc_handleFood; [{player removeItem 'D_FoodCan_DicksSausage_i'}] call CBA_fnc_execNextFrame";
		D_Sandwich_i = "['D_Sandwich_i',60] call DT_fnc_handleFood; [{player removeItem 'D_Sandwich_i'}] call CBA_fnc_execNextFrame";
		D_Toast_i = "['D_Toast_i',40] call DT_fnc_handleFood; [{player removeItem 'D_Toast_i'}] call CBA_fnc_execNextFrame";
		D_Banana_i = "['D_Banana_i',30] call DT_fnc_handleFood; [{player removeItem 'D_Banana_i'}] call CBA_fnc_execNextFrame";
		D_Kiwi_i = "['D_Kiwi_i',30] call DT_fnc_handleFood; [{player removeItem 'D_Kiwi_i'}] call CBA_fnc_execNextFrame";
		D_FoodCan_DogFood_i = "['D_FoodCan_DogFood_i',25] call DT_fnc_handleFood; closeDialog 0; [{player removeItem 'D_FoodCan_DogFood_i'}] call CBA_fnc_execNextFrame";
		D_Donut_i = "['D_Donut_i',50] call DT_fnc_handleFood; [{player removeItem 'D_Donut_i'}] call CBA_fnc_execNextFrame";
		CG_Spikes_Collapsed = "['CG_Spikes_Collapsed'] call DT_fnc_setupItem; [{player removeItem 'CG_Spikes_Collapsed'}] call CBA_fnc_execNextFrame";
		Roadcone_Boxed = "['Roadcone_Boxed'] call DT_fnc_setupItem; [{player removeItem 'Roadcone_Boxed'}] call CBA_fnc_execNextFrame";
		Wood_Barrier_Boxed = "['Wood_Barrier_Boxed'] call DT_fnc_setupItem; [{player removeItem 'Wood_Barrier_Boxed'}] call CBA_fnc_execNextFrame";
		Concrete_Barrier_Boxed = "['Concrete_Barrier_Boxed'] call DT_fnc_setupItem; [{player removeItem 'Concrete_Barrier_Boxed'}] call CBA_fnc_execNextFrame";
		Wardrobe = "['Wardrobe'] call DT_fnc_placeFurniture; [{player removeItem 'Wardrobe'}] call CBA_fnc_execNextFrame";
		MW_tablet = "[false] call DT_fnc_startJailbreak";
		VG_PanicButton = "[player] remoteExecCall ['DT_fnc_panic',(['cop'] call DT_fnc_findPlayers)]";
		//New Drinks
		np_coke = "['np_coke',75] call DT_fnc_handleDrink; [{player removeItem 'np_coke'}] call CBA_fnc_execNextFrame";
		np_drpepper = "['np_drpepper',75] call DT_fnc_handleDrink; [{player removeItem 'np_drpepper'}] call CBA_fnc_execNextFrame";
		np_energydrink = "['np_energydrink',50] call DT_fnc_handleDrink; [{player removeItem 'np_energydrink'}] call CBA_fnc_execNextFrame";
		//Alcohol
		np_tequila = "['np_tequila',25] call DT_fnc_handleDrink; ['np_tequila',0.08] call DT_fnc_handleAlcohol; [{player removeItem 'np_tequila'}] call CBA_fnc_execNextFrame";
		np_beer = "['np_beer',35] call DT_fnc_handleDrink; ['np_beer',0.05] call DT_fnc_handleAlcohol; [{player removeItem 'np_beer'}] call CBA_fnc_execNextFrame";
		//Food Items
		np_chickensoup = "['np_chickensoup',60] call DT_fnc_handleFood; [{player removeItem 'np_chickensoup'}] call CBA_fnc_execNextFrame";
		np_peasoup = "['np_peasoup',60] call DT_fnc_handleFood; [{player removeItem 'np_peasoup'}] call CBA_fnc_execNextFrame";
		np_beefsoup = "['np_beefsoup',60] call DT_fnc_handleFood; [{player removeItem 'np_beefsoup'}] call CBA_fnc_execNextFrame";
		np_tuna = "['np_tuna',60] call DT_fnc_handleFood; [{player removeItem 'np_tuna'}] call CBA_fnc_execNextFrame";
		np_groceries = "['np_groceries',100] call DT_fnc_handleFood; [{player removeItem 'np_groceries'}] call CBA_fnc_execNextFrame";
		//Pizza
		np_hpizza = "['np_hpizza',75] call DT_fnc_handleFood; [{player removeItem 'np_hpizza'}] call CBA_fnc_execNextFrame";
		np_mpizza = "['np_mpizza',75] call DT_fnc_handleFood; [{player removeItem 'np_mpizza'}] call CBA_fnc_execNextFrame";
		np_cpizza = "['np_cpizza',75] call DT_fnc_handleFood; [{player removeItem 'np_cpizza'}] call CBA_fnc_execNextFrame";
		np_spizza = "['np_spizza',75] call DT_fnc_handleFood; [{player removeItem 'np_spizza'}] call CBA_fnc_execNextFrame";
		np_vpizza = "['np_vpizza',75] call DT_fnc_handleFood; [{player removeItem 'np_vpizza'}] call CBA_fnc_execNextFrame";
		//McDonalds
		np_happymeal = "['np_happymeal',50] call DT_fnc_handleFood; [{player removeItem 'np_happymeal'}] call CBA_fnc_execNextFrame";
		np_bigmac = "['np_bigmac',50] call DT_fnc_handleFood; [{player removeItem 'np_bigmac'}] call CBA_fnc_execNextFrame";
		np_mchicken = "['np_mchicken',50] call DT_fnc_handleFood; [{player removeItem 'np_mchicken'}] call CBA_fnc_execNextFrame";
		np_quater = "['np_quater',50] call DT_fnc_handleFood; [{player removeItem 'np_quater'}] call CBA_fnc_execNextFrame";
		np_cheeseburger = "['np_cheeseburger',50] call DT_fnc_handleFood; [{player removeItem 'np_cheeseburger'}] call CBA_fnc_execNextFrame";
		np_hamburger = "['np_hamburger',50] call DT_fnc_handleFood; [{player removeItem 'np_hamburger'}] call CBA_fnc_execNextFrame";
		np_hotdog = "['np_hotdog',50] call DT_fnc_handleFood; [{player removeItem 'np_hotdog'}] call CBA_fnc_execNextFrame";
		np_mhotdog = "['np_mhotdog',50] call DT_fnc_handleFood; [{player removeItem 'np_mhotdog'}] call CBA_fnc_execNextFrame";
		np_kmhotdog = "['np_kmhotdog',50] call DT_fnc_handleFood; [{player removeItem 'np_kmhotdog'}] call CBA_fnc_execNextFrame";
		np_bbqhotdog = "['np_bbqhotdog',50] call DT_fnc_handleFood; [{player removeItem 'np_bbqhotdog'}] call CBA_fnc_execNextFrame";
		np_cheesehotdog = "['np_cheesehotdog',50] call DT_fnc_handleFood; [{player removeItem 'np_cheesehotdog'}] call CBA_fnc_execNextFrame";
		//Donuts
		np_donuts = "['np_donuts',35] call DT_fnc_handleFood; [{player removeItem 'np_donuts'}] call CBA_fnc_execNextFrame";
		np_chdonuts = "['np_chdonuts',35] call DT_fnc_handleFood; [{player removeItem 'np_chdonuts'}] call CBA_fnc_execNextFrame";
		np_jdonuts = "['np_jdonuts',35] call DT_fnc_handleFood; [{player removeItem 'np_jdonuts'}] call CBA_fnc_execNextFrame";
		np_cdonuts = "['np_cdonuts',35] call DT_fnc_handleFood; [{player removeItem 'np_cdonuts'}] call CBA_fnc_execNextFrame";
		// Cigarettes
		murshun_cigs_cigpack = "[] call DT_fnc_handleItem; [{player removeItem 'murshun_cigs_cigpack'}] call CBA_fnc_execNextFrame; ['You feel less weapon sway due to your nicotene buzz.','blue'] call DT_fnc_notify; player setCustomAimCoef 0;[{player getVariable ['dead',false]},{player setCustomAimCoef 1;},[],300,{player setCustomAimCoef 1;['Your nicotene buzz has worn off.','blue'] call DT_fnc_notify;}] call CBA_fnc_waitUntilAndExecute;";
		np_drillItem = "[] call DT_fnc_bankRobbery;";
	};
	wordBlacklist[] = {"nig","spic","fuck","retard","wetback","gay","queer","kkk","fag","homo","chink","beaner","terrorist"};
	adminList[] = {"76561198071007604","76561198090083094","76561198282014773","76561198376183384","76561198169834895","76561198105905115","76561198207258127","76561198021137363","76561198376183384","76561198080306008","76561198074357023"};
};
