/*
Item shop configs work by:
	Name of store
	Conditions to enter store
	Items with format {"classname",buyprice,sellprice,"conditions"}
	If buyprice is -1, its unbuyable, same for selling
	Magazines work the same

Clothing shop configs work by:
	Conditions to enter store
	Clothing with format {"classname",buyprice,"conditions"}
Vehicle shop configs work by:
	Name of store
	Conditions to enter store
	Vehicles with format {"classname",buyprice,"conditions"}
*/
class Shops {
	class Items {
		class gun {
			name = "Logan's Firearms";
			conditions = "'gun' in client_licenses";
			items[] = {
				{"RH_mk2",2750,1375,""},
				{"RH_g17",3000,1500,""},
				{"RH_m9",2800,1400,""},
				{"RH_gsh18",3100,1550,""},
				{"RH_python",3600,1800,""},
				{"RH_cz75",3900,1950,""},
				{"RH_m1911",4000,2000,""},
				{"RH_usp",4150,2075,""},
				{"RH_bull",4750,2375,""}
			};
			mags[] = {
				{"RH_10Rnd_22LR_mk2",65,32,""},
				{"RH_17Rnd_9x19_g17",65,32,""},
				{"RH_15Rnd_9x19_M9",65,32,""},
				{"RH_18Rnd_9x19_gsh",65,32,""},
				{"RH_6Rnd_357_Mag",65,32,""},
				{"RH_16Rnd_9x19_CZ",65,32,""},
				{"RH_7Rnd_45cal_m1911",65,32,""},
				{"RH_12Rnd_45cal_usp",65,32,""},
				{"RH_6Rnd_454_Mag",65,32,""}
			};
		};

		class rebel {
			name = "Rebel Weapons Dealer";
			conditions = "'rebel' in client_licenses";
			items[] = {

				{"RH_kimber",5000,-1,""},
				{"RH_bullb",5750,-1,""},
				{"RH_fn57_t",7200,-1,""},
				{"RH_deagle",7500,-1,""},
				{"RH_Deagles",8500,-1,""},
				{"RH_Deagleg",10500,-1,""},
				{"RH_g18",10000,-1,""},
				{"RH_muzi",10000,-1,""},
				{"RH_vz61",10000,-1,""},
				{"RH_tec9",10000,-1,""},
				{"RH_sbr9_des",16250,-1,""},
				{"hlc_smg_mp5a3",19500,-1,""},
				{"hlc_rifle_aks74_MTK",27500,-1,""},
				{"hlc_rifle_aks74u_MTK",29500,-1,""},
				{"hlc_rifle_aku12",31000,-1,""},
				{"hlc_rifle_mk18mod0",36500,-1,""},
				{"RH_M16A3",39500,-1,""},
				{"FHQ_optic_AC11704",150,-1,""},
				{"FHQ_optic_AIM",150,-1,""},
				{"RH_compm2",150,-1,""},
				{"RH_compm2l",150,-1,""},
				{"RH_barska_rds",150,-1,""},
				{"HLC_optic_DocterR",150,-1,""},
				{"SMA_BARSKA",150,-1,""},
				{"SMA_MICRO_T2",150,-1,""},
				{"SMA_CMORE",150,-1,""},
				{"SMA_eotech552",150,-1,""},
				{"RH_eotech553",150,-1,""},
				{"RH_LTdocter",150,-1,""},
				{"FHQ_optic_MicroCCO",150,-1,""},
				{"RH_SFM952V",150,-1,""},
				{"D_Ziptie_i",5,-1,""},
				{"D_Redgul_i",5,-1,""},
				{"D_Bandage_i",5,-1,""},
				{"D_Splint_i",5,-1,""},
				{"D_Cast_i",5,-1,""},
				{"VG_Morphine",5,-1,""},
				{"D_GoPro_i",5,-1,""},
				{"D_Battery_i",5,-1,""},
				{"TFAR_anprc152",5,-1,""}
			};
			mags[] = {
				{"RH_7Rnd_45cal_m1911",100,-1,""},
				{"RH_20Rnd_32cal_vz61",100,-1,""},
				{"RH_6Rnd_454_Mag",100,-1,""},
				{"RH_33Rnd_9x19_g18",100,-1,""},
				{"RH_30Rnd_9x19_UZI",100,-1,""},
				{"RH_32Rnd_9x19_tec",100,-1,""},
				{"RH_7Rnd_50_AE",100,-1,""},
				{"RH_20Rnd_57x28_FN",100,-1,""},
				{"hlc_30Rnd_9x19_B_MP5",100,-1,""},
				{"RH_32Rnd_9mm_M822",100,-1,""},
				{"hlc_30Rnd_545x39_B_AK",100,-1,""},
				{"hlc_30rnd_556x45_EPR",250,-1,""},
				{"RH_30Rnd_556x45_M855A1",250,-1,""}
			};
		};

		class blackmarket {
			name = "Black Market Dealer";
			conditions = "";
			items[] = {
				{"RH_M4_moe_b",49500,-1,""},
				{"RH_M4m",41500,-1,""},
				{"SMA_M4afg_Tan_SM",45500,-1,""},
				{"MW_tablet",9750,-1,""},
				{"np_drillItem",10500,-1,""},
				{"NP_SatchelCharge",14000,-1,""}
				
			};
			mags[] = {
			{"SMA_30Rnd_556x45_Mk318",50,-1,""},
			{"RH_30Rnd_556x45_M855A1",50,-1,""}
			};
		};

		class genstore {
			name = "General Store";
			conditions = "";
			items[] = {
				{"D_GoPro_i",250,-1,""},
				{"TFAR_anprc152",5,-1,""},
				{"D_Bandage_i",10,-1,""},
				{"D_Splint_i",5,-1,""},
				{"D_Cast_i",5,-1,""},
				{"D_Battery_i",250,-1,""},
				{"D_Can_Monster_i",5,-1,""},
				{"D_Can_DrPepper_i",5,-1,""},
				{"np_chickensoup",5,-1,""},
				{"D_Banana_i",5,-1,""},
				{"Toolkit",150,-1,""},
				{"Binocular",150,-1,""},
				{"ItemGPS",100,50,""},
				{"ItemMap",50,25,""},
				{"ItemCompass",50, 25,""},
				{"ItemWatch",50,25,""},
				//{"D_iPhone9_i","Phone",10,50,""},
				{"NVGoggles",1000,500,""},
				{"NVGoggles_OPFOR",1000,500,""},
				{"NVGoggles_INDEP",1000,500,""},
				{"Chemlight_red",100,50,""},
				{"Chemlight_yellow",100,50,""},
				{"Chemlight_green",100,50,""},
				{"Chemlight_blue",100,50,""}
			};
			mags[] = {};
		};

		class drug {
			name = "Drug Dealer";
			conditions = "";
			items[] = {
				{"weed_seed",45,-1,""},
				{"opium_seed",45,-1,""},
				{"coca_seed",45,-1,""},
				{"VG_Weed",-1,475,""}, // Marijuana
				{"VG_Opium",-1,500,""}, // Unprocessed Heroin
				{"VG_DirtyCoke",-1,550,""}, // Unprocessed Cocaine
				{"CG_Heroin",-1,1000,""}, // Processed Heroin
				{"CG_Cocaine",-1,1100,""} // Processed Cocaine
			};
			mags[] = {};
		};

		class pub {
			name = "Dom's Pub";
			conditions = "";
			items[] = {
				{"NP_Beer",5,-1,""},
				{"NP_Tequila",8,-1,""}
			};
			mags[] = {};
		};

		class Resource {
			name = "Resource Dealer"; // Crafting Materials/Crops
			conditions = "";
			items[] = {
				{"MeleeHatchet",10,-1,""},
				{"A3L_Pickaxe",10,-1,""},
				{"VG_ChickenRaw",-1,300,""},
				{"VG_MeatRaw",-1,250,""},
				{"Wheat_Seed",10,-1,""},
				{"cotton_Seed",10,-1,""},
				{"olive_Seed",10,-1,""},
				{"pumpkin_Seed",10,-1,""},
				{"corn_Seed",10,-1,""},
				{"sunflower_Seed",10,-1,""},
				{"Sack_Wheat",-1,175,""},
				{"Sack_Cotton",-1,200,""},
				{"Sack_Olive",-1,220,""},
				{"Sack_Pumpkin",-1,260,""},
				{"Sack_Corn",-1,275,""},
				{"Sack_Sunflower",-1,300,""},
				{"np_ironbar1",-1,400,""},
				{"np_silverbar1",-1,420,""},
				{"np_goldbar2",-1,670,""},
				{"VG_Ruby",-1,700,""},
				{"VG_Sapphire",-1,720,""},
				{"VG_Gem",-1,775,""},
				{"VG_Diamond",-1,820,""}

			};
			mags[] = {
				{"Hatchet_Swing",10,-1,""},
				{"Pickaxe_Swing",10,-1,""}
			};
		};

		class Lumber {
			name = "Lumber Depot"; // Lumber/Logs
			conditions = "";
			items[] = {
				{"NP_uWood",-1,180,""},
				{"NP_Wood",-1,360,""}
			};
			mags[] = {};
		};

		class foodstore {
			name = "Food Market";
			conditions = "";
			items[] = {
				{"D_WaterBottle_i",5,-1,""},
				{"D_Franta_i",5,-1,""},
				{"np_coke",5,-1,""},
				{"np_drpepper",5,-1,""},
				{"D_Redgul_i",5,-1,""},
				{"np_energydrink",5,-1,""},
				{"D_TacticalBacon_i",5,-1,""},
				{"D_Banana_i",5,-1,""},
				{"D_Sandwich_i",5,-1,""},
				{"D_Sausages_i",5,-1,""},
				{"D_Coffee_i",5,-1,""},
				{"D_Kiwi_i",5,-1,""},
				{"D_Toast_i",5,-1,""},
				{"D_Can_SuperstarEnergy_i",5,-1,""},
				{"D_Can_Pepsi_i",5,-1,""},
				{"D_Can_Monster_i",5,-1,""},
				{"D_Can_DrPepper_i",5,-1,""},
				{"D_Can_7UP_i",5,-1,""},
				{"D_FoodCan_DogFood_i",5,-1,""},
				{"D_FoodCan_DicksSausage_i",5,-1,""},
				//New Food Stuff
				{"np_peasoup",5,-1,""},
				{"np_chickensoup",5,-1,""},
				{"np_beefsoup",5,-1,""},
				{"np_tuna",5,-1,""},
				{"np_groceries",5,-1,""},
				{"np_mpizza",5,-1,""},
				{"np_hpizza",5,-1,""},
				{"np_cpizza",5,-1,""},
				{"np_vpizza",5,-1,""},
				{"np_spizza",5,-1,""},
				{"np_donuts",5,-1,""},
				{"np_chdonuts",5,-1,""},
				{"np_jdonuts",5,-1,""},
				{"np_cdonuts",5,-1,""}
			};
			mags[] = {};
		};

		class McDonalds {
			name = "McDonalds";
			conditions = "";
			items[] = {
				{"np_happymeal",5,-1,""},
				{"np_bigmac",5,-1,""},
				{"np_mchicken",5,-1,""},
				{"np_cheeseburger",5,-1,""},
				{"np_quater",5,-1,""},
				{"np_hamburger",5,-1,""},
				{"np_hotdog",5,-1,""},
				{"np_kmhotdog",5,-1,""},
				{"np_mhotdog",5,-1,""},
				{"np_bbqhotdog",5,-1,""},
				{"np_cheesehotdog",5,-1,""}

			};
			mags[] = {
			};
		};
		class cop {
			name = "Police Supplies";
			conditions = "(player getVariable ['faction','civ']) isEqualTo 'cop'";
			items[] = {     
			//Everyone
			{"D_GoPro_i",5,-1,""},
			{"TFAR_anprc152",5,-1,""},
			{"VG_PanicButton",5,-1,""},
			{"D_Coffee_i",5,-1,""},
			{"np_donuts",5,-1,""},
			{"np_chdonuts",5,-1,""},
			{"np_jdonuts",5,-1,""},
			{"np_cdonuts",5,-1,""},
			{"D_Redgul_i",5,-1,""},
			{"D_Bandage_i",5,-1,""},
			{"D_Splint_i",5,-1,""},
			{"D_Cast_i",5,-1,""},
			{"VG_Morphine",5,-1,""},
			{"D_Battery_i",5,-1,""},
			{"D_Handcuffs_i",5,-1,""},
			{"D_Ziptie_i",5,-1,""},
			{"CG_Spikes_Collapsed",5,-1,""},
			{"Chemlight_red",5,-1,""},
			{"ItemWatch",5,-1,""},
			{"ItemMap",5,-1,""},
			{"ItemCompass",5,-1,""},
			{"ItemGPS",5,-1,""},
			{"D_Earpiece",5,-1,""},
			{"Binocular",5,-1,""},
			{"ToolKit",5,-1,""},
			{"Rangefinder",5,-1,"(player getVariable ['department','Patrol']) isEqualTo 'SWAT' || (player getVariable ['copRank',0]) >= 5"},

			//Cadet
			{"Taser_26",0,-1,""},
			{"RH_m9",0,-1,""},
			{"RH_g19",0,-1,""},
			{"rh_sbr9",0,-1,""},
			{"hlc_smg_mp5k_PDW",0,-1,""},

			//Officer
			{"RH_kimber_nw",0,-1,"(player getVariable ['copRank',0]) >= 2"},
			{"hlc_smg_mp5a4_tac",0,-1,"(player getVariable ['copRank',0]) >= 2"},
			{"hlc_rifle_M4",0,-1,"(player getVariable ['copRank',0]) >= 2"},

			//Corporal
			{"RH_fn57",0,-1,"(player getVariable ['copRank',0]) >= 3"},
			{"rh_m4_ris_m",0,-1,"(player getVariable ['copRank',0]) >= 3"},

			//Sergeant
			{"RH_fnp45",0,-1,"(player getVariable ['copRank',0]) >= 4"},
			{"hlc_rifle_cqbr",0,-1,"(player getVariable ['copRank',0]) >= 4"},
			{"sma_m4moe",0,-1,"(player getVariable ['copRank',0]) >= 4"},

			//Lieutenant
			{"RH_p226",0,-1,"(player getVariable ['copRank',0]) >= 5"},
			{"hlc_smg_mp510",0,-1,"(player getVariable ['copRank',0]) >= 5"},
			{"rh_m16a4_m",0,-1,"(player getVariable ['copRank',0]) >= 5"},

			//Captain
			{"rh_uspm",0,-1,"(player getVariable ['department','Patrol']) isEqualTo 'SWAT' || player getVariable ['copRank',0] >= 6"},
			{"arifle_SPAR_01_blk_F",0,-1,"(player getVariable ['copRank',0]) >= 6"},

			//DTU
			{"hlc_mp510_tac",0,-1,"(player getVariable ['department','Patrol']) in ['DTU','SWAT'] || (player getVariable ['copRank',0]) isEqualTo 7"},

			//SWAT
			{"hlc_rifle_bcmjack",0,-1,"((player getVariable ['department','Patrol']) isEqualTo 'SWAT') || player getVariable ['copRank',0]) >= 5"},
			{"sma_mk18moeblk",0,-1,"((player getVariable ['department','Patrol']) isEqualTo 'SWAT') || player getVariable ['copRank',0] isEqualTo 7"},

			//SWAT Command
			{"RH_DeagleM",0,-1,"((player getVariable ['department','Patrol']) isEqualTo 'SWAT' && player getVariable ['copRank',0] >= 5) || player getVariable ['copRank',0] isEqualTo 7"},
			{"SMA_HK416CUSTOMCQBvfgB",0,-1,"((player getVariable ['department','Patrol']) isEqualTo 'SWAT' && player getVariable ['copRank',0] >= 5) || player getVariable ['copRank',0] isEqualTo 7"},

			{"SmokeShellYellow",25,-1,"((player getVariable ['department','Patrol']) isEqualTo 'SWAT' && player getVariable ['copRank',0] >= 5) || player getVariable ['copRank',0] isEqualTo 7"},

			//Attachments
			{"FHQ_optic_AC11704",0,-1,""},
			{"FHQ_optic_AC12136",0,-1,""},
			{"FHQ_optic_AIM",0,-1,""},
			{"RH_compm2",0,-1,""},
			{"RH_compm2l",0,-1,""},
			{"RH_compm4s",0,-1,""},
			{"SMA_BARSKA",0,-1,""},
			{"SMA_MICRO_T2",0,-1,""},
			{"SMA_CMORE",0,-1,""},
			{"HLC_optic_DocterR",0,-1,""},
			{"SMA_eotech552",0,-1,""},
			{"RH_eotech553",0,-1,""},
			{"RH_LTdocter",0,-1,""},
			{"FHQ_optic_MicroCCO",0,-1,""},
			{"optic_Holosight_blk_F",0,-1,""},

			{"acc_pointer_IR",0,-1,""},
			{"RH_peq15b",0,-1,""},
			{"RH_SFM952V",0,-1,""}
			};

		mags[] = {

			{"26_cartridge",0,-1,""},
			{"RH_15Rnd_9x19_M9",0,-1,""},
			{"RH_19Rnd_9x19_g18",0,-1,""},
			{"RH_32Rnd_9mm_M822",0,-1,""},
			{"hlc_30Rnd_9x19_B_MP5",0,-1,""},
			{"RH_7Rnd_45cal_m1911",0,-1,""},
			{"RH_20Rnd_57x28_FN",0,-1,""},
			{"RH_15Rnd_45cal_fnp",0,-1,""},
			{"RH_15Rnd_9x19_SIG",0,-1,""},
			{"RH_16Rnd_40cal_usp",0,-1,""},
			{"RH_7Rnd_50_AE",0,-1,""},
			{"hlc_30Rnd_10mm_JHP_MP5",0,-1,""},
			{"SMA_30Rnd_556x45_Mk318",0,-1,"(player getVariable ['copRank',0]) >= 6"},
			{"RH_30Rnd_556x45_M855A1",0,-1,""},
			{"hlc_30rnd_556x45_EPR",0,-1,"(player getVariable ['copRank',0]) >= 4"}
		};
	};
		class medic {
			name = "Medical Supplies";
			conditions = "(player getVariable ['faction','civ']) isEqualTo 'medic'";
			items[] = {
				{"Toolkit",0,-1,""},
				{"D_WaterBottle_i",5,-1,""},
				{"TFAR_anprc152",5,-1,""},
				{"D_Franta_i",5,-1,""},
				{"D_Banana_i",5,-1,""},
				{"D_Sandwich_i",5,-1,""},
				{"D_GoPro_i",0,-1,""},
				{"VG_Morphine",0,-1,""},
				{"D_Bandage_i",0,-1,""},
				{"D_BloodBag_i",0,-1,""},
				{"D_Splint_i",0,-1,""},
				{"D_Cast_i",0,-1,""},
				{"D_IcePack_i",0,-1,""},
				{"D_Heatpack_i",0,-1,""},
				{"D_Defibrillator_i",0,-1,""}
			};
			mags[] = {};
		};
	};
	class Clothing {
		class cop {
			conditions = "(player getVariable ['faction','civ']) isEqualTo 'cop'";
			uniforms[] = {
				{"D_Police_Cadet",0,"player getVariable ['copRank',0] >= 1"},
				{"D_Police_Officer",0,"player getVariable ['copRank',0] isEqualTo 2 && (player getVariable ['department','Patrol']) in ['Patrol','DTU']"},
				{"D_Police_Corporal",0,"player getVariable ['copRank',0] isEqualTo 3 && (player getVariable ['department','Patrol']) in ['Patrol','DTU']"},
				{"D_Police_CorporalFTO",0,"player getVariable ['copRank',0] isEqualTo 3 && (player getVariable ['department','Patrol']) in ['Patrol','DTU']"},
				{"D_Police_Sergeant",0,"player getVariable ['copRank',0] isEqualTo 4 && (player getVariable ['department','Patrol']) in ['Patrol','DTU']"},
				{"D_Police_Lieutenant",0,"player getVariable ['copRank',0] isEqualTo 5 && (player getVariable ['department','Patrol']) in ['Patrol','DTU']"},
				{"D_Police_Captain",0,"player getVariable ['copRank',0] isEqualTo 6 && (player getVariable ['department','Patrol']) in ['Patrol','DTU']"},
				{"D_Police_AsstChief",0,"player getVariable ['copRank',0] isEqualTo 7"},
				{"D_Police_Chief",0,"player getVariable ['copRank',0] isEqualTo 7"},
				{"A3VG_HWP_Trooper_Uniform",0,"player getVariable ['copRank',0] isEqualTo 2 && (player getVariable ['department','Patrol']) isEqualTo 'Highway Patrol'"},
				{"A3VG_HWP_Corporal_Uniform",0,"player getVariable ['copRank',0] isEqualTo 3 && (player getVariable ['department','Patrol']) isEqualTo 'Highway Patrol'"},
				{"A3VG_HWP_Sergeant_Uniform",0,"player getVariable ['copRank',0] isEqualTo 4 && (player getVariable ['department','Patrol']) isEqualTo 'Highway Patrol'"},
				{"A3VG_HWP_Lieutenant_Uniform",0,"player getVariable ['copRank',0] isEqualTo 5 && (player getVariable ['department','Patrol']) isEqualTo 'Highway Patrol'"},
				{"D_Corrections_Cadet",0,"player getVariable ['copRank',0] isEqualTo 1 && (player getVariable ['department','Patrol']) isEqualTo 'Department of Corrections'"},
				{"D_Corrections_Officer",0,"player getVariable ['copRank',0] isEqualTo 2 && (player getVariable ['department','Patrol']) isEqualTo 'Department of Corrections'"},
				{"D_Corrections_Corporal",0,"player getVariable ['copRank',0] isEqualTo 3 && (player getVariable ['department','Patrol']) isEqualTo 'Department of Corrections'"},
				{"D_Corrections_CorporalFTO",0,"player getVariable ['copRank',0] isEqualTo 3 && (player getVariable ['department','Patrol']) isEqualTo 'Department of Corrections'"},
				{"D_Corrections_Sergeant",0,"player getVariable ['copRank',0] isEqualTo 4 && (player getVariable ['department','Patrol']) isEqualTo 'Department of Corrections'"},
				{"D_Corrections_Lieutenant",0,"player getVariable ['copRank',0] isEqualTo 5 && (player getVariable ['department','Patrol']) isEqualTo 'Department of Corrections'"},
				{"D_Corrections_Captain",0,"player getVariable ['copRank',0] isEqualTo 6 && (player getVariable ['department','Patrol']) isEqualTo 'Department of Corrections'"},
				{"D_SWAT_Uni",0,"(player getVariable ['department','Patrol']) isEqualTo 'SWAT'"},
				{"VG_SwatPatrol",0,"(player getVariable ['department','Patrol']) isEqualTo 'SWAT'"},
				{"VG_SwatPatrolLT",0,"(player getVariable ['department','Patrol']) isEqualTo 'SWAT' && player getVariable ['copRank',0] isEqualTo 5"},
				{"VG_SwatPatrolCPT",0,"(player getVariable ['department','Patrol']) isEqualTo 'SWAT' && player getVariable ['copRank',0] isEqualTo 6"},
				{"D_Police_Uni_Diving",0,"player getVariable ['copRank',0] > 2"}
			};
			vests[] = {
				{"D_Police_Vest_Carrier",0,"((player getVariable ['department','Patrol']) isEqualTo 'Patrol') || (player getVariable ['copRank',0]) isEqualTo 7"},
                {"EMPIRE_BodyArmor_Patrol",0,"((player getVariable ['department','Patrol']) isEqualTo 'Patrol') || (player getVariable ['copRank',0]) isEqualTo 7"},
				{"EMPIRE_BodyArmor_HWP",0,"player getVariable ['department','Patrol'] isEqualTo 'Highway Patrol'"},
                {"D_Highway_Vest",0,"player getVariable ['department','Patrol'] isEqualTo 'Highway Patrol'"},
				{"EMPIRE_BodyArmor_DOC",0,"player getVariable ['department','Patrol'] isEqualTo 'Department of Corrections'"},
                {"D_Corrections_Vest",0,"player getVariable ['department','Patrol'] isEqualTo 'Department of Corrections'"},
                {"EMPIRE_BodyArmor_IA",0,"player getVariable ['department','Patrol'] isEqualTo 'DTU'"},
                {"EMPIRE_Pouchless_DTU",0,"player getVariable ['department','Patrol'] isEqualTo 'DTU'"},
                {"EF_BS",0,"((player getVariable ['department','Patrol']) isEqualTo 'DTU') || ((player getVariable ['copRank',0]) isEqualTo 7)"},
                {"EF_BLT_F1B",0,"((player getVariable ['department','Patrol']) isEqualTo 'DTU') || ((player getVariable ['copRank',0]) isEqualTo 7)"},
                {"EF_BLT_M1B",0,"((player getVariable ['department','Patrol']) isEqualTo 'DTU') || ((player getVariable ['copRank',0]) isEqualTo 7)"},
				{"D_Base_Vest",0,"player getVariable ['department','Patrol'] isEqualTo 'SWAT'"},
                {"EMPIRE_SWAT_Black",0,"player getVariable ['department','Patrol'] isEqualTo 'SWAT'"},
				{"D_Safety_yellow",0,""}
			};
			backpacks[] = {
				{"AM_PoliceBelt",0,""},
				{"D_Invisible_Backpack",0,""}
			};
			goggles[] = {
				{"G_Spectacles_Tinted",0,""},
				{"G_Spectacles",0,""},
				{"G_Aviator",0,""},
				{"G_B_Diving",0,""},
				{"D_SWAT_Bala_Stealth",0,"(player getVariable ['department','Patrol']) isEqualTo 'SWAT'"},
				{"G_Bandanna_beast",0,"(player getVariable ['department','Patrol']) isEqualTo 'SWAT'"}
			};
			headgear[] = {
				{"D_PatrolHat",0,"(player getVariable ['department','Patrol']) isEqualTo 'High Command'"},
				{"D_PatrolHat2",0,"(player getVariable ['department','Patrol']) isEqualTo 'Patrol'"},
				{"D_Hat_Police_Academy",0,""},
				{"D_Hat_Police",0,""},
				{"D_HatBack_Police",0,""},
				{"D_Hat_Highway",0,"(player getVariable ['department','Patrol']) isEqualTo 'Highway Patrol'"},
				{"D_Hat_Corrections",0,"(player getVariable ['department','Patrol']) isEqualTo 'Department of Corrections'"},
				{"D_Hat_DTU",0,"(player getVariable ['department','Patrol']) isEqualTo 'DTU'"},
				{"D_HatBack_DTU",0,"(player getVariable ['department','Patrol']) isEqualTo 'DTU'"},
				{"D_Beret_CID",0,"(player getVariable ['department','Patrol']) in ['DTU','SWAT']"},
				{"D_Hat_SWAT",0,"(player getVariable ['department','Patrol']) isEqualTo 'SWAT'"},
				{"D_HatBack_SWAT",0,"(player getVariable ['department','Patrol']) isEqualTo 'SWAT'"},
				{"D_SWAT_Hat_Heavy",0,"(player getVariable ['department','Patrol']) isEqualTo 'SWAT'"}
			};
		};
		class medic {
			conditions = "(player getVariable ['faction','civ']) isEqualTo 'medic'";
			uniforms[] = {
				{"VG_EMTPROB_Uniform",0,"player getVariable ['medicRank',0] isEqualTo 1"},
				{"VG_EMTB_Uniform",0,"player getVariable ['medicRank',0] isEqualTo 2"},
				{"VG_EMTP_Uniform",0,"player getVariable ['medicRank',0] isEqualTo 3"},
				{"VG_CCEMT_Uniform",0,"player getVariable ['medicRank',0] isEqualTo 4"},
				{"VG_CMDEMT_Uniform",0,"player getVariable ['medicRank',0] > 4"},
				{"VG_CMDFD_Uniform",0,"player getVariable ['medicRank',0] > 4"},
				{"D_FireRescue_Uni_Diving",0,""}
			};
			vests[] = {
				{"V_RebreatherB",0,""},
				{"V_BandollierB_blk",0,""}

			};
			backpacks[] = {
				{"D_Invisible_Backpack",0,""}
			};
			goggles[] = {
				{"G_Aviator",0,""},
				{"G_Spectacles_Tinted",0,""},
				{"G_Respirator_yellow_F",0,""},
				{"G_Respirator_white_F",0,""},
				{"G_Respirator_blue_F",0,""},
				{"Mask_M40",0,""},
				{"G_B_Diving",0,""}

			};
			headgear[] = {
				{"H_Cap_marshal",0,""},
				{"H_Cap_Black_IDAP_F",0,""},
				{"H_Cap_blu",0,""},
				{"TRYK_H_headsetcap_blk_Glasses",0,""},
				{"TRYK_R_CAP_BLK",0,""},
				{"TRYK_r_cap_blk_Glasses",0,""},
				{"TRYK_H_woolhat",0,""},
				{"TRYK_H_woolhat_WH",0,""},
				{"D_CowboyBlack",0,""},
				{"D_Cowboy",0,""},
				{"D_CowboyBlack",0,""}

			};
		};
		class civ {
			conditions = "";
			uniforms[] = {
			{"TRYK_shirts_Floral1",50,""},
			{"TRYK_shirts_Floral2",50,""},
			{"TRYK_shirts_Floral3",50,""},
			{"TRYK_shirts_Floral4",50,""},
			{"TRYK_shirts_Floral5",50,""},
			{"TRYK_shirts_Floral6",50,""},
			{"TRYK_shirts_Floral7",50,""},
			{"TRYK_shirts_Floral8",50,""},
			{"TRYK_shirts_Plaid1",50,""},
			{"TRYK_shirts_Plaid2",50,""},
			{"TRYK_shirts_Plaid3",50,""},
			{"TRYK_shirts_Plaid4",50,""},
			{"TRYK_shirts_Plaid5",50,""},
			{"TRYK_shirts_Plaid6",50,""},
			{"TRYK_shirts_Plaid7",50,""},
			{"TRYK_shirts_Plaid8",50,""},
			{"TRYK_U_B_PCUGs_BLK",150,""},
			{"TRYK_U_B_PCUGs_gry",150,""},
			{"TRYK_U_B_PCUGs_OD",150,""},
			{"TRYK_shirts_DENIM_BK",50,""},
			{"TRYK_shirts_DENIM_BL",50,""},
			{"TRYK_shirts_DENIM_BWH",50,""},
			{"TRYK_shirts_DENIM_od",50,""},
			{"TRYK_shirts_DENIM_R",50,""},
			{"TRYK_shirts_DENIM_RED2",50,""},
			{"TRYK_shirts_DENIM_WH",50,""},
			{"TRYK_shirts_DENIM_ylb",50,""},
			{"TRYK_shirts_BLK_PAD",50,""},
			{"TRYK_shirts_DENIM_od_Sleeve",50,""},
			{"TRYK_shirts_DENIM_ylb_Sleeve",50,""},
			{"TRYK_shirts_DENIM_BK_Sleeve",50,""},
			{"TRYK_shirts_DENIM_BL_Sleeve",50,""},
			{"TRYK_shirts_DENIM_BWH_Sleeve",50,""},
			{"TRYK_shirts_DENIM_R_Sleeve",50,""},
			{"TRYK_shirts_PAD_BL",50,""},
			{"TRYK_shirts_PAD_RED2",50,""},
			{"hood_gucci_blk",150,""},
			{"hood_gucci_beg",150,""},
			{"hood_gucci_brr",150,""},
			{"hood_riffraff",150,""},
			{"hood_supreme",150,""},
			{"hood_tri",150,""},
			{"hood_space",150,""},
			{"hood_nike_blk",150,""},
			{"hood_nike_ylw",150,""},
			{"hood_nike_red",150,""},
			{"hood_nike_org",150,""},
			{"hood_nike_grn",150,""},
			{"hood_nike_gr",150,""},
			{"hood_nike_blu",150,""},
			{"hood_nike_wh",150,""},
			{"D_HypeBeastShorts",50,""},
			{"U_C_HunterBody_grn",50,""},
			{"EF_HM_B1",100,""},
			{"EF_HM_BL1",100,""},
			{"EF_HM_OD1",100,""},
			{"EF_HM_SG1",100,""},
			{"EF_HM_PP1",100,""},
			{"EF_M_jkt2",100,""},
			{"EF_M_jkt22",100,""},
			{"EF_M_jkt1",100,""},
			{"EF_M_jkt4",100,""},
			{"EF_M_jkt3",100,""},
			{"EF_M_jkt42",100,""},
			{"EF_M_jkt32",100,""},
			{"EF_MX1",50,""},
			{"TRYK_U_B_Denim_T_WH",50,""},
			{"TRYK_U_B_Denim_T_BK",50,""},
			{"TRYK_U_denim_hood_blk",50,""},
			{"TRYK_U_denim_hood_mc",50,""},
			{"TRYK_U_denim_hood_nc",50,""},
			{"TRYK_U_denim_jersey_blk",50,""},
			{"TRYK_U_denim_jersey_blu",50,""},
			{"TRYK_U_denim_hood_3c",50,""},
			{"TRYK_SUITS_BR_F",50,""},
			{"TRYK_SUITS_BLK_F",50,""},
			{"KAEL_SUITS_BLK_F",250,""},
			{"KAEL_SUITS_BR_F3",250,""},
			{"KAEL_SUITS_BR_F4",250,""},
			{"KAEL_SUITS_BR_F5",250,""},
			{"KAEL_SUITS_BR_F6",250,""},
			{"KAEL_SUITS_BR_F7",250,""},
			{"KAEL_SUITS_BR_F8",250,""},
			{"KAEL_SUITS_BR_F9",250,""},
			{"KAEL_SUITS_BR_F10",250,""},
			{"KAEL_SUITS_BR_F11",250,""},
			{"KAEL_SUITS_BR_F12",250,""},
			{"KAEL_SUITS_BR_F13",250,""},
			{"KAEL_SUITS_BR_F14",250,""},
			{"KAEL_SUITS_BLK_F",250,""}
			};
			vests[] = {
			{"V_Press_F",375,""},
			{"TRYK_V_Bulletproof_BL",375,""},
			{"TRYK_V_Bulletproof_BLK",375,""},
			{"TRYK_V_Bulletproof",375,""},
			{"V_DeckCrew_blue_F",375,""},
			{"V_DeckCrew_brown_F",375,""},
			{"V_DeckCrew_green_F",375,""},
			{"V_DeckCrew_red_F",375,""},
			{"V_DeckCrew_violet_F",375,""},
			{"V_DeckCrew_yellow_F",375,""},
			{"V_DeckCrew_white_F",375,""},
			{"V_TacVest_blk",375,""},
			{"V_TacVest_brn",375,""},
			{"V_TacVest_camo",375,""},
			{"V_TacVest_khk",375,""},
			{"V_TacVest_oli",375,""},
			{"V_TacVest_blk",375,""}
			};
			backpacks[] = {
			{"TRYK_B_Belt",50,""},
			{"TRYK_B_Belt_BLK",50,""},
			{"TRYK_B_Belt_CYT",50,""},
			{"TRYK_B_Belt_GR",50,""},
			{"TRYK_B_Coyotebackpack_BLK",50,""},
			{"TRYK_B_Coyotebackpack_OD",50,""},
			{"TRYK_B_Coyotebackpack",50,""},
			{"TRYK_B_Coyotebackpack_WH",50,""},
			{"EF_SQBAG_GRAY",50,""},
			{"EF_SQBAG_BK",50,""},
			{"EF_SQBAG_RED",50,""},
			{"EF_SQBAG_WH",50,""},
			{"EF_SQBAG_VL",50,""},
			{"EF_SQBAG_NV",50,""},
			{"EF_SQBAG_BL",50,""},
			{"EF_SQBAG_SG",50,""},
			{"EF_FBAG_BW",50,""},
			{"EF_FBAG_BK",50,""},
			{"EF_FBAG_VL",50,""},
			{"EF_FBAG_BL",50,""},
			{"EF_FBAG_SG",50,""},
			{"EF_FBAG_RD",50,""},
			{"EF_FBAG_SL_BW",50,""},
			{"EF_FBAG_SL_BK",50,""},
			{"EF_FBAG_SL_VL",50,""},
			{"EF_FBAG_SL_BL",50,""},
			{"EF_FBAG_SL_SG",50,""},
			{"EF_FBAG_SL_RD",50,""},
			{"EF_FBAG_HB_BW",50,""},
			{"EF_FBAG_HB_BK",50,""},
			{"EF_FBAG_HB_VL",50,""},
			{"EF_FBAG_HB_BL",50,""},
			{"EF_FBAG_HB_SG",50,""},
			{"EF_FBAG_HB_RD",50,""},
			{"B_Messenger_Black_F",50,""},
			{"B_Messenger_Coyote_F",50,""},
			{"B_Messenger_Gray_F",50,""},
			{"B_Messenger_Olive_F",50,""},
			{"B_LegStrapBag_black_F",50,""},
			{"B_LegStrapBag_coyote_F",50,""},
			{"B_LegStrapBag_olive_F",50,""},
			{"B_OutdoorPack_blk",50,""},
			{"B_AssaultPack_khk",50,""},
			{"B_AssaultPack_dgtl",50,""},
			{"B_AssaultPack_rgr",50,""},
			{"B_AssaultPack_sgg",50,""},
			{"B_AssaultPack_blk",50,""},
			{"B_AssaultPack_cbr",50,""},
			{"B_AssaultPack_mcamo",50,""},
			{"B_AssaultPack_tna_f",50,""},
			{"B_TacticalPack_oli",50,""},
			{"B_Kitbag_mcamo",50,""},
			{"B_Kitbag_sgg",50,""},
			{"B_Kitbag_cbr",50,""},
			{"B_FieldPack_blk",50,""},
			{"B_FieldPack_ocamo",50,""},
			{"B_FieldPack_oucamo",50,""},
			{"B_FieldPack_ghex_f",50,""},
			{"B_Bergen_sgg",50,""},
			{"B_Bergen_mcamo",50,""},
			{"B_Bergen_rgr",50,""},
			{"B_Bergen_blk",50,""},
			{"B_Carryall_ocamo",50,""},
			{"B_Carryall_oucamo",50,""},
			{"B_Carryall_mcamo",50,""},
			{"B_Carryall_oli",50,""},
			{"B_Carryall_khk",50,""}
			};
			goggles[] = {
			{"G_Shades_Black",25,""},
			{"G_Shades_Blue",25,""},
			{"G_Sport_Blackred",25,""},
			{"G_Sport_Checkered",25,""},
			{"G_Sport_Blackyellow",25,""},
			{"G_Sport_BlackWhite",25,""},
			{"G_Squares",25,""},
			{"G_Lowprofile",25,""},
			{"G_Combat",25,""},
			{"G_Balaclava_blk",25,""},
			{"G_Balaclava_combat",25,""},
			{"G_Balaclava_lowprofile",25,""},
			{"G_Bandanna_khk",25,""},
			{"G_Bandanna_tan",25,""},
			{"G_Bandanna_oli",25,""},
			{"G_Bandanna_aviator",25,""},
			{"G_Bandanna_beast",25,""}
			};
			headgear[] = {
			{"FDNY_Cap_Tan",25,""},
			{"FDNY_Cap_Black",25,""},
			{"FDNY_Cap_White",25,""},
			{"FDNY_Cap_Grey",25,""},
			{"FDNY_Cap_Navy",25,""},
			{"Polo_Cap_Blk",25,""},
			{"Polo_Cap_Tan",25,""},
			{"Polo_Cap_White",25,""},
			{"Polo_Cap_Navy",25,""},
			{"Polo_Cap_LBlue",25,""},
			{"Polo_Cap_Pink",25,""},
			{"Polo_Cap_Red",25,""},
			{"Nike_Cap_Navy",25,""},
			{"Nike_Cap_Blk",25,""},
			{"Nike_Cap_White",25,""},
			{"Nike_Cap_Orange",25,""},
			{"Nike_Cap_Grey",25,""},
			{"Nike_Cap_Green",25,""},
			{"Nike_Cap_Red",25,""},
			{"Nike_Cap_Yellow",25,""},
			{"TRYK_H_Booniehat_3CD",25,""},
			{"TRYK_H_Booniehat_AOR1",25,""},
			{"TRYK_H_Booniehat_AOR2",25,""},
			{"TRYK_H_woolhat",25,""},
			{"TRYK_H_woolhat_br",25,""},
			{"TRYK_H_woolhat_cu",25,""},
			{"TRYK_H_woolhat_tan",25,""},
			{"TRYK_H_woolhat_WH",25,""},
			{"H_Bandanna_camo",25,""},
			{"TRYK_H_bandana_H",25,""},
			{"TRYK_ESS_CAP",25,""},
			{"TRYK_ESS_CAP_OD",25,""},
			{"TRYK_ESS_CAP_tan",25,""},
			{"TRYK_H_headsetcap_blk_Glasses",25,""},
			{"TRYK_H_headsetcap_Glasses",25,""},
			{"TRYK_H_headsetcap_od_Glasses",25,""},
			{"TRYK_H_headsetcap",25,""},
			{"TRYK_H_headsetcap_blk",25,""},
			{"TRYK_H_headsetcap_od",25,""},
			{"TRYK_R_CAP_BLK",25,""},
			{"TRYK_R_CAP_TAN",25,""},
			{"TRYK_R_CAP_OD_US",25,""},
			{"TRYK_r_cap_tan_Glasses",25,""},
			{"TRYK_r_cap_blk_Glasses",25,""},
			{"TRYK_r_cap_od_Glasses",25,""},
			{"H_Booniehat_khk_hs",25,""},
			{"H_Booniehat_khk",25,""},
			{"H_Booniehat_mcamo",25,""},
			{"H_Booniehat_oli",25,""},
			{"H_Booniehat_tan",25,""},
			{"H_Cap_tan",25,""},
			{"H_Cap_blk",25,""},
			{"H_Cap_blk_CMMG",25,""},
			{"H_Cap_brn_SPECOPS",25,""},
			{"H_Cap_tan_specops_US",25,""},
			{"H_Cap_khaki_specops_UK",25,""},
			{"H_Cap_grn",25,""},
			{"H_Cap_grn_BI",25,""},
			{"H_Cap_blk_Raven",25,""},
			{"TRYK_H_woolhat",25,""},
			{"TRYK_H_woolhat_br",25,""},
			{"TRYK_H_woolhat_cu",25,""},
			{"TRYK_H_woolhat_tan",25,""},
			{"TRYK_H_woolhat_WH",25,""},
			{"TRYK_H_wig",25,""},
			{"H_Cap_blk_ION",25,""},
			{"TRYK_UA_CAP",25,""},
			{"TRYK_UA_CAP_GR",25,""},
			{"TRYK_UA_CAP_tan",25,""},
			{"TRYK_UA_CAP_U",25,""},
			{"TRYK_UA_CAP2R",25,""},
			{"TRYK_UA_CAP_GR2R",25,""},
			{"TRYK_UA_CAP_tan2R",25,""},
			{"TRYK_UA_CAP_U2R",25,""}
			};
		};
		class rebelclothes {
		conditions = "";
		uniforms[] = {
			// Gang Clothing

			// TSFG
			{"Gang_Cloth_TSGF_Uni",50,"(player getVariable ['company','']) isEqualTo 'TSFG'"},
			//Delgado
			{"Gang_Cloth_Delgado",50,"(player getVariable ['company','']) isEqualTo 'Delgado Crime Family'"},
			//Pusha
			{"Gang_Cloth_Pusha_Uni",50,"(player getVariable ['company','']) isEqualTo 'Pusha Family LLC.'"},
			//Knights
			{"Gang_Cloth_Knight_Uni",50,"(player getVariable ['company','']) isEqualTo 'INSERT VARIABLE HERE'"},
			//Vikings
			{"Gang_Cloth_Vikings_Uni",50,"(player getVariable ['company','']) isEqualTo 'Unkown Vikings'"},
			//Olympus Guardians
			{"Gang_Cloth_OG_Uni",50,"(player getVariable ['company','']) isEqualTo 'Olympus Guardians'"},
			//Tepti
			{"TRYK_EMPIRE_Tepti_Grey",50,"(player getVariable ['company','']) isEqualTo 'INSERT VARIABLE HERE'"},
			//Ramirez Crime Family
			{"Gang_Cloth_RCF_Uni",50,"(player getVariable ['company','']) isEqualTo 'The Ramirez Cartel'"},
			//Free Family
			{"VG_GangUni_FreeFamily",50,"(player getVariable ['company','']) isEqualTo 'Free Family'"},
			//La Ems
			{"EMPIRE_suit_LaEmes",50,"(player getVariable ['company','']) isEqualTo 'Le Emes'"},

			{"TRYK_shirts_Plaid1_Tan",50,""},
			{"TRYK_shirts_Plaid2_Tan",50,""},
			{"TRYK_shirts_Plaid3_Tan",50,""},
			{"TRYK_shirts_Plaid4_Tan",50,""},
			{"TRYK_shirts_Plaid5_Tan",50,""},
			{"TRYK_shirts_Plaid6_Tan",50,""},
			{"TRYK_shirts_Plaid7_Tan",50,""},
			{"TRYK_shirts_Plaid8_Tan",50,""},
			{"TRYK_shirts_Floral1_Tan",50,""},
			{"TRYK_shirts_Floral2_Tan",50,""},
			{"TRYK_shirts_Floral3_Tan",50,""},
			{"TRYK_shirts_Floral4_Tan",50,""},
			{"TRYK_shirts_Floral5_Tan",50,""},
			{"TRYK_shirts_Floral6_Tan",50,""},
			{"TRYK_shirts_Floral7_Tan",50,""},
			{"TRYK_shirts_Floral8_Tan",50,""},
			{"hood_gucci_blk",150,""},
			{"hood_gucci_beg",150,""},
			{"hood_gucci_brr",150,""},
			{"hood_riffraff",150,""},
			{"hood_supreme",150,""},
			{"hood_tri",150,""},
			{"hood_space",150,""},
			{"hood_nike_blk",150,""},
			{"hood_nike_ylw",150,""},
			{"hood_nike_red",150,""},
			{"hood_nike_org",150,""},
			{"hood_nike_grn",150,""},
			{"hood_nike_gr",150,""},
			{"hood_nike_blu",150,""},
			{"hood_nike_wh",150,""},
			{"TRYK_U_B_PCUHsW3nh",150,""},
			{"TRYK_U_B_PCUHsW3",150,""},
			{"TRYK_U_B_BLKBLK_CombatUniform",150,""},
			{"TRYK_U_B_BLKBLK_R_CombatUniform",150,""},
			{"TRYK_U_B_BLKOCP_CombatUniform",150,""},
			{"TRYK_U_B_BLKOCP_R_CombatUniformTshirt",150,""},
			{"TRYK_U_B_BLKTAN_CombatUniform",150,""},
			{"TRYK_U_B_BLKTANR_CombatUniformTshirt",150,""},
			{"TRYK_U_B_BLKTAN_CombatUniform",150,""},
			{"TRYK_U_B_ODTAN_CombatUniform",150,""},
			{"TRYK_U_B_GRYOCP_CombatUniform",150,""},
			{"TRYK_U_B_GRYOCP_R_CombatUniformTshirt",150,""},  
			{"TRYK_U_Bts_PCUs",150,""},
			{"TRYK_U_Bts_PCUODs",150,""},
			{"TRYK_U_denim_hood_blk",150,""},
			{"TRYK_U_denim_hood_3c",150,""},
			{"TRYK_U_denim_hood_mc",150,""},
			{"TRYK_U_denim_jersey_blu",150,""},
			{"TRYK_U_denim_jersey_blk",150,""},
			{"TRYK_U_B_PCUHs",150,""},
			{"TRYK_U_B_PCUGHs",150,""},
			{"TRYK_U_B_PCUODHs",150,""},
			{"TRYK_U_B_Wood_PCUs_R",150,""},
			{"TRYK_U_B_PCUODs",150,""},
			{"TRYK_U_pad_hood_CSATBlk",150,""},
			{"TRYK_U_nohoodPcu_gry",150,""},
			{"TRYK_U_B_PCUHsW6",150,""},
			{"TRYK_U_B_PCUHsW5",150,""},
			{"TRYK_U_pad_hood_Blk",150,""},
			{"TRYK_shirts_BLK_PAD_BLU3",150,""},
			{"TRYK_shirts_BLK_PAD_BL",150,""},
			{"TRYK_shirts_BLK_PAD",150,""},
			{"TRYK_shirts_BLK_PAD_RED2",150,""},
			{"TRYK_shirts_BLK_PAD_YEL",150,""},
			{"TRYK_U_pad_hood_odBK",150,""},
			{"U_I_G_Story_Protagonist_F",150,""},
			{"U_I_G_resistanceLeader_F",150,""},
			{"TRYK_U_B_TANOCP_CombatUniform",150,""},
			{"TRYK_U_B_TANOCP_R_CombatUniformTshirt",150,""},
			{"TRYK_U_B_OD_OD_R_CombatUniform",150,""},
			{"TRYK_U_B_OD_OD_CombatUniform",150,""},
			{"TRYK_U_B_GRTAN_CombatUniform",150,""},
			{"TRYK_U_B_GRTANR_CombatUniformTshirt",150,""},
			{"TRYK_U_B_3CD_BLK_BDUTshirt ",150,""},
			{"TRYK_U_B_3CD_BLK_BDUTshirt2",150,""},
			{"TRYK_ZARATAKI2",150,""},
			{"TRYK_ZARATAKI3",150,""},
			{"TRYK_T_CSAT_PAD",150,""},
			{"TRYK_T_TAN_PAD",150,""},
			{"TRYK_T_OD_PAD",150,""},
			{"TRYK_T_BLK_PAD",150,""}
			};
	vests[] = {
			{"V_PlateCarrier1_blk",1000,""},
			{"V_PlateCarrier1_rgr",1000,""},
			{"V_PlateCarrier1_tna_f",1000,""},
			{"V_PlateCarrier1_wdl",1000,""},
			{"TRYK_V_ArmorVest_Delta",1000,""},
			{"TRYK_V_ArmorVest_Brown",1000,""},
			{"TRYK_V_ArmorVest_CBR",1000,""},
			{"TRYK_V_ArmorVest_coyo",1000,""},
			{"Tepti_Vest",50,"(player getVariable ['company','']) isEqualTo 'INSERT VARIABLE HERE'"},
			{"RCF_Vest",50,"(player getVariable ['company','']) isEqualTo 'The Ramirez Cartel'"},
			{"OG_Vest",50,"(player getVariable ['company','']) isEqualTo 'Olympus Guardians'"},
			{"Vikings_Vest",50,"(player getVariable ['company','']) isEqualTo 'Unkown Vikings'"},
			{"Knight_Vest",50,"(player getVariable ['company','']) isEqualTo 'INSERT VARIABLE HERE'"},
			{"Pusha_Vest",50,"(player getVariable ['company','']) isEqualTo 'Pusha Family LLC.'"},
			{"Delgado_Vest",50,"(player getVariable ['company','']) isEqualTo 'Delgado Crime Family'"},
			{"TSFG_Vest",50,"(player getVariable ['company','']) isEqualTo 'TSFG'"},
			{"LaEmes_Vest",50,"(player getVariable ['company','']) isEqualTo 'Le Emes'"},
			{"VG_GangVest_FreeFamily",50,"(player getVariable ['company','']) isEqualTo 'Free Family'"}
			};
	backpacks[] = {
			{"TRYK_B_Belt",50,""},
			{"TRYK_B_Belt_BLK",50,""},
			{"TRYK_B_Belt_CYT",50,""},
			{"TRYK_B_Belt_GR",50,""},
			{"B_AssaultPack_cbr",50,""},
			{"B_Kitbag_mcamo",50,""},
			{"B_TacticalPack_oli",50,""},
			{"B_FieldPack_ocamo",50,""},
			{"B_Bergen_sgg",50,""},
			{"B_Kitbag_cbr",50,""},
			{"TRYK_B_Coyotebackpack_BLK",50,""},
			{"TRYK_B_Coyotebackpack_OD",50,""},
			{"TRYK_B_Coyotebackpack",50,""},
			{"TRYK_B_Coyotebackpack_WH",50,""},
			{"EF_SQBAG_GRAY",50,""},
			{"EF_SQBAG_BK",50,""},
			{"EF_SQBAG_RED",50,""},
			{"EF_SQBAG_WH",50,""},
			{"EF_SQBAG_VL",50,""},
			{"EF_SQBAG_NV",50,""},
			{"EF_SQBAG_BL",50,""},
			{"EF_SQBAG_SG",50,""},
			{"EF_FBAG_BW",50,""},
			{"EF_FBAG_BK",50,""},
			{"EF_FBAG_VL",50,""},
			{"EF_FBAG_BL",50,""},
			{"EF_FBAG_SG",50,""},
			{"EF_FBAG_RD",50,""},
			{"EF_FBAG_SL_BW",50,""},
			{"EF_FBAG_SL_BK",50,""},
			{"EF_FBAG_SL_VL",50,""},
			{"EF_FBAG_SL_BL",50,""},
			{"EF_FBAG_SL_SG",50,""},
			{"EF_FBAG_SL_RD",50,""},
			{"EF_FBAG_HB_BW",50,""},
			{"EF_FBAG_HB_BK",50,""},
			{"EF_FBAG_HB_VL",50,""},
			{"EF_FBAG_HB_BL",50,""},
			{"EF_FBAG_HB_SG",50,""},
			{"EF_FBAG_HB_RD",50,""},
			{"B_Messenger_Black_F",50,""},
			{"B_Messenger_Coyote_F",50,""},
			{"B_Messenger_Gray_F",50,""},
			{"B_Messenger_Olive_F",50,""},
			{"B_LegStrapBag_black_F",50,""},
			{"B_LegStrapBag_coyote_F",50,""},
			{"B_LegStrapBag_olive_F",50,""},
			{"B_OutdoorPack_blk",50,""},
			{"B_AssaultPack_khk",50,""},
			{"B_AssaultPack_dgtl",50,""},
			{"B_AssaultPack_rgr",50,""},
			{"B_AssaultPack_sgg",50,""},
			{"B_AssaultPack_blk",50,""},
			{"B_AssaultPack_cbr",50,""},
			{"B_AssaultPack_mcamo",50,""},
			{"B_AssaultPack_tna_f",50,""},
			{"B_TacticalPack_oli",50,""},
			{"B_Kitbag_mcamo",50,""},
			{"B_Kitbag_sgg",50,""},
			{"B_Kitbag_cbr",50,""},
			{"B_FieldPack_blk",50,""},
			{"B_FieldPack_ocamo",50,""},
			{"B_FieldPack_oucamo",50,""},
			{"B_FieldPack_ghex_f",50,""},
			{"B_Bergen_sgg",50,""},
			{"B_Bergen_mcamo",50,""},
			{"B_Bergen_rgr",50,""},
			{"B_Bergen_blk",50,""},
			{"B_Carryall_ocamo",50,""},
			{"B_Carryall_oucamo",50,""},
			{"B_Carryall_mcamo",50,""},
			{"B_Carryall_oli",50,""},
			{"B_Carryall_khk",50,""}
			};
	goggles[] = {
			{"G_Shades_Black",25,""},
			{"G_Shades_Blue",25,""},
			{"G_Sport_Blackred",25,""},
			{"G_Sport_Checkered",25,""},
			{"G_Sport_Blackyellow",25,""},
			{"G_Sport_BlackWhite",25,""},
			{"G_Squares",25,""},
			{"G_Lowprofile",25,""},
			{"G_Combat",25,""},
			{"G_Balaclava_blk",25,""},
			{"G_Balaclava_combat",25,""},
			{"G_Balaclava_lowprofile",25,""},
			{"TRYK_balaclava_NV",25,""},
			{"TRYK_balaclava_BLACK_NV",25,""},
			{"TRYK_US_ESS_Glasses_TAN_NV",25,""},
			{"TRYK_US_ESS_Glasses_NV",25,""},
			{"A3L_Balaclava",25,""},
			{"G_Bandanna_khk",25,""},
			{"G_Bandanna_tan",25,""},
			{"G_Bandanna_oli",25,""},
			{"G_Bandanna_aviator",25,""},
			{"G_Bandanna_beast",25,""}
			};
	headgear[] = {
		
			{"EMPIRE_Cap_TSGF",50,"(player getVariable ['company','']) isEqualTo 'TSFG'"},
			{"EMPIRE_Beret_Delgado",50,"(player getVariable ['company','']) isEqualTo 'Delgado Crime Family'"},
			{"EMPIRE_Beret_Pusha",50,"(player getVariable ['company','']) isEqualTo 'Pusha Family LLC.'"},
			{"EMPIRE_Beret_LaEmes",50,"(player getVariable ['company','']) isEqualTo 'Le Emes'"},
			{"FDNY_Cap_Tan",25,""},
			{"FDNY_Cap_Black",25,""},
			{"FDNY_Cap_White",25,""},
			{"FDNY_Cap_Grey",25,""},
			{"FDNY_Cap_Navy",25,""},
			{"Polo_Cap_Blk",25,""},
			{"Polo_Cap_Tan",25,""},
			{"Polo_Cap_White",25,""},
			{"Polo_Cap_Navy",25,""},
			{"Polo_Cap_LBlue",25,""},
			{"Polo_Cap_Pink",25,""},
			{"Polo_Cap_Red",25,""},
			{"Nike_Cap_Navy",25,""},
			{"Nike_Cap_Blk",25,""},
			{"Nike_Cap_White",25,""},
			{"Nike_Cap_Orange",25,""},
			{"Nike_Cap_Grey",25,""},
			{"Nike_Cap_Green",25,""},
			{"Nike_Cap_Red",25,""},
			{"Nike_Cap_Yellow",25,""},
			{"TRYK_H_Booniehat_3CD",25,""},
			{"TRYK_H_Booniehat_AOR1",25,""},
			{"TRYK_H_Booniehat_AOR2",25,""},
			{"TRYK_H_woolhat",25,""},
			{"TRYK_H_woolhat_br",25,""},
			{"TRYK_H_woolhat_cu",25,""},
			{"TRYK_H_woolhat_tan",25,""},
			{"TRYK_H_woolhat_WH",25,""},
			{"H_Bandanna_camo",25,""},
			{"TRYK_H_bandana_H",25,""},
			{"TRYK_ESS_CAP",25,""},
			{"TRYK_ESS_CAP_OD",25,""},
			{"TRYK_ESS_CAP_tan",25,""},
			{"TRYK_H_headsetcap_blk_Glasses",25,""},
			{"TRYK_H_headsetcap_Glasses",25,""},
			{"TRYK_H_headsetcap_od_Glasses",25,""},
			{"TRYK_H_headsetcap",25,""},
			{"TRYK_H_headsetcap_blk",25,""},
			{"TRYK_H_headsetcap_od",25,""},
			{"TRYK_R_CAP_BLK",25,""},
			{"TRKY_R_CAP_TAN",25,""},
			{"TRYK_R_CAP_OD_US",25,""},
			{"TRYK_r_cap_tan_Glasses",25,""},
			{"TRYK_r_cap_blk_Glasses",25,""},
			{"TRYK_r_cap_od_Glasses",25,""},
			{"H_Booniehat_khk_hs",25,""},
			{"H_Booniehat_khk",25,""},
			{"H_Booniehat_mcamo",25,""},
			{"H_Booniehat_oli",25,""},
			{"H_Booniehat_tan",25,""},
			{"H_Cap_tan",25,""},
			{"H_Cap_blk",25,""},
			{"H_Cap_blk_CMMG",25,""},
			{"H_Cap_brn_SPECOPS",25,""},
			{"H_Cap_tan_specops_US",25,""},
			{"H_Cap_khaki_specops_UK",25,""},
			{"H_Cap_grn",25,""},
			{"H_Cap_grn_BI",25,""},
			{"H_Cap_blk_Raven",25,""},
			{"TRYK_H_woolhat",25,""},
			{"TRYK_H_woolhat_br",25,""},
			{"TRYK_H_woolhat_cu",25,""},
			{"TRYK_H_woolhat_tan",25,""},
			{"TRYK_H_wig",25,""},
			{"TRYK_H_woolhat_WH",25,""},
			{"H_Cap_blk_ION",25,""},
			{"H_Capbw_pmc",25,""},
			{"TRYK_UA_CAP",25,""},
			{"TRYK_UA_CAP_GR",25,""},
			{"TRYK_UA_CAP_tan",25,""},
			{"TRYK_UA_CAP_U",25,""},
			{"TRYK_UA_CAP2R",25,""},
			{"TRYK_UA_CAP_GR2R",25,""},
			{"TRYK_UA_CAP_tan2R",25,""},
			{"TRYK_UA_CAP_U2R",25,""}
		};
	};
};
	class Vehicle {
		class civ_basic { 
			name = "Car Shop";
			conditions = "'driver' in client_licenses";
			vehicles[] = {
				{"ivory_cv",11000,""},
				{"ivory_taurus",18000,""},
				{"ivory_challenger",22000,""},
				{"ivory_charger",24000,""},
				{"ivory_gti",28000,""},
				{"Ivory_wrx",29500,""},
				{"ivory_evox",31000,""},
				{"ivory_supra",42000,""},
				{"ivory_911",45750,""},
				{"ivory_r34",48500,""},
				{"ivory_mp4",50000,""},
				{"ivory_isf",54000,""},
				{"Ivory_LFA",56000,""},
				{"ivory_rs4",58000,""},
				{"ivory_c",60000,""},
				{"ivory_elise",62000,""},
				{"ivory_e36",64000,""},
				{"ivory_f1",66000,""},
				{"ivory_r8",70000,""},
				{"ivory_r8_spyder",72000,""},
				{"Ivory_gt500",75000,""},
				{"ivory_ccx",77000,""},
				{"ivory_lp560",88000,""},
				{"ivory_rev",97000,""},
				{"ivory_veyron",118000,""}
			};
		};
		class truck {
			name = "Truck Shop";
			conditions = "'truck' in client_licenses";
			vehicles[] = {
				{"Jonzie_Tow_Truck",17000,""},
				{"C_Van_02_transport_F",31000,""},
				{"C_Van_01_transport_F",33000,""},
				{"Jonzie_Flat_Bed",41000,""},
				{"Jonzie_Log_Truck",41000,""},
				{"C_Van_01_box_F",44000,""},
				{"C_Truck_02_transport_F",64000,""},
				{"B_Truck_01_transport_F",87000,""}
			};
		};
		class cop {
			name = "Police Vehicles";
			conditions = "(player getVariable ['faction','civ']) isEqualTo 'cop'";
			vehicles[] = {
				{"ivory_taurus_marked",0,"(player getVariable ['copRank',0]) >= 1"},
				{"ivory_cv_marked",0,"(player getVariable ['copRank',0]) >= 1"},
				{"ivory_charger_marked",0,"(player getVariable ['copRank',0]) >= 3"},
				{"ivory_evox_marked",0,"(player getVariable ['department','Patrol']) in ['Highway Patrol','SWAT'] || (player getVariable ['copRank',0]) isEqualTo 7"},
				{"ivory_wrx_marked",0,"(player getVariable ['department','Patrol']) in ['Highway Patrol','SWAT'] || (player getVariable ['copRank',0]) isEqualTo 7"},
				//Unmarked
				{"ivory_taurus_unmarked_norb",0,"(player getVariable ['copRank',0]) >= 5 || (player getVariable ['department','Patrol']) isEqualTo 'DTU'"},
				{"ivory_charger_unmarked_norb",0,"(player getVariable ['copRank',0]) >= 5 || (player getVariable ['department','Patrol']) isEqualTo 'DTU'"},
				{"ivory_cv_unmarked_norb",0,"(player getVariable ['copRank',0]) >= 5 || (player getVariable ['department','Patrol']) isEqualTo 'DTU'"},
				{"ivory_evox_unmarked_norb",0,"(player getVariable ['copRank',0]) isEqualTo 7 || (player getVariable ['department','Patrol']) isEqualTo 'SWAT'"},
				{"ivory_wrx_unmarked_norb",0,"(player getVariable ['copRank',0]) isEqualTo 7 || (player getVariable ['department','Patrol']) isEqualTo 'SWAT'"},
				{"ivory_rs4_unmarked_norb",0,"(player getVariable ['copRank',0]) >= 6 || (player getVariable ['department','Patrol']) isEqualTo 'DTU'"},
				{"ivory_m3_unmarked_norb",0,"(player getVariable ['copRank',0]) >= 6 || (player getVariable ['department','Patrol']) isEqualTo 'DTU'"},
				{"ivory_isf_unmarked_norb",0,"(player getVariable ['copRank',0]) >= 6 || (player getVariable ['department','Patrol']) isEqualTo 'DTU'"},
				{"ivory_rev_unmarked_norb",0,"(player getVariable ['copRank',0]) isEqualTo 7"}
			};
		};
		class cop_air {
			name = "Police Aircraft";
			conditions = "(player getVariable ['faction','civ']) isEqualTo 'cop'";
			vehicles[] = {
				{"B_Heli_Light_01_F",1500,""},
				{"MELB_MH6M",2500,"(player getVariable ['copRank',0]) >= 5 || (player getVariable ['department','Patrol']) in ['DTU','SWAT']"}
			};
		};
		class civ_air {
			name = "Civilian Aircraft";
			conditions = "'pilot' in client_licenses";
			vehicles[] = {
				{"B_Heli_Light_01_F",79500,""},
				{"C_Heli_Light_01_civil_F",79500,""},
				{"C_Plane_Civil_01_F",91000,""},
				{"C_Plane_Civil_01_Racing_F",98000,""}
			};
		};
		class cop_boat {
			name = "Police Ships";
			conditions = "(player getVariable ['faction','civ']) isEqualTo 'cop'";
			vehicles[] = {
				{"B_Boat_Transport_01_F",0,""},
				{"B_Lifeboat",0,""},
				{"B_SDV_01_F",0,""}
			};
		};
		class civ_boat {
			name = "Civilian Ships";
			conditions = "'diving' in client_licenses";
			vehicles[] = {
				{"C_Rubberboat",4500,""},
				{"C_Boat_Civil_01_F",5200,""},
				{"C_Boat_Transport_02_F",4800,""},
				{"C_Scooter_Transport_01_F",2750,""}
			};
		};
		class med {
			name = "Medic Vehicles";
			conditions = "(player getVariable ['faction','civ']) isEqualTo 'medic'";
			vehicles[] = {
				{"Jonzie_Ambulance",0,""},
				{"ivory_cv_marked",0,"(player getVariable ['medicRank',0]) >= 4"},
				{"ivory_taurus_marked",0,"(player getVariable ['medicRank',0]) >= 5"},
				{"ivory_wrx_marked",0,"(player getVariable ['medicRank',0]) >= 5"},
				{"Fox_Firetruck",0,""},
				{"Fox_ArrowXTLadder",0,""},
				{"Fox_HeavyRescue",0,""},
				{"Fox_HeavyRescue2",0,""}
				
			};
		};
		class med_air {
			name = "Medic Aircraft";
			conditions = "(player getVariable ['faction','civ']) isEqualTo 'medic'";
			vehicles[] = {
				{"B_Heli_Light_01_F",1500,""}
			};
		};
	};
};
