/*
*    class:
*        displayName = License Name
*        price = License Price
*/
class Licenses {
	class driver {
		displayName = "Driving";
		price = 500;
	};

	class pilot {
		displayName = "Pilot";
		price = 6500;
	};

	class truck {
		displayName = "Trucking";
		price = 1200;
	};

	class gun {
		displayName = "Firearm";
		price = 2200;
	};

	class rifle {
		displayName = "Rifle";
		price = 4000;
	};

	class diving {
		displayName = "Diving";
		price = 900;
	};

	class rebel {
		displayName = "Rebel";
		price = 35000;
	};
};
