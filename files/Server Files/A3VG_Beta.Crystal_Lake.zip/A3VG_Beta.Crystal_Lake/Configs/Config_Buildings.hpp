/*
Item shop configs work by:
	Price of house
	Max number of furniture items
	Type: 0 = house, 1 = garage
	Offset to spawn vehicles (only if type is 1)
	Directional offset to spawn vehicles (only if type is 1)
	Lighting position
*/

class Buildings {
	class Houses {
	
		//Industrial
		class Land_i_Shed_Ind_F {
			price = 375000;
			maxFurniture = 60;
			type = 0;
		};
		class Land_SM_01_shed_F : Land_i_Shed_Ind_F{};

		//Vanilla 2 Story
		class Land_i_House_Big_01_V1_F {
			price = 225000;
			maxFurniture = 60;
			type = 0;
		};
		class Land_i_House_Big_02_V1_F {
			price = 195000;
			maxFurniture = 40;
			type = 0;
		};
		class Land_i_House_Big_01_V2_F : Land_i_House_Big_01_V1_F{};
		class Land_i_House_Big_01_V3_F : Land_i_House_Big_01_V1_F{};
		class Land_u_House_Big_01_V1_F : Land_i_House_Big_01_V1_F{};
		class Land_i_House_Big_01_b_blue_F : Land_i_House_Big_01_V1_F{};
		class Land_i_House_Big_01_b_brown_F : Land_i_House_Big_01_V1_F{};
		class Land_i_House_Big_01_b_pink_F : Land_i_House_Big_01_V1_F{};
		class Land_i_House_Big_01_b_white_F : Land_i_House_Big_01_V1_F{};
		class Land_i_House_Big_01_b_whiteblue_F : Land_i_House_Big_01_V1_F{};
		class Land_i_House_Big_01_b_yellow_F : Land_i_House_Big_01_V1_F{};
		class Land_i_House_Big_02_V2_F : Land_i_House_Big_02_V1_F{};
		class Land_i_House_Big_02_V3_F : Land_i_House_Big_02_V1_F{};
		class Land_i_House_Big_02_b_blue_F : Land_i_House_Big_02_V1_F{};
		class Land_i_House_Big_02_b_brown_F : Land_i_House_Big_02_V1_F{};
		class Land_i_House_Big_02_b_pink_F : Land_i_House_Big_02_V1_F{};
		class Land_i_House_Big_02_b_white_F : Land_i_House_Big_02_V1_F{};
		class Land_i_House_Big_02_b_whiteblue_F : Land_i_House_Big_02_V1_F{};
		class Land_i_House_Big_02_b_yellow_F : Land_i_House_Big_02_V1_F{};

		//Vanilla 1 Story
		class Land_i_House_Small_01_V1_F {
			price = 95000;
			maxFurniture = 30;
			type = 0;
		};
		class Land_i_House_Small_01_V2_F : Land_i_House_Small_01_V1_F{};
		class Land_i_House_Small_01_V3_F : Land_i_House_Small_01_V1_F{};
		class Land_i_House_Small_02_V1_F : Land_i_House_Small_01_V1_F{};
		class Land_i_House_Small_02_V2_F : Land_i_House_Small_01_V1_F{};
		class Land_i_House_Small_02_V3_F : Land_i_House_Small_01_V1_F{};
		class Land_i_House_Small_01_b_blue_F : Land_i_House_Small_01_V1_F{};
		class Land_i_House_Small_01_b_brown_F : Land_i_House_Small_01_V1_F{};
		class Land_i_House_Small_01_b_pink_F : Land_i_House_Small_01_V1_F{};
		class Land_i_House_Small_01_b_white_F : Land_i_House_Small_01_V1_F{};
		class Land_i_House_Small_01_b_whiteblue_F : Land_i_House_Small_01_V1_F{};
		class Land_i_House_Small_01_b_yellow_F : Land_i_House_Small_01_V1_F{};
		class Land_i_House_Small_02_b_blue_F : Land_i_House_Small_01_V1_F{};
		class Land_i_House_Small_02_b_brown_F : Land_i_House_Small_01_V1_F{};
		class Land_i_House_Small_02_b_pink_F : Land_i_House_Small_01_V1_F{};
		class Land_i_House_Small_02_b_white_F : Land_i_House_Small_01_V1_F{};
		class Land_i_House_Small_02_b_whiteblue_F : Land_i_House_Small_01_V1_F{};
		class Land_i_House_Small_02_b_yellow_F : Land_i_House_Small_01_V1_F{};

		//Vanilla Shacks/Sheds
		class Land_Slum_House01_F {
			price = 55000;
			maxFurniture = 0;
			type = 0;
		};
		class Land_Slum_03_F {
			price = 75000;
			maxFurniture = 10;
			type = 0;
		};
		class Land_Slum_House02_F : Land_Slum_House01_F{};
		class Land_Slum_House03_F : Land_Slum_House01_F{};

		//Modded 2 Story
		class Land_house_mansion_1 {
			price = 450000;
			maxFurniture = 80;
			type = 0;
		};
		class Land_home6b_ded_home6b_01_f {
			price = 200000;
			maxFurniture = 50;
			type = 0;
		};
		class Land_HouseDoubleAL {
			price = 240000;
			maxFurniture = 60;
			type = 0;
		};
		class Land_em_mansion_01 {
			price = 200000;
			maxFurniture = 60;
			type = 0;
		};
		class Land_HouseDoubleAL2 : Land_HouseDoubleAL{};
		class Land_home3r_ded_home3r_01_f : Land_home6b_ded_home6b_01_f{};
		class Land_em_mansion_01_reversed : Land_em_mansion_01{};

		//Modded 1 Story
		class Land_HouseA1 {
			price = 115000;
			maxFurniture = 30;
			type = 0;
		};
		class Land_Ranch_DED_Ranch_01_F {
			price = 100000;
			maxFurniture = 30;
			type = 0;
		};
		class Land_HouseC_R : Land_HouseA1{};
		class Land_HouseB1 : Land_HouseA1{};
		class Land_HouseB : Land_HouseA1{};
		class Land_HouseA : Land_HouseA1{};
		class Land_HouseC1_l : Land_HouseA1{};
		class Land_Ranch_DED_Ranch_02_F : Land_Ranch_DED_Ranch_01_F{};
		
		//Garages
		class Land_GarageShelter_01_F {
			price = 10000;
			maxFurniture = 0;
			type = 1;
			garageSpawnPos[] = {0.241684,-5.72266,-1.46744};
			garageSpawnDir = 90;
		};
		class Land_i_Garage_V2_F : Land_GarageShelter_01_F{};
		class Land_i_Garage_V1_F : Land_GarageShelter_01_F{};
		class Land_FuelStation_01_workshop_F : Land_GarageShelter_01_F{};
	};
	
	class Shops {
		class Land_Snow_Store {
			price = 45000;
			maxItems = 30;
		};
		class Land_Snow_Store2 : Land_Snow_Store{};
	};
};



