/*
* I NEED FINISHING
*    {item,{requiredItems},{requiredCounts},conditions,location,cost}
*/
class Crafting {
	class Basic {
		items[] = {
			{"TRYK_shirts_Floral1",{"Sack_Cotton"},{3},"",0},
			{"TRYK_shirts_Floral2",{"Sack_Cotton"},{3},"",0},
			{"TRYK_shirts_Floral3",{"Sack_Cotton"},{3},"",0},
			{"TRYK_shirts_Floral4",{"Sack_Cotton"},{3},"",0},
			{"TRYK_shirts_Floral5",{"Sack_Cotton"},{3},"",0},
			{"TRYK_shirts_Floral6",{"Sack_Cotton"},{3},"",0},
			{"TRYK_shirts_Floral7",{"Sack_Cotton"},{3},"",0},
			{"TRYK_shirts_Floral8",{"Sack_Cotton"},{3},"",0},
			{"TRYK_shirts_Plaid1",{"Sack_Cotton"},{3},"",0},
			{"TRYK_shirts_Plaid2",{"Sack_Cotton"},{3},"",0},
			{"TRYK_shirts_Plaid3",{"Sack_Cotton"},{3},"",0},
			{"TRYK_shirts_Plaid4",{"Sack_Cotton"},{3},"",0},
			{"TRYK_shirts_Plaid5",{"Sack_Cotton"},{3},"",0},
			{"TRYK_shirts_Plaid6",{"Sack_Cotton"},{3},"",0},
			{"TRYK_shirts_Plaid7",{"Sack_Cotton"},{3},"",0},
			{"TRYK_shirts_Plaid8",{"Sack_Cotton"},{3},"",0},
			{"TRYK_U_B_PCUGs_BLK",{"Sack_Cotton"},{3},"",0},
			{"TRYK_U_B_PCUGs_gry",{"Sack_Cotton"},{3},"",0},
			{"TRYK_U_B_PCUGs_OD",{"Sack_Cotton"},{3},"",0},
			{"TRYK_shirts_DENIM_BK",{"Sack_Cotton"},{3},"",0},
			{"TRYK_shirts_DENIM_BL",{"Sack_Cotton"},{3},"",0},
			{"TRYK_shirts_DENIM_BWH",{"Sack_Cotton"},{3},"",0},
			{"TRYK_shirts_DENIM_od",{"Sack_Cotton"},{3},"",0},
			{"TRYK_shirts_DENIM_R",{"Sack_Cotton"},{3},"",0},
			{"TRYK_shirts_DENIM_RED2",{"Sack_Cotton"},{3},"",0},
			{"TRYK_shirts_DENIM_WH",{"Sack_Cotton"},{3},"",0},
			{"TRYK_shirts_DENIM_ylb",{"Sack_Cotton"},{3},"",0},
			{"TRYK_shirts_BLK_PAD",{"Sack_Cotton"},{3},"",0},
			{"TRYK_shirts_DENIM_od_Sleeve",{"Sack_Cotton"},{3},"",0},
			{"TRYK_shirts_DENIM_ylb_Sleeve",{"Sack_Cotton"},{3},"",0},
			{"TRYK_shirts_DENIM_BK_Sleeve",{"Sack_Cotton"},{3},"",0},
			{"TRYK_shirts_DENIM_BL_Sleeve",{"Sack_Cotton"},{3},"",0},
			{"TRYK_shirts_DENIM_BWH_Sleeve",{"Sack_Cotton"},{3},"",0},
			{"TRYK_shirts_DENIM_R_Sleeve",{"Sack_Cotton"},{3},"",0},
			{"TRYK_shirts_PAD_BL",{"Sack_Cotton"},{3},"",0},
			{"TRYK_shirts_PAD_RED2",{"Sack_Cotton"},{3},"",0},
			{"hood_gucci_blk",{"Sack_Cotton"},{3},"",0},
			{"hood_gucci_beg",{"Sack_Cotton"},{3},"",0},
			{"hood_gucci_brr",{"Sack_Cotton"},{3},"",0},
			{"hood_riffraff",{"Sack_Cotton"},{3},"",0},
			{"hood_supreme",{"Sack_Cotton"},{3},"",0},
			{"hood_tri",{"Sack_Cotton"},{3},"",0},
			{"hood_space",{"Sack_Cotton"},{3},"",0},
			{"hood_nike_blk",{"Sack_Cotton"},{3},"",0},
			{"hood_nike_ylw",{"Sack_Cotton"},{3},"",0},
			{"hood_nike_red",{"Sack_Cotton"},{3},"",0},
			{"hood_nike_org",{"Sack_Cotton"},{3},"",0},
			{"hood_nike_grn",{"Sack_Cotton"},{3},"",0},
			{"hood_nike_gr",{"Sack_Cotton"},{3},"",0},
			{"hood_nike_blu",{"Sack_Cotton"},{3},"",0},
			{"hood_nike_wh",{"Sack_Cotton"},{3},"",0},
			{"TRYK_V_Bulletproof_BL",{"Sack_Cotton","np_ironbar1"},{3,1},"",0},
			{"TRYK_V_Bulletproof_BLK",{"Sack_Cotton","np_ironbar1"},{3,1},"",0},
			{"TRYK_V_Bulletproof",{"Sack_Cotton","np_ironbar1"},{3,1},"",0},
			{"V_PlateCarrier1_blk",{"Sack_Cotton","np_ironbar1"},{3,3},"",0},
			{"V_PlateCarrier1_rgr",{"Sack_Cotton","np_ironbar1"},{3,3},"",0},
			{"V_PlateCarrier1_tna_f",{"Sack_Cotton","np_ironbar1"},{3,3},"",0},
			{"V_PlateCarrier1_wdl",{"Sack_Cotton","np_ironbar1"},{3,3},"",0},
			{"TRYK_V_ArmorVest_Delta",{"Sack_Cotton","np_ironbar1"},{3,3},"",0},
			{"TRYK_V_ArmorVest_Brown",{"Sack_Cotton","np_ironbar1"},{3,3},"",0},
			{"TRYK_V_ArmorVest_CBR",{"Sack_Cotton","np_ironbar1"},{3,3},"",0},
			{"TRYK_V_ArmorVest_coyo",{"Sack_Cotton","np_ironbar1"},{3,3},"",0},
			{"hood_200T_blk",{"Sack_Cotton"},{3},"(player getVariable ['company',''] isEqualTo '200 Thieves')",0},
			{"Cap_200T",{"Sack_Cotton"},{2},"(player getVariable ['company',''] isEqualTo '200 Thieves')",0},
			{"Cap_200T2",{"Sack_Cotton"},{3},"(player getVariable ['company',''] isEqualTo '200 Thieves')",0}
			
		};

		materials[] = {
			{"NP_Wood",{"NP_uWood"},{1},"(player distance (getMarkerPos 'lumberprocessing') < 40) || (player distance (getMarkerPos 'lumberprocessing2') < 40)",0},
			{"np_ironbar1",{"VG_IronChunk"},{1},"(player distance (getMarkerPos 'RefineryMarker') < 40)",0},
			{"np_silverbar1",{"VG_SilverChunk"},{1},"(player distance (getMarkerPos 'RefineryMarker') < 40)",0},
			{"np_goldbar2",{"VG_GoldChunk"},{1},"(player distance (getMarkerPos 'RefineryMarker') < 40)",0},
			{"VG_Ruby",{"VG_RubyChunk"},{1},"(player distance (getMarkerPos 'RefineryMarker') < 40)",0},
			{"VG_Sapphire",{"VG_SapphireChunk"},{1},"(player distance (getMarkerPos 'RefineryMarker') < 40)",0},
			{"VG_Emerald",{"VG_GemChunk"},{1},"(player distance (getMarkerPos 'RefineryMarker') < 40)",0},
			{"VG_Diamond",{"VG_DiamondChunk"},{1},"(player distance (getMarkerPos 'RefineryMarker') < 40)",0},
			{"CG_Heroin",{"VG_Opium"},{1},"(player distance (getMarkerPos 'RefineryMarker') < 40)",0},
			{"CG_Cocaine",{"VG_DirtyCoke"},{1},"(player distance (getMarkerPos 'RefineryMarker') < 40)",0}
		};
		weapons[] = {
			{"SMA_SAR21_F",{"np_ironbar1","np_silverbar1"},{15,10},"(player distance (getMarkerPos 'WeaponsFactory') < 25)",0},
			{"SMA_MK18afgTAN_SM",{"np_ironbar1","np_silverbar1"},{15,10},"(player distance (getMarkerPos 'WeaponsFactory') < 25)",0},
			{"hlc_rifle_RU556",{"np_ironbar1","np_silverbar1"},{15,10},"(player distance (getMarkerPos 'WeaponsFactory') < 25)",0},
			{"SMA_30Rnd_556x45_M855A1",{"np_ironbar1"},{1},"(player distance (getMarkerPos 'WeaponsFactory') < 25)",0},
			{"hlc_30rnd_556x45_EPR",{"np_ironbar1"},{1},"(player distance (getMarkerPos 'WeaponsFactory') < 25)",0}
		};
		vehicles[] = {

		};
	};
	class Advanced {

	};
};