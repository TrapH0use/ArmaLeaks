class Skills {
	class Level_0 {
		experience = 0;
	};
	class Level_1 {
		experience = 2;
	};
	class Level_2 {
		experience = 5;
	};
	class Level_3 {
		experience = 9;
	};
	class Level_4 {
		experience = 14;
	};
	class Level_5 {
		experience = 20;
	};
	class Level_6 {
		experience = 27;
	};
	class Level_7 {
		experience = 35;
	};
	class Level_8 {
		experience = 44;
	};
	class Level_9 {
		experience = 54;
	};
	class Level_10 {
		experience = 65;
	};
	class Level_11 {
		experience = 77;
	};
	class Level_12 {
		experience = 90;
	};
	class Level_13 {
		experience = 104;
	};
	class Level_14 {
		experience = 119;
	};
	class Level_15 {
		experience = 135;
	};
	class Level_16 {
		experience = 152;
	};
	class Level_17 {
		experience = 170;
	};
	class Level_18 {
		experience = 189;
	};
	class Level_19 {
		experience = 209;
	};
	class Level_20 {
		experience = 230;
	};
	class Level_21 {
		experience = 252;
	};
	class Level_22 {
		experience = 275;
	};
	class Level_23 {
		experience = 299;
	};
	class Level_24 {
		experience = 324;
	};
	class Level_25 {
		experience = 350;
	};
	class Level_26 {
		experience = 377;
	};
	class Level_27 {
		experience = 405;
	};
	class Level_28 {
		experience = 434;
	};
	class Level_29 {
		experience = 464;
	};
	class Level_30 {
		experience = 495;
	};
	class Level_31 {
		experience = 527;
	};
	class Level_32 {
		experience = 560;
	};
	class Level_33 {
		experience = 594;
	};
	class Level_34 {
		experience = 629;
	};
	class Level_35 {
		experience = 665;
	};
	class Level_36 {
		experience = 702;
	};
	class Level_37 {
		experience = 740;
	};
	class Level_38 {
		experience = 779;
	};
	class Level_39 {
		experience = 819;
	};
	class Level_40 {
		experience = 860;
	};
	class Level_41 {
		experience = 902;
	};
	class Level_42 {
		experience = 945;
	};
	class Level_43 {
		experience = 989;
	};
	class Level_44 {
		experience = 1034;
	};
	class Level_45 {
		experience = 1080;
	};
	class Level_46 {
		experience = 1127;
	};
	class Level_47 {
		experience = 1175;
	};
	class Level_48 {
		experience = 1224;
	};
	class Level_49 {
		experience = 1274;
	};
	class Level_50 {
		experience = 1325;
	};
};
