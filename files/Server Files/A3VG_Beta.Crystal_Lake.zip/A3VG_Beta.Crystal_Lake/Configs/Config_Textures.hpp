/*
Texture with format {"nameoftexture",{"textures","anothertexture"},"conditions"}
If a vehicle has more then 1 hidden selection texture which needs changing, then put multiple textures in 2nd element
*/
class Textures {
	class Vehicle {
		class Default {
			textures[] = {};
		};

		class Car_Base {
			textures[] = {
				{"White",{"#(argb,8,8,3)color(1,1,1,1)"},"",0},
				{"Black",{"#(argb,8,8,3)color(0,0,0,1)"},"",0},
				{"Grey",{"#(argb,8,8,3)color(0.369,0.369,0.369,1)"},"",0},
				{"Silver",{"#(argb,8,8,3)color(0.561,0.561,0.561,1)"},"",0},
				{"Dark Grey",{"#(argb,8,8,3)color(0.29,0.29,0.29,1)"},"",0},
				{"Charcoal",{"#(argb,8,8,3)color(0.18,0.18,0.18,1)"},"",0},
				{"Red",{"#(argb,8,8,3)color(1,0,0,1)"},"",0},
				{"Maroon",{"#(argb,8,8,3)color(0.38,0.051,0,1)"},"",0},
				{"Coral",{"#(argb,8,8,3)color(0.678,0.427,0.388,1)"},"",0},
				{"Sunkist",{"#(argb,8,8,3)color(0.761,0.576,0.427,1)"},"",0},
				{"Orange",{"#(argb,8,8,3)color(0.702,0.392,0.141,1)"},"",0},
				{"Burnt Orange",{"#(argb,8,8,3)color(0.529,0.31,0,1)"},"",0},
				{"Racing Yellow",{"#(argb,8,8,3)color(1,0.816,0,1)"},"",0},
				{"Pale Yellow",{"#(argb,8,8,3)color(1,0.953,0.729,1)"},"",0},
				{"Acid Green",{"#(argb,8,8,3)color(0.808,0.969,0.008,1)"},"",0},
				{"Green",{"#(argb,8,8,3)color(0.337,0.631,0,1)"},"",0},
				{"Camo Green",{"#(argb,8,8,3)color(0.204,0.322,0.067,1)"},"",0},
				{"Aqua Green",{"#(argb,8,8,3)color(0,0.722,0.624,1)"},"",0},
				{"Cyan",{"#(argb,8,8,3)color(0,1,1,1)"},"",0},
				{"Light Blue",{"#(argb,8,8,3)color(0.243,0.624,0.71,1)"},"",0},
				{"Blue",{"#(argb,8,8,3)color(0,0,1,1)"},"",0},
				{"Navy Blue",{"#(argb,8,8,3)color(0.145,0.173,0.239,1)"},"",0},
				{"Indigo",{"#(argb,8,8,3)color(0.165,0.075,0.439,1)"},"",0},
				{"Pale Purple",{"#(argb,8,8,3)color(0.392,0.329,0.58,1)"},"",0},
				{"Purple",{"#(argb,8,8,3)color(0.349,0,1,1)"},"",0},
				{"Magenta",{"#(argb,8,8,3)color(0.549,0,1,1)"},"",0},
				{"Hot Pink",{"#(argb,8,8,3)color(0.733,0,1,1)"},"",0},
				{"Pink",{"#(argb,8,8,3)color(0.902,0.612,0.882,1)"},"",0},
				{"Reddish Pink",{"#(argb,8,8,3)color(0.58,0,0.369,1)"},"",0}
				
				
			};
		};

		class Jonzie_Raptor : Car_Base {};
		class Jonzie_Tow_Truck : Car_Base {};
		class Jonzie_Flat_Bed : Car_Base {};
		class Jonzie_Log_Truck : Car_Base {};
		class ivory_cv : Car_Base {};
		class ivory_taurus : Car_Base {};
		class ivory_suburban : Car_Base {};
		class ivory_challenger : Car_Base {};
		class ivory_charger : Car_Base {};
		class ivory_gti : Car_Base {};
		class Ivory_wrx : Car_Base {};
		class ivory_evox : Car_Base {};
		class ivory_supra : Car_Base {};
		class ivory_911 : Car_Base {};
		class ivory_r34 : Car_Base {};
		class ivory_mp4 : Car_Base {};
		class ivory_isf : Car_Base {};
		class Ivory_LFA : Car_Base {};
		class ivory_rs4 : Car_Base {};
		class ivory_c : Car_Base {};
		class ivory_elise : Car_Base {};
		class ivory_lp560 : Car_Base {};
		class ivory_e36 : Car_Base {};
		class ivory_f1 : Car_Base {};
		class ivory_r8 : Car_Base {};
		class ivory_r8_spyder : Car_Base {};
		class Ivory_gt500 : Car_Base {};
		class ivory_ccx : Car_Base {};
		class ivory_rev : Car_Base {};
		class ivory_veyron : Car_Base {};
		//Unmarked Cop Cars 
		class ivory_taurus_unmarked_norb : Car_Base {};
		class ivory_charger_unmarked_norb : Car_Base {};
		class ivory_cv_unmarked_norb : Car_Base {};
		class ivory_wrx_unmarked_norb : Car_Base {};
		class ivory_rs4_unmarked_norb : Car_Base {};
		class ivory_m3_unmarked_norb : Car_Base {};
		class ivory_isf_unmarked_norb : Car_Base {};
		class ivory_rev_unmarked_norb : Car_Base {};
	

		class ivory_evox_marked {
			textures[] = {
				{"Highway Patrol",{"\EMPIRE_Clothing\data\cartextures\HWPEvo.paa"},"(player getVariable ['department','Patrol']) isEqualTo 'Highway Patrol'",0},
				{"SWAT",{"\EMPIRE_Clothing\data\cartextures\SWAT.paa"},"(player getVariable ['department','Patrol']) isEqualTo 'SWAT'",0}
			};
		};
		class ivory_evox_unmarked_norb {
			textures[] = {
				{"SWAT",{"\EMPIRE_Clothing\data\cartextures\SWAT.paa"},"(player getVariable ['department','Patrol']) isEqualTo 'SWAT'",0}
			};
		};
		class ivory_taurus_marked {
			textures[] = {
				{"Patrol",{"\EMPIRE_Clothing\data\cartextures\Taurus.paa"},"(player getVariable ['faction','civ']) isEqualTo 'cop'",0},
				{"EMS",{"\EMPIRE_Clothing\data\cartextures\ivory_taurus_ems.paa"},"(player getVariable ['faction','civ']) isEqualTo 'medic'",0},
				{"Fire Department",{"\EMPIRE_Clothing\data\cartextures\ivory_taurus_FD.paa"},"(player getVariable ['faction','civ']) isEqualTo 'medic'",0}
				
			};
		};

		class ivory_cv_marked {
			textures[] = {
				{"Patrol",{"\EMPIRE_Clothing\data\cartextures\CVPI.paa"},"(player getVariable ['faction','civ']) isEqualTo 'cop'",0},
				{"EMS",{"\EMPIRE_Clothing\data\cartextures\ivory_cv_ems.paa"},"(player getVariable ['faction','civ']) isEqualTo 'medic'",0}
			};
		};

		class ivory_charger_marked {
			textures[] = {
				{"Patrol",{"\EMPIRE_Clothing\data\cartextures\Charger.paa"},"",0}
			};
		};

		class ivory_wrx_marked {
			textures[] = {
				{"Highway Patrol",{"\EMPIRE_Clothing\data\cartextures\HWPWrx.paa"},"(player getVariable ['department','Patrol']) isEqualTo 'Highway Patrol'",0},
				{"EMS",{"\EMPIRE_Clothing\data\cartextures\ivory_wrx_ems.paa"},"(player getVariable ['faction','civ']) isEqualTo 'medic'",0},
				{"Fire Department",{"\EMPIRE_Clothing\data\cartextures\ivory_WRX_fd.paa"},"(player getVariable ['faction','civ']) isEqualTo 'medic'",0}
			};
		};

		class B_Heli_Light_01_F {
			textures[] = {
				{"Patrol",{"\a3\air_f\Heli_Light_01\Data\heli_light_01_ext_ion_co.paa"},"(player getVariable ['faction','civ']) isEqualTo 'cop'",0},
				{"EMS",{"#(argb,8,8,3)color(1,1,1,0.8)"},"(player getVariable ['faction','civ']) isEqualTo 'medic'",0},
			};
		};
		class Jonzie_Ambulance {
			textures[] = {
				{"EMS",{"\EMPIRE_Clothing\data\cartextures\Jonzie_Ambo_EMS.paa"},"(player getVariable ['faction','civ']) isEqualTo 'medic'",0},
				{"Fire Department",{"\EMPIRE_Clothing\data\cartextures\Jonzie_Ambo_FD.paa"},"(player getVariable ['faction','civ']) isEqualTo 'medic'",0}
			};
		};
		class Fox_Firetruck {
            textures[] = {
                {"Fire Department",{"\fox_skins\textures\arrowxtladder\cab.paa", "\fox_skins\textures\arrowxtladder\pumperbody.paa"},"(player getVariable ['faction','civ']) isEqualTo 'medic'",0}
            };
        };
        class Fox_ArrowXTLadder {
            textures[] = {
                {"Fire Department",{"\fox_skins\textures\arrowxtladder\cab.paa", "\fox_skins\textures\arrowxtladder\ladder.paa"},"(player getVariable ['faction','civ']) isEqualTo 'medic'",0}
            };
        };
        class Fox_HeavyRescue {
            textures[] = {
                {"Fire Department",{"\fox_skins\textures\heavyrescue\cab_camo1.paa", "\fox_skins\textures\heavyrescue\rescue_camo2.paa"},"(player getVariable ['faction','civ']) isEqualTo 'medic'",0}
            };
        };
        class Fox_HeavyRescue2 {
            textures[] = {
                {"Fire Department",{ "\fox_skins\textures\heavyrescue\cab_camo1_skin2.paa", "\fox_skins\textures\heavyrescue\rescue_camo2_skin2.paa" },"(player getVariable ['faction','civ']) isEqualTo 'medic'",0}
            };
		};

		class C_Boat_Civil_01_police_F {
			textures[] = {};
		};
		class B_SDV_01_F {
			textures[] = {};
		};
	};
};

class Modifications {
	class car {
		rvmats[] = {
			{"Default","\ivory_data\data\glossy.rvmat","",100},
			{"Matte","\ivory_data\data\matte.rvmat","",1000},
			{"Metallic","\ivory_data\data\metallic.rvmat","",400},
			// Special RVMATS
			{"Pearlescent Blue","\EMPIRE_Clothing\data\cartextures\pearl_blue.rvmat","",2200},
			{"Pearlescent Red","\EMPIRE_Clothing\data\cartextures\pearl_red.rvmat","",2200},
			{"Pearlescent Green","\EMPIRE_Clothing\data\cartextures\pearl_green.rvmat","",2200},
			{"Pearlescent Yellow","\EMPIRE_Clothing\data\cartextures\pearl_yellow.rvmat","",2200},
			{"Pearlescent Purple","\EMPIRE_Clothing\data\cartextures\pearl_purple.rvmat","",2200},
			{"Chrome","\EMPIRE_Clothing\data\cartextures\Chrome.rvmat","",3500},
			{"Gold Chrome","\EMPIRE_Clothing\data\cartextures\ChromeGold.rvmat","",5500},
			{"Rose Gold Chrome","\EMPIRE_Clothing\data\cartextures\ChromeRoseGold.rvmat","",4750},
			{"Blue Chrome","\EMPIRE_Clothing\data\cartextures\chromeBlue.rvmat","",4750},
			{"Red Chrome","\EMPIRE_Clothing\data\cartextures\chromeRed.rvmat","",4750},
			{"Green Chrome","\EMPIRE_Clothing\data\cartextures\chromeGreen.rvmat","",4750},
			{"Orange Chrome","\EMPIRE_Clothing\data\cartextures\chromeOrange.rvmat","",4750},
			{"Purple Chrome","\EMPIRE_Clothing\data\cartextures\chromePurple.rvmat","",4750},
			{"Pink Chrome","\EMPIRE_Clothing\data\cartextures\chromePink.rvmat","",4750}
		};
		plates[] = {//cant change plates, just leave this section blank
			//{"Default","\A3VG_Core\data\Vehicles\plates\plate.paa","",100},
			//{"Crystal Lake","texture\path","",0},s
			//{"Emergency","texture\path","player getVariable ['faction',''] != 'civ'",0}
		};
		tint[] = {
			{"Default",0.01,"",0},
			{"10%",0.1,"",100},
			{"20%",0.2,"",200},
			{"30%",0.3,"",300},
			{"40%",0.4,"",400},
			{"50%",0.5,"",500},
			{"60%",0.6,"",600},
			{"70%",0.7,"",700},
			{"80%",0.8,"",800},
			{"90%",0.9,"",900},
			{"100%",1,"",1000}
		};
		wheelColour[] = {
				{"White","#(argb,8,8,3)color(1,1,1,1)","",0},
				{"Black","#(argb,8,8,3)color(0,0,0,1)","",0},
				{"Grey","#(argb,8,8,3)color(0.369,0.369,0.369,1)","",0},
				{"Silver","#(argb,8,8,3)color(0.561,0.561,0.561,1)","",0},
				{"Dark Grey","#(argb,8,8,3)color(0.29,0.29,0.29,1)","",0},
				{"Charcoal","#(argb,8,8,3)color(0.18,0.18,0.18,1)","",0},
				{"Red","#(argb,8,8,3)color(1,0,0,1)","",0},
				{"Maroon","#(argb,8,8,3)color(0.38,0.051,0,1)","",0},
				{"Coral","#(argb,8,8,3)color(0.678,0.427,0.388,1)","",0},
				{"Sunkist","#(argb,8,8,3)color(0.761,0.576,0.427,1)","",0},
				{"Orange","#(argb,8,8,3)color(0.702,0.392,0.141,1)","",0},
				{"Burnt Orange","#(argb,8,8,3)color(0.529,0.31,0,1)","",0},
				{"Racing Yellow","#(argb,8,8,3)color(1,0.816,0,1)","",0},
				{"Pale Yellow","#(argb,8,8,3)color(1,0.953,0.729,1)","",0},
				{"Acid Green","#(argb,8,8,3)color(0.808,0.969,0.008,1)","",0},
				{"Green","#(argb,8,8,3)color(0.337,0.631,0,1)","",0},
				{"Camo Green","#(argb,8,8,3)color(0.204,0.322,0.067,1)","",0},
				{"Aqua Green","#(argb,8,8,3)color(0,0.722,0.624,1)","",0},
				{"Cyan","#(argb,8,8,3)color(0,1,1,1)","",0},
				{"Light Blue","#(argb,8,8,3)color(0.243,0.624,0.71,1)","",0},
				{"Blue","#(argb,8,8,3)color(0,0,1,1)","",0},
				{"Navy Blue","#(argb,8,8,3)color(0.145,0.173,0.239,1)","",0},
				{"Indigo","#(argb,8,8,3)color(0.165,0.075,0.439,1)","",0},
				{"Pale Purple","#(argb,8,8,3)color(0.392,0.329,0.58,1)","",0},
				{"Purple","#(argb,8,8,3)color(0.349,0,1,1)","",0},
				{"Magenta","#(argb,8,8,3)color(0.549,0,1,1)","",0},
				{"Hot Pink","#(argb,8,8,3)color(0.733,0,1,1)","",0},
				{"Pink","#(argb,8,8,3)color(0.902,0.612,0.882,1)","",0},
				{"Reddish Pink","#(argb,8,8,3)color(0.58,0,0.369,1)","",0}
		};
		proxies[] = {//leave for now
			//{"No spoiler",{},"",100},
			//{"Spoiler",{},"player getVariable ['faction',''] != 'civ'",0}
		};
	};
};