class Wiki {
	General[] = {
		{
			"Getting Started",
			{
				"",
				"icons\ico_apple.paa",
				"Rules",
				"Before you get started on your path as whatever you have chosen to be, please be sure to read our rules on our community forum! Website = https://forums.vanguardgaming.net/ 
                Keep in mind, we value roleplay over ruleplay here at Vanguard. It is possible for staff to show leniency on rule breaks if proper roleplay was involved."
			},
			{
				"",
				"icons\ico_apple.paa",
				"Legal Money Making",
				"There are many ways to make money in the vast land of Crystal Lake. Live the lifestyle of Miner, Farmer, or a Fisherman, if that doesn't suit your needs perhaps you can start your own company and purchase your own shop to sell products! 
                Of course there are other ways to make money however. Try out our Taxi, Towtruck, Delivery, or Security Jobs as well!"
			},
            {
				"",
				"icons\ico_apple.paa",
				"Illegal Money Making",
				"So you've chosen the life of crime huh? Well, lucky for you there's plenty illegal ways to make plenty of money if you're willing to put in the time! See the see the Illegal Money Methods tab below for more information on this matter!"
			}
		},
		{
			"Legal Money Methods",
			{
				"",
				"icons\ico_apple.paa",
				"Farming",
				"Purchase any of our premium quality seeds from any of the Resource Markets around Crystal Lake to begin your path as a farmer! Once you've got the seeds, find suitable land
                and open your inventory and double click on the seed you'd like to plant to make it your active seed. Once you do that, look at the soil and hit your windows key and select Plant Seed.
                Once the seed is planted, it will take 3 minutes for the plant to grow before you can harvest it for it's resources. Once you harvest your crop, take it to the resource market and sell it to the vendor!"
			},
			{
				"",
				"icons\ico_apple.paa",
				"Mining",
				"To begin mining, you're gonna need to purchase a pickaxe from the resource market. Once you've done that, head on down to the mine and begin mining the colored rock deposits around the area. 
                Generally speaking, you'll normally get some chunks of rock along with a few pieces of the ore that you are mining. If you're lucky, you'll maybe even find Rubies, Sapphires, Emeralds, or even diamonds!
                Once you fill up you and your vehicle's inventory on supplies you can take them directly to the resource market and sell. However, if you take the extra time to refine your ores into Ingots and Minerals, you can make double the profit!"
			},
            {
				"",
				"icons\ico_apple.paa",
				"Fishing",
				"To effectively fish you'll need to set out on the water with a boat and a fishing net that you've purchased from the Resource Market. Once on the water, open your inventory and double click on the fishing net to deploy it. Once deployed, 
                it will gather fish that swim into it over time. Once your net is full, simply bring it up and go sell your fish at the Resource Market!"
			},
            {
				"",
				"icons\ico_apple.paa",
				"Hunting",
				"To begin hunting, you're gonna need a suitable firearm to do the job. The Double Barreled shotgun or the AR-10 are suitable weapons for this journey, so go ahead and purhcase one of them from the Gun Store (Be sure you have your rifle license!).
                Once you have your equipment, head over to the hunting area and start hunting! Every animal you kill you'll be able to Gut by hitting Windows Key on their body. Once you've harvested enough meat, sell it all to the General Stores around the map."
			},
            {
				"",
				"icons\ico_apple.paa",
				"Refining",
				"To refine objects, simply head over to one of the Refineries on the map and find the large warehouse. As long as you're within 40 meters of the refinery, hit your Windows Key and select the crafting menu.
                From here you'll be able to see all of your materials and be able to craft your raw ores and materials into ingots and minerals. Once you've completed all of the above and you're loaded on refined materials, go sell them at the resource market!"
			}
		},
        {
			"Player Jobs",
			{
				"",
				"icons\ico_apple.paa",
				"Security",
				"TBA"
			},
			{
				"",
				"icons\ico_apple.paa",
				"Taxi Driver",
				"TBA"
			},
            {
				"",
				"icons\ico_apple.paa",
				"Delivery Man",
				"TBA"
			},
            {
				"",
				"icons\ico_apple.paa",
				"Tow Trucker",
				"TBA"
			},
		},
		{
			"Illegal Money Methods",
			{
				"(player getVariable ['faction','civ'] isEqualTo 'civ')",
				"icons\ico_apple.paa",
				"Drug Cultivation",
				"Purchase your seeds of choice from the Drug Dealer to start your quest of becoming a drug kingpin! Once you've got the seeds you need, find suitable land to plant your crops on and wait for your plants to grow.
                Once they are fully grown, harvest the drugs and decide what to do next. If you are farming Cocaine or Opium, chances are you'll get either Raw Opium or Dirty Coke from the crops. You can sell these low-grade materials to the dealer (See Illegal Vendors Tab to find out how to located the dealer), but you won't get nearly as much if you refine them.
                For doubled profits, you can refine the drugs into Cocaine and Heroin at the refinery! (See Refining Tab)"
			},
			{
				"(player getVariable ['faction','civ'] isEqualTo 'civ')",
				"icons\ico_apple.paa",
				"Store Robberies",
				"If you've got the guts and the will, you can make a good sum of money from robbing stores around the map. All you need is a weapon and head over to any of the Item or Clothing stores around the map and begin robbing the clerk! 
                You will get a handful of cash every few seconds until the register is empty. Be careful though, cops get notified of these robberies and are highly likely to respond. So make sure you have a get away plan!"
			},
            {
				"(player getVariable ['faction','civ'] isEqualTo 'civ')",
				"icons\ico_apple.paa",
				"Place Holder",
				"Place Holder"
			},
            {
				"(player getVariable ['faction','civ'] isEqualTo 'civ')",
				"icons\ico_apple.paa",
				"Major Crimes",
				"Major Crimes are perhaps the best ways to make a large sum of money in the shortest amount of time. For more details on how to commit a major crime, see the Major Crimes Tab below."
			}
		},
        {
			"Refining",
			{
				"",
				"icons\ico_apple.paa",
				"Refining Items",
				"To refine objects, simply head over to one of the Refineries on the map and find the large warehouse. As long as you're within 40 meters of the refinery, hit your Windows Key and select the crafting menu.
                From here you'll be able to see all of your materials and be able to craft your raw ores and materials into ingots and minerals. Once you've completed all of the above and you're loaded on refined materials, go sell them at the resource market or Drug Dealer."
			}
		},
        {
			"Businesses",
			{
				"",
				"icons\ico_apple.paa",
				"Start a Business",
				"To start a business, hit F2 and it will open the Company Menu. Kepe in mind, you will need $25,000 to start your business, so make sure you have your finances arranged! Once you've created your company, you'll be able to recruit members
                by hitting Windows Key on someone and selcting the Company Invite option. In the Manage Tab, you can create status updates, announcements, and you can fully manage your staff by selecting selecting supervisors and managers. Here, you can also 
                chose salaries for your company members. Salaries will be pulled out of your company bank account each time a paycheck cycle occurs. Keep in mind, you can deposit any amount of money into your company bank from any ATM on the map."
			},
            {
				"",
				"icons\ico_apple.paa",
				"Buying a Shop",
				"Once you've started a business, locate one of the few hundred Shops around the map and you'll be able to purchase one for $45,000. Here you will be able to supply your store with product, mandate prices, and collect revenue. 
                Once you've started making a bit of money from your business, it would be smart to invest in a security system to stop any burglars looking for loot!"
			}
		},
        {
			"Illegal Vendors",
			{
				"(player getVariable ['faction','civ'] isEqualTo 'civ')",
				"icons\ico_apple.paa",
				"Drug Dealer",
				"Drug Dealers are hidden on the map until you ask a vendor about him. Locate any of the General Store, McDonalds, Resource Market, or Gun Store NPC's and you'll be able to Ask them about the drug dealer through your Windows Key Menu.
                Usually, it will cost you $100 or so to bribe the vendor so he'll tell you where to go. However, they aren't always completely accurate with their locations. Once they've taken your money and decided to cooperate, they will mark two locations on your map
                with red circles. The Drug Dealer is at one of these markers... Here you will be able to purchase Drug Seeds and sell your drugs. Also, keep in mind the Drug Dealer moves every 30 minutes or so (Unless someone stays within 300 Meters of him)! So you might have to ask vendors his whereabouts more than once."
			},
            {
				"(player getVariable ['faction','civ'] isEqualTo 'civ')",
				"icons\ico_apple.paa",
				"Black Market Dealer",
				"Black Market Dealers are hidden on the map until you ask a vendor about him. Locate any of the clothing store NPC's or the Rebel Vendor and you'll be able to Ask them about the black market dealer through your Windows Key Menu.
                Usually, it will cost you $100 or so to bribe the vendor so he'll tell you where to go. However, they aren't always completely accurate with their locations. Once they've taken your money and decided to cooperate, they will mark two locations on your map
                with red circles. The Black Market is at one of these markers... Here you will be able to purchase high-tier weapons and gear. Also, keep in mind the Black Market Dealer moves every 30 minutes or so (Unless someone stays within 300 Meters of him)! So you might have to ask vendors his whereabouts more than once."
			}
		},
        {
			"Major Crimes",
			{
				"",
				"icons\ico_apple.paa",
				"Bank Robbery",
				"TBA"
			},
            {
				"",
				"icons\ico_apple.paa",
				"Department of Corrections",
				"TBA"
			}
		}
	};
};