#define ST_CENTER         0x02

/*
    Arma Life Development
	Anxious / Andy Jones
*/

class AL_Hud {
    idd = -1;
    duration = 1e+1000;
    movingEnable = 0;
    fadein = 0;
    fadeout = 0;
    name = "AL_Hud";
    onLoad = "uiNamespace setVariable ['AL_Hud',_this select 0]";
    objects[] = {};
    controls[] = {
        Armalife_Background,
        Armalife_Header,
        Armalife_FoodIcon,
        Armalife_WaterIcon,
        Armalife_HealthIcon,
        Armalife_RscProgress_HUDFood,
        Armalife_RscProgress_HUDHealth,
        Armalife_RscProgress_HUDWater,
        Armalife_RscText_HUDHealth,
        Armalife_RscText_HUDFood,
        Armalife_RscText_HUDWater,
		Armalife_ThreatLevelText
    };

																/* BG */
	class Armalife_Background: Life_RscText
	{
		idc = -1;
		x = 0.823776 * safezoneW + safezoneX;
		y = 0.814091 * safezoneH + safezoneY;
		w = 0.171877 * safezoneW;
		h = 0.112847 * safezoneH;
		colorBackground[] = {0.2,0.2,0.2,1};
	};
	class Armalife_Header: Life_RscText
	{
		idc = 1203;
		text = "Player Stats - ";
		x = 0.823776 * safezoneW + safezoneX;
		y = 0.795283 * safezoneH + safezoneY;
		w = 0.171877 * safezoneW;
		h = 0.0188079 * safezoneH;
		colorBackground[] = {0,0.3,0.5,1};
	};


																/* Icons */

	class Armalife_FoodIcon: life_RscPicture
    {
        idc = -1;
        text = "ArmaLifeCore\images\textures\newhud\health.paa";
        x = 0.825489 * safezoneW + safezoneX;
        y = 0.8208 * safezoneH + safezoneY;
        w = 0.0152631 * safezoneW;
        h = 0.0282118 * safezoneH;
    };
    class Armalife_WaterIcon: life_RscPicture
    {
        idc = -1;
        text = "ArmaLifeCore\images\textures\newhud\hunger.paa";
        x = 0.821718 * safezoneW + safezoneX;
        y = 0.852717 * safezoneH + safezoneY;
        w = 0.0220355 * safezoneW;
        h = 0.0376157 * safezoneH;
    };
    class Armalife_HealthIcon: life_RscPicture
    {
        idc = -1;
        text = "ArmaLifeCore\images\textures\newhud\thirst.paa";
        x = 0.825062 * safezoneW + safezoneX;
        y = 0.893683 * safezoneH + safezoneY;
        w = 0.0152631 * safezoneW;
        h = 0.0282118 * safezoneH;
    };


																/* Progress Bars */
																
	class Armalife_RscProgress_HUDFood: Life_RscProgress
	{
		idc = 2200;
		colorBar[] = {0,0.3,0.5,1};
		colorFrame[] = {1, 1, 1, 1};
		x = 0.842776 * safezoneW + safezoneX;
		y = 0.858478 * safezoneH + safezoneY;
		w = 0.149841 * safezoneW;
		h = 0.0282118 * safezoneH;
	};
	class Armalife_RscProgress_HUDHealth: Life_RscProgress
	{
		idc = 2201;
		colorBar[] = {0,0.3,0.5,1};
		colorFrame[] = {1, 1, 1, 1};
		x = 0.842776 * safezoneW + safezoneX;
		y = 0.820486 * safezoneH + safezoneY;
		w = 0.149841 * safezoneW;
		h = 0.0282118 * safezoneH;
	};
	class Armalife_RscProgress_HUDWater: Life_RscProgress
	{
		idc = 2202;
		colorBar[] = {0,0.3,0.5,1};
		colorFrame[] = {1, 1, 1, 1};
		x = 0.842776 * safezoneW + safezoneX;
		y = 0.894965 * safezoneH + safezoneY;
		w = 0.149841 * safezoneW;
		h = 0.0282118 * safezoneH;
	};

																/* Texts */

	class Armalife_RscText_HUDHealth: Life_RscText
	{
		idc = 1201;
		text = "100%"; //--- ToDo: Localize;
		x = 0.971444 * safezoneW + safezoneX;
		y = 0.820486 * safezoneH + safezoneY;
		w = 0.0396638 * safezoneW;
		h = 0.0282118 * safezoneH;
	};
	class Armalife_RscText_HUDFood: Life_RscText
	{
		idc = 1200;
		text = "100%"; //--- ToDo: Localize;
		x = 0.971444 * safezoneW + safezoneX;
		y = 0.858478 * safezoneH + safezoneY;
		w = 0.0396638 * safezoneW;
		h = 0.0282118 * safezoneH;
	};
	class Armalife_RscText_HUDWater: Life_RscText
	{
		idc = 1202;
		text = "100%"; //--- ToDo: Localize;
		x = 0.971444 * safezoneW + safezoneX;
		y = 0.894965 * safezoneH + safezoneY;
		w = 0.0396638 * safezoneW;
		h = 0.0282118 * safezoneH;
	};
    class Armalife_ThreatLevelText: life_RscText
    {
        idc = 1251;
        text = "THREAT LEVEL";
		x = 0.950229 * safezoneW + safezoneX;
		y = 0.924305 * safezoneH + safezoneY;
		w = 0.061875 * safezoneW;
		h = 0.0219999 * safezoneH;
        colorText[] = {0.063,0.776,0,1};
        SizeEx = 0.035;

    };
    class Armalife_ServerVersion: life_RscText
	{
		idc = 1252;
		font = "PuristaSemiBold";
		text = "v"; 
		x = 0.962 * safezoneW + safezoneX;
		y = 0.9554 * safezoneH + safezoneY;
		w = 0.0360937 * safezoneW;
		h = 0.022 * safezoneH;
		colorText[] = {1,1,1,1};
	};
};
