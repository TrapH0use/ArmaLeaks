/*
/*
*    ARRAY FORMAT:
*        0: STRING (Classname): Item Classname
*        1: STRING (Description): Description of item
*        2: SCALAR (Buy price): Cost of item
*        3: STRING (Conditions): Same as above conditions string
*        4: STRING (Nickname): Nickname that will appear purely in the shop dialog
*/

class WeaponShops {
  class cop {
    name = "Cop Weapon Shop";
    conditions = "call life_coplevel >= 1";
    side = "cop";
    weapons[] = {
      { "HandGrenade_Stone", "Blind your suspects and get the upper hand.", 3500, "call life_copdept in [6,7,8]", "Flashbang"},
      { "SmokeShellBlue", "", 2500, "call life_copdept in [6,7,8]", ""},
      { "SmokeShellRed", "", 2500, "call life_copdept in [6,7,8]", ""},
      { "SmokeShellGreen", "", 2500, "call life_copdept in [6,7,8]", ""},
	  { "KA_M7A3", "", 2500, "call life_copdept in [6,7,8]", ""},
	  { "KA_M7290", "", 2500, "call life_copdept in [6,7,8]", ""},
	  { "KA_M84", "", 2500, "call life_copdept in [6,7,8]", ""},
      { "taser", "A gun that will drop your target", 50, "call life_coplevel >= 1", ""},
      { "hlc_Pistol_M11", "", 580, "true", ""},
      { "hlc_pistol_Mk25", "", 570, "true", ""},
      { "hlc_pistol_P226WestGerman", "", 670, "true", ""},
      { "hlc_Pistol_P228", "", 670, "true", ""},
      { "hlc_Pistol_M11A1", "", 680, "true", ""},
      { "hlc_Pistol_M11A1D", "", 680, "true", ""},
      { "hlc_pistol_Mk25D", "", 670, "true", ""},
      { "hlc_pistol_Mk25TR", "", 670, "true", ""},
      { "arifle_SDAR_F", "", 6000, "call life_coplevel >= 5 || call life_copdept in [5,6,7,8]", ""},
      { "hlc_smg_mp5a3", "", 4000, "call life_coplevel >= 1 || call life_copdept in [5,6,7,8]", ""},
	  { "RH_sbr9", "", 4000, "call life_coplevel >= 2 || call life_copdept in [5,6,7,8]", ""},
	  { "Mossberg_590", "", 8000, "call life_coplevel >= 3 || call life_copdept in [5,6,7,8]", ""},
      { "hlc_smg_mp510", "", 4000, "call life_coplevel >= 6 || call life_copdept in [6,7,8]", ""},
      { "hlc_smg_9mmar", "", 4000, "call life_coplevel >= 6 || call life_copdept in [6,7,8]", ""},
      { "hlc_rifle_M4", "", 15000, "call life_coplevel >= 3 || call life_copdept in [5,6,7,8]", ""},
      { "hlc_rifle_CQBR", "", 15000, "call life_coplevel >= 3 || call life_copdept in [5,6,7,8]", ""},
      { "hlc_rifle_RU556", "", 15000, "call life_coplevel >= 3 || call life_copdept in [5,6,7,8]", ""},
      { "hlc_rifle_bcmjack", "", 15000, "call life_coplevel >= 4 || call life_copdept in [6,7,8]", ""},
      { "hlc_rifle_SAMR", "", 15000, "call life_coplevel >= 5 || call life_copdept in [5,6,7,8]", ""},
      { "hlc_rifle_auga3_bl", "", 15000, "call life_coplevel >= 4 || call life_copdept in [5,6,7,8]", ""},
      { "hlc_rifle_ACR68_mid_black", "", 15000, "call life_coplevel >= 6 || call life_copdept in [5,6,7,8]", ""},
      { "arifle_SPAR_01_blk_F", "", 15000, "call life_coplevel >= 6 || call life_copdept in [5,6,7,8]", ""},
      { "hlc_rifle_mk18mod0", "", 15000, "call life_coplevel >= 6 || call life_copdept in [5,6,7,8]", ""},
      { "hlc_rifle_FN3011", "", 15000, "call life_coplevel >= 5 || call life_copdept in [6,7,8]", ""},
      { "hlc_rifle_SG550Sniper_RIS", "", 15000, "call life_coplevel >= 5 && call life_copdept in [6,7,8]", ""},
      { "hlc_rifle_awmagnum_BL", "", 15000, "call life_coplevel >= 5 && call life_copdept in [6,7,8]", ""},
      { "hlc_rifle_honeybadger", "", 15000, "call life_coplevel >= 5 && call life_copdept in [6,7,8]", ""},
      { "hlc_rifle_Bushmaster300", "", 15000, "call life_coplevel >= 5 && call life_copdept in [6,7,8]", ""},
	  { "hlc_smg_mp5k", "", 3000, "call life_coplevel >= 4 && call life_copdept in [6,7,8]", ""},
      { "launch_B_Titan_F", "This will launch fuel rockets at heli when locking on.", 60000, "call life_copdept in [5,7,8]", "Fuel Rocket Launcher"},
      { "RH_M16A6", "", 15000, "call life_coplevel >= 3 && call life_copdept in [6,7,8]", ""},
      { "hlc_rifle_M14dmr_Rail", "", 15000, "call life_coplevel >= 5 && call life_copdept in [6,7,8]", ""},
      { "KA_CS5", "", 15000, "call life_coplevel >= 5 && call life_copdept in [6,7,8]", ""},
      { "RH_Mk12mod1", "", 15000, "call life_coplevel >= 5 && call life_copdept in [6,7,8]", ""},
      { "KA_M1014", "", 15000, "call life_coplevel >= 4 && call life_copdept in [6,7,8]", ""},
      { "KA_PDR", "", 15000, "call life_coplevel >= 4 && call life_copdept in [6,7,8]", ""},
      { "KA_M98B", "", 15000, "call life_coplevel >= 4 && call life_copdept in [6,7,8]", ""},
      { "RH_Deaglem", "", 5000, "call life_coplevel >= 4 && call life_copdept in [6,7,8]", ""},
      { "RH_M4sbr_b", "", 15000, "call life_coplevel >= 4 || call life_copdept in [6,7,8]", ""},
      { "RH_M4A1_ris", "", 15000, "call life_coplevel >= 3 || call life_copdept in [6,7,8]", ""},
      { "RH_M16A2", "", 15000, "call life_coplevel >= 2 || call life_copdept in [6,7,8]", ""},
      { "RH_Hk416s", "", 15000, "call life_coplevel >= 3 || call life_copdept in [6,7,8]", ""},
      { "KA_SCAR_L_Black_Grip", "", 15000, "call life_coplevel >= 5 || call life_copdept in [6,7,8]", ""},
      { "KA_SCAR_L_Black_Hand", "", 15000, "call life_coplevel >= 5 || call life_copdept in [6,7,8]", ""},
      { "RH_kimber_nw", "", 680, "true", ""},
      { "RH_g19", "", 680, "true", ""},
      { "RH_mp412", "", 680, "true", ""},
      { "RH_fn57", "", 680, "true", ""},
      { "RH_m9", "", 680, "true", ""},
      { "RH_m1911", "", 680, "true", ""},
      { "RH_uspm", "", 680, "true", ""},
      { "RH_g19", "", 680, "true", ""},
      { "RH_gsh18", "", 680, "true", ""},

	  //DTU weapons
      { "KA_machete", "", 5000, "call life_copdept in [6,7,8]", ""},
      { "KA_dagger", "", 5000, "call life_copdept in [6,7,8]", ""},
      { "KA_axe", "", 5000, "call life_copdept in [6,7,8]", ""},
      { "KA_knife", "", 5000, "call life_copdept in [6,7,8]", ""},
      { "arifle_AKS_F", "", 15000, "call life_copdept in [6,7,8]", ""},
      { "hlc_rifle_CQBR", "", 15000, "call life_copdept in [6,7,8]", ""},
  	  { "hlc_rifle_RPK12", "", 15000, "call life_copdept in [6,7,8]", ""},
      { "arifle_CTAR_hex_F", "", 15000, "call life_copdept in [6,7,8]", ""},
      { "hlc_rifle_aek971_mtk", "", 15000, "call life_copdept in [6,7,8]", ""},
      { "hlc_rifle_ACR_SBR_tan", "", 15000, "call life_copdept in [6,7,8]", ""},
      { "hlc_rifle_SG553LB_RIS", "", 15000, "call life_copdept in [6,7,8]", ""},
      { "hlc_rifle_ak74", "", 15000, "call life_copdept in [6,7,8]", ""},
      { "hlc_rifle_rpk74n", "", 15000, "call life_copdept in [6,7,8]", ""},
      { "hlc_rifle_ak12", "", 15000, "call life_copdept in [6,7,8]", ""},
      { "RH_mk2", "", 15000, "call life_copdept in [6,7,8]", ""},
      { "RH_ttracker_g", "", 6000, "call life_copdept in [6,7,8]", ""},
      { "RH_muzi", "", 15000, "call life_copdept in [6,7,8]", ""},
      { "RH_vp70", "", 15000, "call life_copdept in [6,7,8]", ""},
      { "RH_bullb", "", 7000, "call life_copdept in [6,7,8]", ""},
      { "AN94_MTK83", "", 15000, "call life_copdept in [6,7,8]", ""},
      { "KA_UMP45", "", 15000, "call life_copdept in [6,7,8]", ""},
    };

    magazines[] = {
      { "RH_32Rnd_9mm_M822", "", 10, "true", ""},
      { "KA_CS5_10rnd_M993_AP_mag", "", 10, "true", ""},
      { "8Rnd_SPAS12_buck", "", 10, "true", ""},
      { "KA_SCAR_L_30rnd_Mk318_SOST_mag", "", 10, "call life_coplevel >= 5 || call life_copdept in [6,7,8]", ""},
      { "RH_7Rnd_45cal_m1911", "", 10, "true", ""},
      { "RH_30Rnd_556x45_Mk262", "", 10, "true", ""},
      { "RH_17Rnd_9x19_g17", "", 10, "true", ""},
      { "RH_6Rnd_357_Mag", "", 10, "true", ""},
      { "RH_20Rnd_57x28_FN", "", 10, "true", ""},
      { "RH_15Rnd_9x19_M9", "", 10, "true", ""},
      { "RH_16Rnd_40cal_usp", "", 10, "true", ""},
      { "RH_18Rnd_9x19_gsh", "", 10, "true", ""},
      { "KA_15Rnd_45ACP_Mag", "", 10, "true", ""},
      { "RH_7Rnd_50_AE", "", 10, "true", ""},
      { "RH_30Rnd_68x43_FMJ", "call life_coplevel >= 3 && call life_copdept in [6,7,8]", 10, "true", ""},
      { "SMA_30Rnd_556x45_Mk262", "call life_coplevel >= 3 && call life_copdept in [6,7,8]", 10, "true", ""},
      { "hlc_20Rnd_762x51_mk316_M14", "call life_coplevel >= 3 && call life_copdept in [6,7,8]", 10, "true", ""},
      { "6Rnd_M1014_buck", "call life_coplevel >= 3 && call life_copdept in [6,7,8]", 10, "true", ""},
      { "KA_M98B_10Rnd_338_API526_Mag", "call life_coplevel >= 3 && call life_copdept in [6,7,8]", 10, "true", ""},
      { "vvv_np_magazine_taser", "Magazine for tazer", 5, "call life_coplevel >= 1", ""},
      { "KA_15Rnd_45ACP_Mag", "call life_coplevel >= 3 && call life_copdept in [6,7,8]", 10, "true", ""},
      { "8Rnd_9x19_Magazine", "", 10, "true", ""},
      { "hlc_13Rnd_9x19_B_P228", "", 10, "true", ""},
      { "hlc_15Rnd_9x19_B_P226", "", 10, "true", ""},
      { "8Rnd_45GAP_Magazine", "", 10, "true", ""},
      { "6Rnd_357M_Magazine", "", 10, "true", ""},
      { "20Rnd_556x45_UW_mag", "", 50, "true", ""},
      { "hlc_30Rnd_9x19_GD_MP5", "", 50, "true", ""},
      { "hlc_30Rnd_9x19_B_MP5", "", 100, "true", ""},
      { "hlc_30Rnd_10mm_JHP_MP5", "", 100, "true", ""},
      { "hlc_30rnd_556x45_EPR", "", 100, "true", ""},
      { "hlc_30rnd_556x45_SPR", "", 100, "call life_coplevel >= 4 && call life_copdept in [6,7,8]", ""},
      { "30Rnd_556x45_Stanag", "", 100, "true", ""},
      { "hlc_30rnd_556x45_SOST", "", 100, "true", ""},
      { "hlc_30Rnd_556x45_B_AUG", "", 100, "true", ""},
      { "hlc_30rnd_68x43_FMJ", "", 110, "call life_copdept in [6,7,8]", ""},
      { "29rnd_300BLK_STANAG", "", 110, "call life_copdept in [6,7,8]", ""},
      { "FHQ_25Rnd_762x51_Mag", "", 110, "call life_copdept in [6,7,8]", ""},
      { "FHQ_rem_30Rnd_680x43_ACR", "", 110, "call life_copdept in [6,7,8]", ""},
      { "hlc_5rnd_300WM_mk248_AWM", "", 110, "call life_copdept in [6,7,8]", ""},
      { "hlc_30rnd_556x45_SPR_sg550", "", 110, "call life_copdept in [6,7,8]", ""},
      { "hlc_10Rnd_762x51_mk316_fal", "", 100, "call life_copdept in [6,7,8]", ""},
      { "UGL_FlareCIR_F", "", 100, "call life_copdept in [6,7,8]", ""},
      { "UGL_FlareYellow_F", "", 100, "call life_copdept in [6,7,8]", ""},
      { "UGL_FlareRed_F", "", 100, "call life_copdept in [6,7,8]", ""},
      { "UGL_FlareWhite_F", "", 100, "call life_copdept in [6,7,8]", ""},
      { "UGL_FlareGreen_F", "", 100, "call life_copdept in [6,7,8]", ""},
      { "1Rnd_SmokeGreen_Grenade_shell", "", 100, "call life_copdept in [6,7,8]", ""},
      { "1Rnd_SmokeBlue_Grenade_shell", "", 100, "call life_copdept in [6,7,8]", ""},
      { "1Rnd_SmokeRed_Grenade_shell", "", 100, "call life_copdept in [6,7,8]", ""},
      { "29rnd_300BLK_STANAG", "", 100, "call life_copdept in [6,7,8]", ""},
      { "Titan_AA", "This will drain the helis fuel when rocket hits.", 1000, "call life_copdept in [5,7,8]", "Fuel Rocket"},

      //DTU
      { "KA_machete_blade", "", 40, "call life_copdept in [6,7,8]", ""},
	  { "KA_dagger_blade", "", 40, "call life_copdept in [6,7,8]", ""},
	  { "KA_axe_blade", "", 40, "call life_copdept in [6,7,8]", ""},
	  { "KA_knife_blade", "", 40, "call life_copdept in [6,7,8]", ""},
      { "RH_10Rnd_22LR_mk2", "", 40, "call life_copdept in [6,7,8]", ""},
      { "RH_6Rnd_45ACP_Mag", "", 40, "call life_copdept in [6,7,8]", ""},
      { "RH_30Rnd_9x19_UZI", "", 100, "call life_copdept in [6,7,8]", ""},
      { "RH_18Rnd_9x19_VP", "", 100, "call life_copdept in [6,7,8]", ""},
      { "RH_6Rnd_454_Mag", "", 100, "call life_copdept in [6,7,8]", ""},
      { "KA_30rnd_7N6M_FMJ_HSC_mag", "", 100, "call life_copdept in [6,7,8]", ""},
      { "KA_25Rnd_45ACP_Tracer_Red_Mag", "", 100, "call life_copdept in [6,7,8]", ""},
      { "7Rndx2_KSG_buck_mag", "", 500, "call life_copdept in [6,7,8]", ""},
      { "hlc_30rnd_556x45_EPR", "", 100, "call life_copdept in [6,7,8]", ""},
      { "30Rnd_545x39_Mag_F", "", 100, "call life_copdept in [6,7,8]", ""},
      { "30Rnd_580x42_Mag_F", "", 100, "call life_copdept in [6,7,8]", ""},
      { "hlc_30Rnd_545x39_t_ak", "", 100, "call life_copdept in [6,7,8]", ""},
      { "FHQ_35Rnd_556x45_Mag", "", 100, "call life_copdept in [6,7,8]", ""},
      { "hlc_30Rnd_545x39_B_AK", "", 100, "call life_copdept in [6,7,8]", ""}
    };

    items[] = {
      {"Binocular", "Use these to see stuff at furthur distances", 250, "call life_coplevel >= 1", ""},
      {"Rangefinder", "Use these to see stuff at furthur distances", 250, "call life_coplevel >= 5 && call life_copdept in [6,7,8]", ""},
      {"ItemGPS", "Use this to not get lost", 500, "call life_coplevel >= 1", ""},
      {"ItemMap", "Use this to find the local shops", 10, "call life_coplevel >= 1", ""},
      {"ItemCompass", "Use this to find directions", 10, "call life_coplevel >= 1", ""},
      {"RoleplayRadio", "Use this to communicate from distance", 15, "call life_coplevel >= 1", ""},
      {"B_UavTerminal", "Use this to stalk criminals", 15, "call life_coplevel >= 1", ""}
    };

    attachments[] = {
      { "RH_cmore", "", 200, "true", ""},
      { "RH_eotech553", "", 200, "true", ""},
      { "KA_red", "", 200, "true", ""},
      { "RH_barska_rds", "", 200, "true", ""},
      { "SMA_BARSKA", "", 200, "true", ""},
      { "RH_ta31rmr", "", 200, "true", ""},
      { "SMA_ELCAN_SPECTER_RDS", "", 200, "true", ""},
      { "acc_flashlight", "", 200, "true", ""},
      { "optic_Hamr", "", 50, "true", ""},
      { "optic_MRCO", "", 50, "true", ""},
      { "optic_Arco_blk_F", "", 50, "true", ""},
      { "optic_ERCO_blk_F", "", 50, "true", ""},
      { "optic_MRD", "", 50, "true", ""},
      { "HLC_optic228_ATT", "", 20, "true", ""},
      { "HLC_optic228_VTAC", "", 20, "true", ""},
      { "HLC_Optic_Romeo1_RX", "", 50, "true", ""},
      { "HLC_optic228_stavenhagen", "", 50, "true", ""},
      { "hlc_optic_ZF95_3011", "", 50, "true", ""},
      { "acc_flashlight", "", 50, "true", ""},
      { "RH_ta31rmr_2D", "", 100, "call life_coplevel >= 3 && call life_copdept in [6,7,8]", ""},
      { "KA_red", "", 100, "call life_coplevel >= 3 && call life_copdept in [6,7,8]", ""},
      { "KA_FNP45_shield2", "", 100, "call life_coplevel >= 3 && call life_copdept in [6,7,8]", ""},
      { "RH_ta648", "", 100, "call life_coplevel >= 3 && call life_copdept in [6,7,8]", ""},
      { "SMA_SFPEQ_M4TOP_BLK", "", 100, "call life_coplevel >= 3 && call life_copdept in [6,7,8]", ""},
      { "hlc_optic_LeupoldM3A_3011", "", 100, "call life_coplevel >= 5 && call life_copdept in [7,8]", ""},
      { "optic_LRPS", "", 100, "call life_coplevel >= 5 && call life_copdept in [6,7,8]", ""}
    };
  };

  class gun {
    name = "Metropolis Firearms";
    conditions = "license_civ_gun || call life_copdept in [6,7,8]";
    side = "civ";
    weapons[] = {
      { "hlc_Pistol_M11", "", 13200, "true", ""},
      { "hlc_pistol_Mk25", "", 13600, "true", ""},
      { "hlc_pistol_P226WestGerman", "", 12800, "true", ""},
      { "hlc_Pistol_P228", "", 13500, "true", ""},
      { "hlc_Pistol_M11A1", "", 13400, "true", ""},
      { "hlc_Pistol_M11A1D", "", 13400, "true", ""},
      { "hlc_pistol_Mk25D", "", 13600, "true", ""},
      { "hlc_pistol_Mk25TR", "", 13600, "true", ""},
      { "hlc_pistol_P226R_357Combat", "", 13000, "true", ""},
      { "hlc_pistol_P226R_40Combat", "", 13000, "true", ""},
      { "hgun_Pistol_heavy_01_F", "", 13200, "true", ""},
      { "hgun_Rook40_F", "", 12600, "true", ""},
      { "hlc_rifle_FN3011", "", 95000, "true", ""},
      { "hlc_rifle_FN3011_WDL", "", 95000, "true", ""},
      { "hlc_rifle_M1903A1", "", 95000, "true", ""},
      { "RH_m9", "", 13100, "true", ""},
      { "RH_m9c", "", 13100, "true", ""},
      { "KA_Px4", "", 13500, "true", ""},
      { "KA_Px4_Black", "", 13500, "true", ""},
      { "RH_python", "", 24800, "true", ""},
      { "RH_Deagleg", "", 50000, "true", ""},
      { "RH_Deaglem", "", 50000, "true", ""},
      { "RH_Deagles", "", 50000, "true", ""},
      { "RH_fn57", "", 13500, "true", ""},
      { "RH_fn57_t", "", 13500, "true", ""},
      { "RH_g17", "", 13600, "true", ""},
      { "RH_g19", "", 13900, "true", ""},
      { "KA_Glock_17_Single", "", 13600, "true", ""},
      { "KA_Glock_18_Single", "", 14000, "true", ""},
      { "RH_gsh18", "", 13600, "true", ""},
      { "RH_kimber", "", 13700, "true", ""},
      { "RH_m1911", "", 12100, "true", ""},
      { "RH_mak", "", 13500, "true", ""},
      { "RH_mp412", "", 13500, "true", ""},
      { "arifle_KA_SKS_F", "", 95000, "true", ""},
      { "KA_crossbow_black", "", 25000, "true", ""}
    };

    magazines[] = {
      { "hlc_12Rnd_357SIG_B_P226", "", 40, "true", ""},
      { "hlc_12Rnd_40SW_B_P226", "", 40, "true", ""},
      { "hlc_13Rnd_9x19_B_P228", "", 30, "true", ""},
      { "hlc_15Rnd_9x19_B_P226", "", 40, "true", ""},
      { "8Rnd_45GAP_Magazine", "", 50, "true", ""},
      { "6Rnd_357M_Magazine", "", 100, "true", ""},
      { "hlc_30rnd_556x45_EPR", "", 30, "true", ""},
      { "11Rnd_45ACP_Mag", "", 30, "true", ""},
      { "16Rnd_9x21_Mag", "", 30, "true", ""},
      { "hlc_5rnd_3006_1903", "", 50, "true", ""},
      { "RH_15Rnd_9x19_M9", "", 40, "true", ""},
      { "KA_Px4_17Rnd_9x19_FMJ_Mag", "", 40, "true", ""},
      { "RH_6Rnd_357_Mag", "", 40, "true", ""},
      { "RH_7Rnd_50_AE", "", 40, "true", ""},
      { "RH_20Rnd_57x28_FN", "", 40, "true", ""},
      { "RH_17Rnd_9x19_g17", "", 40, "true", ""},
      { "KA_17Rnd_9x19_Mag", "", 40, "true", ""},
      { "RH_18Rnd_9x19_gsh", "", 40, "true", ""},
      { "RH_7Rnd_45cal_m1911", "", 40, "true", ""},
      { "RH_8Rnd_9x18_Mak", "", 40, "true", ""},
      { "RH_6Rnd_357_Mag", "", 40, "true", ""},
      { "10Rnd_M43_762x39_Ball", "", 100, "true", ""},
      { "KA_arrow_mag", "", 40, "true", ""},
      { "hlc_10Rnd_762x51_B_fal", "", 100, "true", ""}
    };

    attachments[] = {
      { "optic_Yorris", "", 50, "true", ""},
	  { "optic_Aco_smg", "", 50, "true", ""},
      { "optic_MRD", "", 50, "true", ""},
      { "HLC_optic228_ATT", "", 20, "true", ""},
      { "HLC_optic228_VTAC", "", 20, "true", ""},
      { "HLC_Optic_Romeo1_RX", "", 50, "true", ""},
      { "HLC_optic228_stavenhagen", "", 50, "true", ""},
      { "hlc_optic_ANGSCHUTZ", "", 20, "true", ""},
      { "hlc_optic_ZF95_3011", "", 400, "true", ""},
      { "hlc_optic_FNSTANAG2D", "", 200, "true", ""}
    };
    items[] = {
  		{ "RoleplayRadio", "Use this to communicate from distance", 150, "true", ""},
  		{ "Binocular", "Use these to see stuff at furthur distances", 250, "true", ""},
  		{ "ItemGPS", "Use this to not get lost", 500, "true", ""},
  		{ "ItemMap", "Use this to find the local shops", 10, "true", ""},
      { "ItemCompass", "Use this to control drones", 10, "true", ""}
   	};
  };

  class jail {
    name = "Jail Firearms";
    conditions = "life_is_arrested";
    side = "civ";
    weapons[] = {
      { "KA_knife", "", 3000, "true", ""},
      { "hgun_Pistol_heavy_01_F", "", 6000, "true", ""},
      { "hgun_Rook40_F", "", 7000, "true", ""}
    };

    magazines[] = {
      { "KA_knife_blade", "", 500, "true", ""},
      { "11Rnd_45ACP_Mag", "", 500, "true", ""},
      { "16Rnd_9x21_Mag", "", 750, "true", ""}
    };

    attachments[] = {
      { "optic_Yorris", "", 50, "true", ""},
      { "optic_MRD", "", 50, "true", ""},
      { "HLC_optic228_ATT", "", 20, "true", ""},
      { "HLC_optic228_VTAC", "", 20, "true", ""},
      { "HLC_Optic_Romeo1_RX", "", 50, "true", ""},
      { "HLC_optic228_stavenhagen", "", 50, "true", ""}
    };
    items[] = {
      { "RoleplayRadio", "Use this to talk to others out of jail", 250, "true", ""},
      { "Binocular", "Use these to see cops at furthur distances", 250, "true", ""},
      { "ItemGPS", "Let others find you if you are in a gang", 750, "true", ""},
      { "ItemMap", "Use this to find your way out", 100, "true", ""}
    };
  };

  class rebel {
    name = "rebel";
    conditions = "(missionNamespace getVariable ['mav_ttm_var_rebel',0]) isEqualTo 1";
    side = "civ";
    weapons[] = {
      { "KA_machete", "", 15000, "true", ""},
      { "KA_dagger", "", 15000, "true", ""},
      { "KA_axe", "", 15000, "true", ""},
      { "KA_knife", "", 15000, "true", ""},
      { "hlc_smg_mp5k", "", 55000, "true", ""},
      { "arifle_AKS_F", "", 55000, "true", ""},
      { "hlc_rifle_CQBR", "", 51000, "true", ""},
  	  { "hlc_rifle_RPK12", "", 67500, "true", ""},
  	  { "hlc_smg_mp510", "", 67500, "true", ""},
      { "arifle_CTAR_hex_F", "", 67500, "true", ""},
      { "hlc_rifle_RU556", "", 81000, "true", ""},
      { "hlc_rifle_aek971_mtk", "", 89000, "true", ""},
      { "hlc_rifle_ACR_SBR_tan", "", 85000, "true", ""},
      { "hlc_rifle_SG553LB_RIS", "", 85000, "true", ""},
      { "hlc_rifle_mk18mod0", "", 85000, "true", ""},
      { "hlc_rifle_SAMR", "", 85000, "true", ""},
      { "arifle_SPAR_01_blk_F", "", 91000, "true", ""},
      { "hlc_rifle_ak74", "", 61000, "true", ""},
      { "hlc_rifle_rpk74n", "", 61000, "true", ""},
      { "hlc_rifle_ak12", "", 61000, "true", ""},
      { "hlc_rifle_ACR_full_black", "", 77000, "true", ""},
      { "RH_mk2", "", 19000, "true", ""},
      { "KICKASS_Sawed_Off_Shotgun", "", 19000, "true", ""},
      { "RH_ttracker_g", "", 19000, "true", ""},
      { "RH_muzi", "", 35000, "true", ""},
      { "RH_vp70", "", 35000, "true", ""},
      { "RH_bullb", "", 22000, "true", ""},
      { "AN94_MTK83", "", 67500, "true", ""},
      { "RH_SAMR", "", 90000, "true", ""},
      { "RH_M4sbr_b", "", 67500, "true", ""},
      { "KA_UMP45", "", 67500, "true", ""},
      { "RH_Hk416s", "", 90000, "true", ""},
      { "RH_m4", "", 90000, "true", ""}
    };

    magazines[] = {
      { "KA_machete_blade", "", 80, "true", ""},
      { "KA_dagger_blade", "", 80, "true", ""},
	  { "KA_axe_blade", "", 80, "true", ""},
	  { "KA_knife_blade", "", 80, "true", ""},
      { "RH_10Rnd_22LR_mk2", "", 80, "true", ""},
      { "KICKASS_2Rnd_Sawed_Off_Shotgun_Pellets", "", 80, "true", ""},
      { "RH_6Rnd_45ACP_Mag", "", 80, "true", ""},
      { "RH_30Rnd_9x19_UZI", "", 300, "true", ""},
      { "RH_18Rnd_9x19_VP", "", 300, "true", ""},
      { "RH_6Rnd_454_Mag", "", 300, "true", ""},
      { "KA_30rnd_7N6M_FMJ_HSC_mag", "", 300, "true", ""},
      { "SMA_30Rnd_556x45_Mk262", "", 300, "true", ""},
      { "KA_25Rnd_45ACP_Tracer_Red_Mag", "", 300, "true", ""},
      { "7Rndx2_KSG_buck_mag", "", 750, "true", ""},
      { "hlc_30Rnd_9x19_B_MP5", "", 300, "true", ""},
      { "hlc_30rnd_556x45_EPR", "", 300, "true", ""},
      { "30Rnd_545x39_Mag_F", "", 300, "true", ""},
      { "hlc_30Rnd_10mm_B_MP5", "", 300, "true", ""},
      { "30Rnd_556x45_Stanag", "", 300, "true", ""},
      { "30Rnd_580x42_Mag_F", "", 300, "true", ""},
      { "hlc_30Rnd_556x45_SPR_sg550", "", 300, "true", ""},
      { "hlc_30Rnd_545x39_t_ak", "", 300, "true", ""},
      { "hlc_30Rnd_545x39_B_AK", "", 300, "true", ""}
    };

    attachments[] = {
      { "optic_Arco_blk_F", "", 50, "true", ""},
      { "optic_ERCO_blk_F", "", 50, "true", ""},
      { "optic_MRCO", "", 20, "true", ""},
      { "optic_Hamr", "", 20, "true", ""},
      { "optic_SOS", "", 20000, "true", ""},
      { "bipod_03_F_blk", "", 10000, "true", ""},
      { "optic_Holosight", "", 20, "true", ""},
      { "RH_cmore", "", 200, "true", ""},
      { "RH_eotech553", "", 200, "true", ""},
      { "RH_barska_rds", "", 200, "true", ""},
      { "SMA_BARSKA", "", 200, "true", ""},
      { "RH_ta31rmr", "", 200, "true", ""},
      { "SMA_ELCAN_SPECTER_RDS", "", 200, "true", ""},
      { "acc_flashlight", "", 200, "true", ""}
    };

    items[] = {
      { "RoleplayRadio", "Use this to communicate from distance", 150, "true", ""},
      { "Binocular", "Use these to see stuff at furthur distances", 250, "true", ""},
      { "ItemGPS", "Use this to not get lost", 500, "true", ""},
      { "ItemMap", "Use this to find the local shops", 10, "true", ""},
      { "ItemCompass", "Use this to find directions", 10, "true", ""}
    };
  };

  class Advrebel {
    name = "Advanced Rebel";
    conditions = "(missionNamespace getVariable ['mav_ttm_var_advrebel',0]) isEqualTo 1";
    side = "civ";
    weapons[] = {
      { "RH_Mk12mod1", "", 150000, "true", ""},
      { "hlc_rifle_awmagnum", "", 250000, "true", ""},
      { "hlc_rifle_M14", "", 225000, "true", ""},
      { "RH_M4A6", "", 175000, "true", ""},
      { "hlc_rifle_ak47", "", 150000, "true", ""},
      { "hlc_rifle_rpk74n", "", 90000, "true", ""},
      { "RH_M16A6", "", 175000, "true", ""},
      { "hlc_rifle_honeybadger", "", 200000, "true", ""},
      { "hlc_rifle_M14dmr_Rail", "", 200000, "true", ""},
      { "hlc_rifle_SG550Sniper_RIS", "", 250000, "true", ""}
    };

    magazines[] = {
      { "RH_30Rnd_68x43_FMJ", "", 500, "true", ""},
      { "hlc_5rnd_300WM_FMJ_AWM", "", 500, "true", ""},
      { "hlc_60Rnd_545x39_t_rpk", "", 600, "true", ""},
      { "hlc_30Rnd_762x39_b_ak", "", 200, "true", ""},
      { "FHQ_rem_30Rnd_680x43_ACR", "", 500, "true", ""},
      { "hlc_30Rnd_556x45_SOST_sg550", "", 500, "true", ""},
      { "RH_30Rnd_556x45_Mk262", "", 500, "true", ""},
      { "hlc_20Rnd_762x51_barrier_M14", "", 500, "true", ""},
	    { "hlc_20Rnd_762x51_B_M14", "", 500, "true", ""},
      { "29rnd_300BLK_STANAG_S", "", 500, "true", ""}
    };

    attachments[] = {
      { "optic_SOS", "", 20000, "true", ""},
	  { "hlc_optic_kobra", "", 500, "true", ""},
      { "RH_ta31rmr_2D", "", 20000, "true", ""},
      { "RH_ta648", "", 20000, "true", ""},
      { "SMA_SFPEQ_M4TOP_BLK", "", 20000, "true", ""}
    };

    items[] = {
      { "RoleplayRadio", "Use this to communicate from distance", 150, "true", ""},
      { "Binocular", "Use these to see stuff at furthur distances", 250, "true", ""},
      { "ItemGPS", "Use this to not get lost", 500, "true", ""},
      { "ItemMap", "Use this to find the local shops", 10, "true", ""},
      { "ItemCompass", "Use this to find directions", 10, "true", ""}
    };
  };

  class genstore {
    name = "Metropolis General Store";
    conditions = "";
    side = "civ";
    weapons[] = {
      { "TR8_Mining_Drill", "Used to mine more ore", 1000, "true", ""},
      { "Mr_Camera_News", "Used to record the news.", 1000, "true", ""},
      { "Mr_Micro_News", "Used to record audio.", 1000, "true", ""}
    };

    magazines[] = {
      { "10_TR8_Drill_Fuel", "Fuel for the drill", 100, "true", ""}
    };

    items[] = {
      { "RoleplayRadio", "Use this to communicate from distance", 150, "true", ""},
      { "Binocular", "Use these to see stuff at furthur distances", 250, "true", ""},
      { "ItemGPS", "Use this to not get lost", 500, "true", ""},
      { "ItemMap", "Use this to find the local shops", 10, "true", ""},
      { "ItemCompass", "Use this to find directions", 10, "true", ""}
    };
  };

  class f_station_store {
    name = "Metropolis Fuel Station Store";
    conditions = "";
    side = "civ";
    items[] = {
      { "RoleplayRadio", "Use this to communicate from distance", 150, "true", ""},
      { "Binocular", "Use these to see stuff at furthur distances", 250, "true", ""},
      { "ItemGPS", "Use this to not get lost", 500, "true", ""},
      { "ItemMap", "Use this to find the local shops", 10, "true", ""},
      { "ItemCompass", "Use this to find directions", 10, "true", ""}
    };
  };

  class med_basic {
    name = "Medic Shop";
    conditions = "call life_medicLevel >= 1";
    side = "med";
    items[] = {
	  { "KA_TL_122_flashlight", "Use this to communicate from distance", 50, "call(life_medicLevel) >= 1", ""},
      { "RoleplayRadio", "Use this to communicate from distance", 50, "call(life_medicLevel) >= 1", ""},
      { "Medikit", "Use this to heal to full health", 50, "call(life_medicLevel) >= 1", ""},
      { "FirstAidKit", "Use this to heal players", 50, "call(life_medicLevel) >= 1", ""},
      { "Binocular", "Use this to communicate from distance", 50, "call(life_medicLevel) >= 1", ""},
      { "ItemGPS", "Use this to not get lost", 50, "call(life_medicLevel) >= 1", ""},
      { "ItemMap", "Use this to find the local shops", 10, "call(life_medicLevel) >= 1", ""},
      { "ItemCompass", "Use this to find directions", 10, "call(life_medicLevel) >= 1", ""}
    };
  };
};
