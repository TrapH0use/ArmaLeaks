class life_earth_menu {
	idd = -1;
	name= "life_earth_menu";
	movingEnable = false;
	enableSimulation = true;
	onLoad = "[] spawn fnc_kearth;";
};

class life_call_menu {
	idd = -1;
	name= "life_call_menu";
	movingEnable = false;
	enableSimulation = true;
	onLoad = "closedialog 0;";
};