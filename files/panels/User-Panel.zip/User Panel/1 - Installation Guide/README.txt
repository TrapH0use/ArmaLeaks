FR
Les guides sont disponibles à cette addresse : https://www.the-programmer.com/download/product.php?id=55159

EN
The guide are available at this URL: https://www.the-programmer.com/download/product.php?id=55159