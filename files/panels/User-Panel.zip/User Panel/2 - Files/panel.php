<!--
    Author: Thomas Croizet "Steez"
    Teamspeak 3: ts.the-programmer.com
    Web site: www.the-programmer.com

    Terms of use:
      - This file is forbidden unless you have permission from the author. If you have this file without permission to use it please do not use it and do not share it.
      - If you have permission to use this file, you can use it on your server however it is strictly forbidden to share it.
      - Out of respect for the author please do not delete this information.
-->

<?php
// *** -------------------- (Please do not touch these lines) -------------------- ***
require 'config/constant.php';
require "app/pdo.php";
require "app/Parser/beautifier.php";
session_start();

if (!is_dir('news')) {
	mkdir('news', 0777);
	chmod('news', 0777);
}
if (!is_dir('guide')) {
	mkdir('guide', 0777);
	chmod('guide', 0777);
}
if (!is_dir('gallery')) {
	mkdir('gallery', 0777);
	chmod('gallery', 0777);
}

if (isset($_GET['steamId']))
{
	// Set the cookie and rediect automaticly the user
	setCookie('steamId', $_GET['steamId'], (time() + 60 * 60 * 24 * 30), '/', $_SERVER['HTTP_HOST'], false, true);
	header("Location: panel.php");
	exit;
}

// If the cookie steamId is not set
if (!isset($_COOKIE['steamId']))
	header('Location: index.php');

// Set the steamId session variable
$_SESSION['steamId'] = $_COOKIE['steamId'];

// Reset the cookie
setCookie('steamId', $_SESSION['steamId'], (time() + 60 * 60 * 24 * 30), '/', $_SERVER['HTTP_HOST'], false, true);
// *** --------------------------------------------------------------------------- ***
?>

<!DOCTYPE html>
<html lang="fr">
	<head>
		<title><?= $generic_namePanel ?> - <?= $navbar_homePage ?></title>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="Example of a description">
		<meta name="keywords" content="user, panel, theprogrammer">
		<meta name="author" content="The Programmer">
		<meta name="twitter:site" content="User Panel">
		<meta name="twitter:title" content="User Panel">
		<meta name="twitter:description" content="Example of a description">
		<meta name="twitter:creator" content="The Programmer">
		<meta property="og:title" content="User Panel"/>
		<meta property="og:type" content="Web site"/>
		<meta property="og:url" content="https://example-userpanel.com"/>
		<meta property="og:description" content="Example of a description"/>
		<meta property="og:site_name" content="User Panel"/>
		<meta name="robots" content="index, follow"/>
		<meta name="reply-to" content="example@userpanel.com">
		<meta name="copyright" content="The Programmer">

		<link rel="stylesheet" href="css/panel.css?<?= time() ?>">
		<?php include 'include/header.php'; ?>
	</head>

    <body>
        <!-- ** NAVBAR ** -->
		<?php include 'include/navbar.php'; ?>
		<!-- ** END - NAVBAR ** -->

		<!-- ** MAIN ** -->
		<main class="container animated fadeIn">
			<article id="homePage" class="information-container ql-editor p-3 p-0 mt-4 mb-4" style="height: auto;">
				<?php
					// *** -------------------- (Please do not touch these lines) -------------------- ***
					if (file_exists('homePage.html')) {
						echo trim(file_get_contents('homePage.html'), ' \t');
					}
					// *** --------------------------------------------------------------------------- ***
				?>
			</article>

			<hr>

			<?php
				// *** -------------------- (Please do not touch these lines) -------------------- ***
				// Get the last news
				$path = 'news';
				$news = scandir($path);
				sort($news,  SORT_NATURAL);
				$news = array_reverse($news);
				$newsCount = count($news);

				for ($i = 0; $i < $constPanelMaxLastNewsShowHome; $i++)
				{
					if (!in_array($news[$i], ['.', '..']))
					{
						// Read the XML
						$newsXml = new SimpleXMLElement(file_get_contents("$path/".pathinfo($news[$i])['filename'].'.xml'));
						// Get the news information
						$newsName = $newsXml->newsName;
						$newsTagName = $constNewsTag[strval($newsXml->newsTag)][0];
						$newsTagColor = $constNewsTag[strval($newsXml->newsTag)][1];
						$newsIcon = '';
						if (isset($constNewsTag[strval($newsXml->newsTag)][2]))
							$newsIcon = $constNewsTag[strval($newsXml->newsTag)][2];
						$newsContent = ($newsXml->newsContent);
						$date = date("d/m/Y $generic_dateAt G:i", filemtime("$path/$news[$i]"));

						echo ($i == 0) ? "<article class=\"news-preview mb-4\" onclick=\"request_news('$news[$i]')\"><div class=\"row news-preview-title m-0\"><div class=\"col-12 col-sm-6 p-0\"><h3 class=\"display-4 mb-2\">$newsName</h3><span style=\"background: $newsTagColor\" class=\"p-1 news-tag\"><i class=\"icon-$newsIcon mr-1\"></i>$newsTagName</span></div><div class=\"col-12 col-sm-6 p-0\"><p class=\"news-modification-text\">$general_lastModification $date</p></div></div><div class=\"news-preview-content\"><p class=\"lead mb-0\"><div class=\"ql-editor news-preview-content-text p-0\">$newsContent</p></div></p></div></article>" : 
										 "<article class=\"news-preview mb-4\" onclick=\"request_news('$news[$i]')\"><div class=\"row news-preview-title m-0\"><div class=\"col-12 col-sm-6 p-0\"><h3 class=\"display-4 mb-2\">$newsName</h3><span style=\"background: $newsTagColor\" class=\"p-1 news-tag\"><i class=\"icon-$newsIcon mr-1\"></i>$newsTagName</span></div><div class=\"col-12 col-sm-6 p-0\"><p class=\"news-modification-text\">$general_lastModification $date</p></div></div><div class=\"news-preview-content\"><p class=\"lead mb-0\"><div class=\"ql-editor news-preview-content-text p-0\">$newsContent</p></div></p></div></article>";
					}
				}
				// *** --------------------------------------------------------------------------- ***
            ?>
		</main>
		<!-- ** END - MAIN ** -->

		<!-- ** FOOTER ** -->
		<?php include 'include/footer.php'; ?>
        <!-- ** END - FOOTER ** -->

		<script>
			const request_news = (newsFileName) => {
                document.location.href = `news.php?news=${newsFileName}`;
            }

			function clean(node)
			{
				for (var i = 0; i < node.childNodes.length; i++)
				{
					var child = node.childNodes[i];

					if (child.nodeType === 8 || (child.nodeType === 3 && !/\S/.test(child.nodeValue))) {
						node.removeChild(child);
						i--;
					}
					else if (child.nodeType === 1)
						clean(child);
				}
			}

			clean(document.getElementById('homePage'));
		</script>
    </body>
</html>