<!--
    Author: Thomas Croizet "Steez"
    Teamspeak 3: ts.the-programmer.com
    Web site: www.the-programmer.com

    Terms of use:
      - This file is forbidden unless you have permission from the author. If you have this file without permission to use it please do not use it and do not share it.
      - If you have permission to use this file, you can use it on your server however it is strictly forbidden to share it.
      - Out of respect for the author please do not delete this information.
-->

<?php
// *** -------------------- (Please do not touch these lines) -------------------- ***
require 'config/constant.php';
require "app/pdo.php";
require "app/Parser/beautifier.php";
session_start();

if (isset($_GET['steamId']))
{
	// Set the cookie and rediect automaticly the user
	setCookie('steamId', $_GET['steamId'], (time() + 60 * 60 * 24 * 30), '/', $_SERVER['HTTP_HOST'], false, true);
	header("Location: news.php");
	exit;
}

// If the cookie steamId is not set
if (!isset($_COOKIE['steamId']))
	header('Location: index.php');

// Set the steamId session variable
$_SESSION['steamId'] = $_COOKIE['steamId'];

// Reset the cookie
setCookie('steamId', $_SESSION['steamId'], (time() + 60 * 60 * 24 * 30), '/', $_SERVER['HTTP_HOST'], false, true);
// *** --------------------------------------------------------------------------- ***
?>

<!DOCTYPE html>
<html lang="fr">
	<head>
		<title><?= $generic_namePanel ?> - <?= $navbar_guide ?></title>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="Example of a description">
		<meta name="keywords" content="user, panel, theprogrammer">
		<meta name="author" content="The Programmer">
		<meta name="twitter:site" content="User Panel">
		<meta name="twitter:title" content="User Panel">
		<meta name="twitter:description" content="Example of a description">
		<meta name="twitter:creator" content="The Programmer">
		<meta property="og:title" content="User Panel"/>
		<meta property="og:type" content="Web site"/>
		<meta property="og:url" content="https://example-userpanel.com"/>
		<meta property="og:description" content="Example of a description"/>
		<meta property="og:site_name" content="User Panel"/>
		<meta name="robots" content="index, follow"/>
		<meta name="reply-to" content="example@userpanel.com">
		<meta name="copyright" content="The Programmer">

		<link rel="stylesheet" href="css/panel.css?<?= time() ?>">
		<?php include 'include/header.php'; ?>
	</head>

    <body>
        <!-- ** NAVBAR ** -->
		<?php include 'include/navbar.php'; ?>
		<!-- ** END - NAVBAR ** -->

		<!-- ** MAIN ** -->
		<!-- -------------------- (Please do not touch these lines) -------------------- -->
		<?php if (isset($_GET['guideClassName'], $_GET['guideFileName'])): ?>

		<main class="container-fluid animated fadeIn mt-4">
			<div class="row">
				<div class="col-12 col-md-3 col-xl-2 guide-sidebar mb-4">
					<article class="news-container">
						<div>
							<p class="lead mb-3"><?= $guide_guideList ?></p>
						</div>

						<hr>

						<nav class="guide-links collapse">
							<?php
							// Get all the guide
							$path = 'guide';
							$guideCategories = scandir($path);
							$guideCategories = array_splice($guideCategories, 2);
							$guideCategoriesCount = count($guideCategories);
			
							// Show the guide categorie
							for ($i = 0; $i < $guideCategoriesCount; $i++) {

								// Get the guide in the guide category
								$guidesInCategory = scandir($path.'/'.$guideCategories[$i]);
								$guidesInCategory = array_splice($guidesInCategory, 2);
								$guidesInCategoryCount = count($guidesInCategory);
								$urlToDisplays = '';

								// echo the guide
								echo "<div class=\"mb-3\"><p class=\"mb-1\">$guideCategories[$i]</p>";
			
								for ($j = 0; $j < $guidesInCategoryCount; $j++) 
								{
									// Display all the guide
									$guideXml = new SimpleXMLElement(file_get_contents($path.'/'.$guideCategories[$i].'/'.$guidesInCategory[$j]));
									$guideName = strval($guideXml->guideName);
									$urlToDisplays .= ($j == 0) ? "<p class=\"mb-0\"><a class=\"link\" href=\"guide.php?guideClassName=$guideCategories[$i]&guideFileName=$guidesInCategory[$j]\">$guideName</a></p>" : 
																  "<p class=\"mb-0 mt-1\"><a class=\"link\" href=\"guide.php?guideClassName=$guideCategories[$i]&guideFileName=$guidesInCategory[$j]\">$guideName</a></p>";
								}

								echo $urlToDisplays.'</div>';
							}
							?>
						</nav>
					</article>
				</div>

				<?php
				// Get all the information about the guide
				$guideXml = new SimpleXMLElement(file_get_contents("guide/$_GET[guideClassName]/$_GET[guideFileName]"));
				$guideName = $guideXml->guideName;
				$guideContent = ($guideXml->guideContent);
				$date = date("d/m/Y $generic_dateAt G:i", filemtime("guide/$_GET[guideClassName]/$_GET[guideFileName]"));

				require 'app/html2text.php';
				// Parse the HTML string as HTML DOM
				$guideContentHtml = new \Html2Text\Html2Text($guideContent);
				// Get all the word in the HTML content
				$guideContentWords = explode(' ', $guideContentHtml->getText());
				// Get the number of words
				$guideContentWordsCount = count($guideContentWords);
				$timeToRead = round($guideContentWordsCount / 250);
				if ($timeToRead == 0) $timeToRead = 1;
				?>

				<div class="col-12 col-md-9 col-xl-10 mb-4">
					<article class="news-container">
						<div class="row m-0">
							<div class="col-12 col-sm-6 p-0">
								<p class="display-4 mb-2"><?= $guideName ?></p>
							</div>

							<div class="col-12 col-sm-6 p-0">
								<p class="news-modification-text"><?= $general_lastModification ?> <?= $date ?> <br> <?= $general_timeToRead ?> <?= $timeToRead ?> min</p>
							</div>
						</div>

						<hr>

						<div class="ql-editor p-0"><?= $guideContent ?></div>
					</article>
				</div>
			</div>
		</main>

		<?php else: ?>

        <main class="container animated fadeIn mt-4">
			<div class="row">
				<?php
				$path = 'guide';
				$guideCategories = scandir($path);
				$guideCategories = array_splice($guideCategories, 2);
				$guideCategoriesCount = count($guideCategories);

				for ($i = 0; $i < $guideCategoriesCount; $i++) 
				{
					// Scan the guide category
					$guidesInCategory = scandir($path.'/'.$guideCategories[$i]);
					$guidesInCategory = array_splice($guidesInCategory, 2);
					$guidesInCategoryCount = count($guidesInCategory);
					$urlToDisplays = '';

					for ($j = 0; $j < $guidesInCategoryCount; $j++) {
						$guideXml = new SimpleXMLElement(file_get_contents($path.'/'.$guideCategories[$i].'/'.$guidesInCategory[$j]));
						$guideName = strval($guideXml->guideName);
						$urlToDisplays .= ($j == 0) ? "<p class=\"lead mb-0\"><a class=\"link\" href=\"guide.php?guideClassName=$guideCategories[$i]&guideFileName=$guidesInCategory[$j]\">$guideName</a></p>" : "<p class=\"lead mb-0 mt-3\"><a class=\"link\" href=\"guide.php?guideClassName=$guideCategories[$i]&guideFileName=$guidesInCategory[$j]\">$guideName</a></p>";
					}

					echo "<article class=\"col-12 col-lg-6\"><div class=\"news-preview mb-4\"><div class=\"row news-preview-title m-0\"><h3 class=\"display-4 mb-2\"><i class=\"icon-book mr-1\"></i>$guideCategories[$i]</h3></div><div class=\"news-preview-content-noHover\">$urlToDisplays</div></div></article>";
				}
				?>
			</div>
		</main>

		<?php endif ?>
		<!-- --------------------------------------------------------------------------- -->
		<!-- ** END - MAIN ** -->

		<!-- ** FOOTER ** -->
		<?php include 'include/footer.php'; ?>
        <!-- ** END - FOOTER ** -->
    </body>
</html>