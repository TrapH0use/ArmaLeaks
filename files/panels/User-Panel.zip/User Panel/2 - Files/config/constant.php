<?php
error_reporting(E_ERROR | E_PARSE);

# PDO CONSTANTS
$constPdoSgbd = 'mysql';
$constPdoHost = '';
$constPdoUsername = '';
$constPdoPassword = '';
$constPdoDatabaseName = '';

# STEAM CONSTANTS
$constSteamApiKey = '';

# PANEL CONSTANTS
$constPanelAdminUsers = ['76561198142754886'];
$constPanelPlayerInformationDefaultCategory = 'players';
$constPanelPlayerInformationPlayerNameDefaultCategory = 'name';
$constPanelLeaderboardMaxDataShowPerCategory = 5;
$constPanelMaxLastNewsShowHome = 2;

# GALLERY CONSTANT
$constGalleryMaxImagesCanSend = 5;
$constGalleryMaxShortDescriptionLength = 32;
$constGalleryMaxLongDescriptionLength = 128;

# NEWS CONSTANT
$constNewsMaxNameLength = 64;

# LOAD LANGUAGE
// *** -------------------- (Please do not touch these lines) -------------------- ***
$lang = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2);
$acceptLang = ['fr', 'en', 'de'];
$lang = in_array($lang, $acceptLang) ? $lang : 'en';
include_once "config/$lang.php";
// *** --------------------------------------------------------------------------- ***

$constNewsTag = ['misc' => [$generic_misc, '#32a852', 'info'], 'important' => [$generic_important, '#a83232', 'alert-circle'], 'update' => [$generic_update, '#3277a8', 'download'], 'event' => [$generic_event, '#9a32a8', 'bookmark']];

# USEFUL INFORMATION CONSTANT
$constForumUrl = '';
$constInformationIpServer = '';
$constInformationPortServer = '';
$constInformationPasswordServer = '';
$constInformationNameServer = '';
$constInformationTeamspeakAddress = '';
$constInformationDiscordAddress = '';
$constInformationFacebookPage = '';
$constInformationTwitterAccount = '';
$constInformationYoutubeAccount = '';
$constInformationTwitchAccount = '';
$constInformationLauncherPath = '';
$constInformationTaskforceTeamspeakPath = '';