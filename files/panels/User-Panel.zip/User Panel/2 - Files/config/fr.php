<?php
$generic_namePanel = 'User Panel';
$generic_allRightReserved = '© '.date('Y').'. All rights reserved';
$generic_welcomeLoginMessage = 'Bienvenue sur notre panel joueur pour notre communauté.';
$generic_login = 'Connexion';
$generic_dateAt = '\à';
$generic_findData = 'Chercher une donnée';
$generic_findTag = 'Filtrer par tag';
$generic_update = 'Mise à jour';
$generic_event = 'Evénèment';
$generic_important = 'Important';
$generic_misc = 'Divers';
$general_timeToRead = 'Temps de lecture :';
$general_lastModification = 'Dernière modification :';
$general_all = 'Tous';


$navbar_playerInformation = 'Informations joueurs';
$navbar_homePage = 'Page d\'accueil';
$navbar_gallery = 'Galerie';
$navbar_news = 'Annonces';
$navbar_guide = 'Guides';
$navbar_leaderboard = 'Leaderboard';
$navbar_usefulInformation = 'Informations utiles';
$navbar_disconnect = 'Déconnexion';
$navbar_admin = 'Admin';
$navbar_forum = 'Forum';


$adminModal_adminTools = 'Outils admin';
$adminModal_pageIntentionalyBlank = 'Cette page est volontairement blanche';
$adminModal_internalError = 'Erreur interne';

$adminModal_homePage_setHomePage = 'Mettre à jour la page d\'accueil';
$adminModal_homePage_homePageUploaded = 'La page d\'accueil a été téléversé';

$adminModal_chooseFile = 'Choisir un fichier';
$adminModal_gallery_uploadImage = 'Téléverser une image';
$adminModal_gallery_imageFileType = "Doit être un .jpg, .png ou un .gif, maximum $constGalleryMaxImagesCanSend images";
$adminModal_gallery_shortDescriptionPlaceholder = 'Courte description à afficher';
$adminModal_gallery_maxShortDescriptionLength = "Maximum $constGalleryMaxShortDescriptionLength caractères";
$adminModal_gallery_longDescriptionPlaceholder = 'Longue description à afficher';
$adminModal_gallery_maxLongDescriptionLength = "Maximum $constGalleryMaxLongDescriptionLength caractères";
$adminModal_gallery_deleteImages = 'Supprimer des images';
$adminModal_gallery_imageUploaded = 'L\'image a été téléversée';
$adminModal_gallery_imageRemoved = 'L\'image a été supprimée';
$adminModal_gallery_removedImageAsk = 'Voulez-vous supprimé l\'image ${imageName} ? Il n\'a aucun moyen de revenir en arrière';

$adminModal_news_writeNews = 'Ecrire une annonce';
$adminModal_news_chooseNews = 'Choisir une annonce à modifier';
$adminModal_news_chooseNewsTag = 'Choisir un tag';
$adminModal_news_newsName = 'Nom de l\'annonce';
$adminModal_news_maxNewsNameLength = "Maximum $constNewsMaxNameLength characters";
$adminModal_news_uploadNews = 'Téléverser l\'annonce';
$adminModal_news_deleteNews = 'Supprimer une annonce';
$adminModal_news_newsUploaded = 'L\'annonce a été téléversée';
$adminModal_news_newsRemoved = 'L\'annonce a été supprimée';
$adminModal_news_removedNewsAsk = 'Voulez-vous supprimé l\'annonce ${newsName} ? Il n\'a aucun moyen de revenir en arrière.';
$adminModal_news_loadNewsAsk = 'Voulez-vous charger l\'annonce ${newsName} ? Votre travail sera sauvegardé.';


$adminModal_guide_createGuideClass = 'Créer une catégorie de guide';
$adminModal_guide_guideClassName = 'Nom de la catégorie';
$adminModal_guide_createGuideClassName = 'Créer la catégorie';
$adminModal_guide_guideClassNameCreated = 'Catégorie créée';
$adminModal_guide_guideClassNameNotCreated = 'La catégorie existe déjà';
$adminModal_guide_deleteGuideClass = 'Supprimer une catégorie de guide';
$adminModal_guide_deleteGuideClassName = 'Supprimer la catégorie';
$adminModal_guide_guideClassNameDeleted = 'Catégorie supprimée';
$adminModal_guide_category = 'Catégorie';
$adminModal_guide_deleteGuideClassNameAsk = 'Voulez-vous supprimer la catégorie ${guideClassName} ? Tous les guides présent seront supprimés. Il n\'a aucun moyen de revenir en arrière';
$adminModal_guide_writeGuide = 'Ecrire un guide';
$adminModal_guide_uploadGuide = 'Téléverser le guide';
$adminModal_guide_guideName = 'Nom du guide';
$adminModal_guide_maxGuideNameLength = "Maximum $constNewsMaxNameLength caractères";
$adminModal_guide_guideUploaded = 'Le guide a été téléversé';
$adminModal_guide_deleteGuide = 'Supprimer un guide';
$adminModal_guide_deleteGuideAsk = 'Voulez-vous supprimer le guide ${guideName} ? Il n\'a aucun moyen de revenir en arrière';
$adminModal_guide_guideDeleted = 'Le guide a bien été supprimé';
$adminModal_guide_chooseGuide = 'Choisir un guide à modifier';
$adminModal_guide_loadGuideAsk = 'Voulez-vous charger le guide ${guideName} ? Votre travail sera sauvegardé.';


$guide_guideList = 'Liste des guides :';


$usefulInformation_mainInformation = 'Nos informations';
$usefulInformation_gameInformation = 'Informations serveur';
$usefulInformation_socialLinks = 'Nos liens';
$usefulInformation_serverName = 'Nom du serveur : ';
$usefulInformation_serverIp = 'IP du serveur : ';
$usefulInformation_serverPort = 'Port du serveur : ';
$usefulInformation_serverPassword = 'Mot de passe du serveur : ';
$usefulInformation_linkFacebook = 'Notre page Facebook : ';
$usefulInformation_linkTwitter = 'Notre compte Twitter : ';
$usefulInformation_linkYoutube = 'Notre chaîne Youtube : ';
$usefulInformation_linkTeamspeak = 'Notre Teamspeak : ';
$usefulInformation_linkDiscord = 'Notre Discord : ';
$usefulInformation_linkTwitch = 'Notre chaîne Twitch : ';

$usefulInformation_downloadLauncher = 'Télécharger notre launcher';
$usefulInformation_downloadLauncherAction = 'Télécharer le launcher';
$usefulInformation_downloadLauncherDescription = "Pour pouvoir accéder à notre launcher vous devez télécharger notre launcher. <br> Il se chargera de télécharger les mods et vous connectera directement sur le serveur.";

$usefulInformation_downloadTfrPlugin = 'Télécharger le plugin Task Force Radio pour Teamspeak';
$usefulInformation_downloadTfrPluginAction = 'Télécharer le plugin';
$usefulInformation_downloadTfrPluginDescription = "Notre serveur nécessite l'installation d'un plugin pour Teamspeak : Task Force Radio. <br> Celui-ci permet d'avoir une radio réaliste sur notre serveur. Il est par conséquant indispensable et doit être installé et activé pour pouvoir jouer sur notre serveur.";


$playerInformation_noDataFound = 'Aucune donnée trouvée';