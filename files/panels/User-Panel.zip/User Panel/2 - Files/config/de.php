<?php
$generic_namePanel = 'Nutzer Panel';
$generic_allRightReserved = '© '.date('Y').'. Alle Rechte Vorbehalten';
$generic_welcomeLoginMessage = 'Willkommen zu Unserem Nutzer Panel für Unsere Community';
$generic_login = 'Anmelden';
$generic_dateAt = '\at';
$generic_findData = 'Finde eine Datei';
$generic_findTag = 'Sortieren anhand des Tags';
$generic_update = 'Update';
$generic_event = 'Event';
$generic_important = 'Wichtig';
$generic_misc = 'Misc';
$general_timeToRead = 'Zeit zum lesen:';
$general_lastModification = 'Letze Änderung:';
$general_all = 'Alle';


$navbar_playerInformation = 'Spieler informationen';
$navbar_homePage = 'Home page';
$navbar_gallery = 'Gallerie';
$navbar_news = 'Neuigkeiten';
$navbar_guide = 'Anleitungen';
$navbar_leaderboard = 'Spieler Statistiken';
$navbar_usefulInformation = 'Wichtige Informationen';
$navbar_disconnect = 'Abmelden';
$navbar_admin = 'Admin';
$navbar_forum = 'Forum';


$adminModal_adminTools = 'Admin tools';
$adminModal_pageIntentionalyBlank = 'Diese Seite hat keinen Inhalt';
$adminModal_internalError = 'Interner Fehler';

$adminModal_homePage_setHomePage = 'Update home page';
$adminModal_homePage_homePageUploaded = 'Deine Webseite wurde hochgeladen und die Änderungen Übernommen';

$adminModal_chooseFile = 'Wähle eine Datei';
$adminModal_gallery_uploadImage = 'Lade ein Bild Hoch';
$adminModal_gallery_imageFileType = "Bild muss eine .jpg, .png or .gif, maximum $constGalleryMaxImagesCanSend images";
$adminModal_gallery_shortDescriptionPlaceholder = 'Short description to display';
$adminModal_gallery_maxShortDescriptionLength = "Maximum $constGalleryMaxShortDescriptionLength chars";
$adminModal_gallery_longDescriptionPlaceholder = 'Zulange Beschreibunf für den Display';
$adminModal_gallery_maxLongDescriptionLength = "Maximum $constGalleryMaxLongDescriptionLength chars";
$adminModal_gallery_deleteImages = 'Bild Löschen';
$adminModal_gallery_imageUploaded = 'Das Bild wurde Hochgeladen';
$adminModal_gallery_imageRemoved = 'Das Bild wurde gelöscht';
$adminModal_gallery_removedImageAsk = 'Möchtest du das Bild Löschen ${imageName} ? Es gibt keinen weg zurück';

$adminModal_news_writeNews = 'Veröffentliche eine Neuigkeit';
$adminModal_news_chooseNews = 'Wähle eine Neuigkeit zum bearbeiten';
$adminModal_news_chooseNewsTag = 'Wähle einen Tag';
$adminModal_news_newsName = 'Überschrift deiner Neuigkeit';
$adminModal_news_maxNewsNameLength = "Maximum $constNewsMaxNameLength chars";
$adminModal_news_uploadNews = 'Veröffentlich deine Neuigkeit';
$adminModal_news_deleteNews = 'Lösche deine Neuigkeit';
$adminModal_news_newsUploaded = 'Deine Neuigkeit wurde Veröffentlicht';
$adminModal_news_newsRemoved = 'Deine Neuigkeit wurde gelöscht';
$adminModal_news_removedNewsAsk = 'Möchtest du deine Neuigkeit Löschen ${newsName} ? Es gibt keinen weg zurück';
$adminModal_news_loadNewsAsk = 'Möchtest du diese Neuigkeit Laden ${newsName} ? Deine Arbeit wird gespeichert.';


$adminModal_guide_createGuideClass = 'Erstelle eine Anleitung';
$adminModal_guide_guideClassName = 'Category Name';
$adminModal_guide_createGuideClassName = 'Erstelle eine Category';
$adminModal_guide_guideClassNameCreated = 'Category erstellt';
$adminModal_guide_guideClassNameNotCreated = 'Die category exestiert bereits';
$adminModal_guide_deleteGuideClass = 'Lösche eine Anleitung';
$adminModal_guide_deleteGuideClassName = 'Lösche eine category';
$adminModal_guide_guideClassNameDeleted = 'Category gelöscht';
$adminModal_guide_category = 'Category';
$adminModal_guide_deleteGuideClassNameAsk = 'Möchtest du die Category Löschen ${guideClassName} ? Alle Inhalte der Category werden gelöscht und sie können nicht wieder hergestellt werden';
$adminModal_guide_writeGuide = 'Erstelle eine Anleitung';
$adminModal_guide_uploadGuide = 'Lade die Anleitung herunter';
$adminModal_guide_guideName = 'Name der Anleitung ';
$adminModal_guide_maxGuideNameLength = "Maximum $constNewsMaxNameLength chars";
$adminModal_guide_guideUploaded = 'Die Anleitung wurde hochgeladen';
$adminModal_guide_deleteGuide = 'Lösche eine Anleitung';
$adminModal_guide_deleteGuideAsk = 'Möchtest du die Anleitung ${guideName} ? Du kannst sie nicht wiederherstellen.';
$adminModal_guide_guideDeleted = 'The Anleitung wurde entfernt';
$adminModal_guide_chooseGuide = 'Wähle eine Anleitung um sie zu Bearbeiten';
$adminModal_guide_loadGuideAsk = 'Möchtest du diese Anleitungen Herunterladen ${guideName} ? Deine Änderungen werden gespeichert.';


$guide_guideList = 'Anleitungen liste:';


$usefulInformation_mainInformation = 'Unsere Informationen';
$usefulInformation_gameInformation = 'Server informationene';
$usefulInformation_socialLinks = 'Unsere Links';
$usefulInformation_serverName = 'Server name: ';
$usefulInformation_serverIp = 'Server IP: ';
$usefulInformation_serverPort = 'Server port: ';
$usefulInformation_serverPassword = 'Server password: ';
$usefulInformation_linkFacebook = 'Unsere Facebook Seite: ';
$usefulInformation_linkTwitter = 'Unser Twitter account: ';
$usefulInformation_linkYoutube = 'Unser YouTube channel: ';
$usefulInformation_linkTeamspeak = 'Unser TeamSpeak: ';
$usefulInformation_linkDiscord = 'Unser Discord: ';
$usefulInformation_linkTwitch = 'Unser Twitch channel: ';

$usefulInformation_downloadLauncher = 'Lade unseren Launcher herunter';
$usefulInformation_downloadLauncherAction = 'Lade den Launcher herunter';
$usefulInformation_downloadLauncherDescription = "Um unseren launcher zu nutzen musst du ihn erst Herunterladen. <br> Er lädt das Modpack und alle wichtigen Datei für den Server Herunter.";

$usefulInformation_downloadTfrPlugin = 'Lade TaskForceRadio Herunter';
$usefulInformation_downloadTfrPluginAction = 'Lade das Plugin Herunter';
$usefulInformation_downloadTfrPluginDescription = "Unserer Server benutz TaskForceRadio. <br> TFAR erlaubt dir eine Realitische Stimmen wiedergabe. TaskForce Radio ist verpflichtent um auf unserem Server zu Spielen eine Installation ist zwingend Notwendig.";


$playerInformation_noDataFound = 'Keine Daten gefunden';