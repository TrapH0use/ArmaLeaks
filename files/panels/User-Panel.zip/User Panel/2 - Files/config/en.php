<?php
$generic_namePanel = 'User Panel';
$generic_allRightReserved = '© '.date('Y').'. All rights reserved';
$generic_welcomeLoginMessage = 'Welcome to our user panel for our community.';
$generic_login = 'Login';
$generic_dateAt = '\at';
$generic_findData = 'Find a data';
$generic_findTag = 'Filter by tag';
$generic_update = 'Update';
$generic_event = 'Event';
$generic_important = 'Important';
$generic_misc = 'Misc';
$general_timeToRead = 'Time to read:';
$general_lastModification = 'Last modified:';
$general_all = 'All';


$navbar_playerInformation = 'Players information';
$navbar_homePage = 'Home page';
$navbar_gallery = 'Gallery';
$navbar_news = 'News';
$navbar_guide = 'Guides';
$navbar_leaderboard = 'Leaderboard';
$navbar_usefulInformation = 'Useful information';
$navbar_disconnect = 'Logout';
$navbar_admin = 'Admin';
$navbar_forum = 'Forum';


$adminModal_adminTools = 'Admin tools';
$adminModal_pageIntentionalyBlank = 'This page is deliberately blank';
$adminModal_internalError = 'Inteternal error';

$adminModal_homePage_setHomePage = 'Update home page';
$adminModal_homePage_homePageUploaded = 'The home page has been uploaded';

$adminModal_chooseFile = 'Choose a file';
$adminModal_gallery_uploadImage = 'Upload an image';
$adminModal_gallery_imageFileType = "Must be a .jpg, .png or .gif, maximum $constGalleryMaxImagesCanSend images";
$adminModal_gallery_shortDescriptionPlaceholder = 'Short description to display';
$adminModal_gallery_maxShortDescriptionLength = "Maximum $constGalleryMaxShortDescriptionLength chars";
$adminModal_gallery_longDescriptionPlaceholder = 'Long description to display';
$adminModal_gallery_maxLongDescriptionLength = "Maximum $constGalleryMaxLongDescriptionLength chars";
$adminModal_gallery_deleteImages = 'Delete images';
$adminModal_gallery_imageUploaded = 'The image been uploaded';
$adminModal_gallery_imageRemoved = 'The image has been deleted';
$adminModal_gallery_removedImageAsk = 'Do you want to delete the image ${imageName} ? He has no way to go back.';

$adminModal_news_writeNews = 'Write a news';
$adminModal_news_chooseNews = 'Choose a news to modify';
$adminModal_news_chooseNewsTag = 'Choose a tag';
$adminModal_news_newsName = 'News name';
$adminModal_news_maxNewsNameLength = "Maximum $constNewsMaxNameLength chars";
$adminModal_news_uploadNews = 'Upload the news';
$adminModal_news_deleteNews = 'Delete a news';
$adminModal_news_newsUploaded = 'The news has been uploaded';
$adminModal_news_newsRemoved = 'The news has been deleted';
$adminModal_news_removedNewsAsk = 'Do you want to delete the news ${newsName} ? He has no way to go back.';
$adminModal_news_loadNewsAsk = 'Do you want to load the news ${newsName} ? Your work will be saved.';


$adminModal_guide_createGuideClass = 'Create a guide category';
$adminModal_guide_guideClassName = 'Category Name';
$adminModal_guide_createGuideClassName = 'Create the category';
$adminModal_guide_guideClassNameCreated = 'Category created';
$adminModal_guide_guideClassNameNotCreated = 'The category already exists';
$adminModal_guide_deleteGuideClass = 'Delete a guide category';
$adminModal_guide_deleteGuideClassName = 'Delete a category';
$adminModal_guide_guideClassNameDeleted = 'Category deleted';
$adminModal_guide_category = 'Category';
$adminModal_guide_deleteGuideClassNameAsk = 'Do you want to delete the category ${guideClassName} ? All present guides will be deleted. He has no way to go back.';
$adminModal_guide_writeGuide = 'Write a guide';
$adminModal_guide_uploadGuide = 'Download the guide';
$adminModal_guide_guideName = 'Name of the guide';
$adminModal_guide_maxGuideNameLength = "Maximum $constNewsMaxNameLength chars";
$adminModal_guide_guideUploaded = 'The guide has been uploaded';
$adminModal_guide_deleteGuide = 'Delete a guide';
$adminModal_guide_deleteGuideAsk = 'Do you want to delete the guide ${guideName} ? He has no way to go back.';
$adminModal_guide_guideDeleted = 'The guide has been deleted';
$adminModal_guide_chooseGuide = 'Choose a guide to modify';
$adminModal_guide_loadGuideAsk = 'Do you want to load the guide ${guideName} ? Your work will be saved.';


$guide_guideList = 'Guides list:';


$usefulInformation_mainInformation = 'Our information';
$usefulInformation_gameInformation = 'Server information';
$usefulInformation_socialLinks = 'Our links';
$usefulInformation_serverName = 'Server name: ';
$usefulInformation_serverIp = 'Server IP: ';
$usefulInformation_serverPort = 'Server port: ';
$usefulInformation_serverPassword = 'Server password: ';
$usefulInformation_linkFacebook = 'Our Facebook page: ';
$usefulInformation_linkTwitter = 'Our Twitter account: ';
$usefulInformation_linkYoutube = 'Our YouTube channel: ';
$usefulInformation_linkTeamspeak = 'Our TeamSpeak: ';
$usefulInformation_linkDiscord = 'Our Discord: ';
$usefulInformation_linkTwitch = 'Our Twitch channel: ';

$usefulInformation_downloadLauncher = 'Download our launcher';
$usefulInformation_downloadLauncherAction = 'Download the launcher';
$usefulInformation_downloadLauncherDescription = "In order to access our launcher you need to download our launcher. <br> It will download the mods and connect you directly to the server.";

$usefulInformation_downloadTfrPlugin = 'Download Task Force Radio plugin for Teamspeak';
$usefulInformation_downloadTfrPluginAction = 'Download the plugin';
$usefulInformation_downloadTfrPluginDescription = "Our server requires the installation of a plugin for Teamspeak: Task Force Radio. <br> This one allows us to have a realistic radio on our server. It is therefore indispensable and must be installed and activated in order to play on our server.";


$playerInformation_noDataFound = 'No data found';