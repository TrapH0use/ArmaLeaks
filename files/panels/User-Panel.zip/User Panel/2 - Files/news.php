<!--
    Author: Thomas Croizet "Steez"
    Teamspeak 3: ts.the-programmer.com
    Web site: www.the-programmer.com

    Terms of use:
      - This file is forbidden unless you have permission from the author. If you have this file without permission to use it please do not use it and do not share it.
      - If you have permission to use this file, you can use it on your server however it is strictly forbidden to share it.
      - Out of respect for the author please do not delete this information.
-->

<?php
// *** -------------------- (Please do not touch these lines) -------------------- ***
require 'config/constant.php';
require "app/pdo.php";
require "app/Parser/beautifier.php";
session_start();

if (isset($_GET['steamId']))
{
	// Set the cookie and rediect automaticly the user
	setCookie('steamId', $_GET['steamId'], (time() + 60 * 60 * 24 * 30), '/', $_SERVER['HTTP_HOST'], false, true);
	header("Location: news.php");
	exit;
}

// If the cookie steamId is not set
if (!isset($_COOKIE['steamId']))
	header('Location: index.php');

// Set the steamId session variable
$_SESSION['steamId'] = $_COOKIE['steamId'];

// Reset the cookie
setCookie('steamId', $_SESSION['steamId'], (time() + 60 * 60 * 24 * 30), '/', $_SERVER['HTTP_HOST'], false, true);
// *** --------------------------------------------------------------------------- ***
?>

<!DOCTYPE html>
<html lang="fr">
	<head>
        <title><?= $generic_namePanel ?> - <?= $navbar_news ?></title>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="Example of a description">
		<meta name="keywords" content="user, panel, theprogrammer">
		<meta name="author" content="The Programmer">
		<meta name="twitter:site" content="User Panel">
		<meta name="twitter:title" content="User Panel">
		<meta name="twitter:description" content="Example of a description">
		<meta name="twitter:creator" content="The Programmer">
		<meta property="og:title" content="User Panel"/>
		<meta property="og:type" content="Web site"/>
		<meta property="og:url" content="https://example-userpanel.com"/>
		<meta property="og:description" content="Example of a description"/>
		<meta property="og:site_name" content="User Panel"/>
		<meta name="robots" content="index, follow"/>
		<meta name="reply-to" content="example@userpanel.com">
		<meta name="copyright" content="The Programmer">

		<link rel="stylesheet" href="css/panel.css?<?= time() ?>">
		<?php include 'include/header.php'; ?>
	</head>

    <body>
        <!-- ** NAVBAR ** -->
		<?php include 'include/navbar.php'; ?>
		<!-- ** END - NAVBAR ** -->

        <!-- ** MAIN ** -->
        <main class="container animated fadeIn mt-4">
            <?php if (isset($_GET['news'])): ?>

            <?php
                // *** -------------------- (Please do not touch these lines) -------------------- ***
                $newsXml = new SimpleXMLElement(file_get_contents("news/$_GET[news]"));
                $newsName = $newsXml->newsName;
                $newsTagName = $constNewsTag[strval($newsXml->newsTag)][0];
                $newsTagColor = $constNewsTag[strval($newsXml->newsTag)][1];
                $newsIcon = '';
                if (isset($constNewsTag[strval($newsXml->newsTag)][2]))
                    $newsIcon = $constNewsTag[strval($newsXml->newsTag)][2];
                $newsContent = $newsXml->newsContent;
                $date = date("d/m/Y $generic_dateAt G:i", filemtime("news/$_GET[news]"));

                require 'app/html2text.php';
                // Parse the HTML string as HTML DOM
                $newsContentHtml = new \Html2Text\Html2Text($newsContent);
                // Get all the word in the HTML content
                $newsContentWords = explode(' ', $newsContentHtml->getText());
                // Get the number of words
                $newsContentWordsCount = count($newsContentWords);
                $timeToRead = round($newsContentWordsCount / 250);
                if ($timeToRead == 0) $timeToRead = 1;

                echo "<article class=\"news-container mt-4 mb-4\"><div class=\"row m-0\"><div class=\"col-12 col-sm-6 p-0\"><p class=\"display-4 mb-2\">$newsName</p><span style=\"background: $newsTagColor\" class=\"p-1 news-tag\"><i class=\"icon-$newsIcon mr-1\"></i>$newsTagName</span></div><div class=\"col-12 col-sm-6 p-0\"><p class=\"news-modification-text\">$general_lastModification $date <br> $general_timeToRead $timeToRead min</p></div></div><hr><div class=\"ql-editor p-0\">$newsContent</div></article>"
                // *** --------------------------------------------------------------------------- ***
            ?>

            <?php else: ?>

            <div class="row m-0 p-0">
                <div class="col-12 col-sm-6 pl-0 pt-0 pb-0 pr-0 pr-md-3">
                    <div class="inner-addon left-addon">
                        <input id="searchTextBox" class="form-control" type="text" placeholder="<?= $generic_findData ?>">
                        <i class="icon-search"></i>
                    </div>
                </div>

                <div class="col-12 col-sm-6 pr-0 pt-0 pb-0 pl-0 pl-md-3">
                    <div class="inner-addon left-addon">
                        <select id="tagSelect" class="custom-select">
                            <option value="all" selected><?= $general_all ?></option>
                            <?php 
                            $newsTagCount = count($constNewsTag);
                            // Get the keys and interact with them like an id
                            $newsTagKeys = array_keys($constNewsTag);

                            for ($i = 0; $i < $newsTagCount; $i++) {
                                $newsTagDisplayName = $constNewsTag[$newsTagKeys[$i]][0];
                                echo "<option value=\"$newsTagDisplayName\">$newsTagDisplayName</option>";
                            }
                            ?>
                        </select>
                        <i class="icon-search"></i>
                    </div>
                </div>
            </div>

            <hr>

            <?php
                // *** -------------------- (Please do not touch these lines) -------------------- ***
                // Get the gallery images
                $path = 'news';
                $news = scandir($path);
                sort($news,  SORT_NATURAL);
                $news = array_reverse($news);
                $newsCount = count($news);

                for ($i = 0; $i < $newsCount; $i++)
                {
                    if (!in_array($news[$i], ['.', '..']))
                    {
                        // Read the XML
                        $newsXml = new SimpleXMLElement(file_get_contents("$path/".pathinfo($news[$i])['filename'].'.xml'));
                        // Get the news information
                        $newsName = $newsXml->newsName;
                        $newsTagName = $constNewsTag[strval($newsXml->newsTag)][0];
                        $newsTagColor = $constNewsTag[strval($newsXml->newsTag)][1];
                        $newsIcon = '';
                        if (isset($constNewsTag[strval($newsXml->newsTag)][2]))
                            $newsIcon = $constNewsTag[strval($newsXml->newsTag)][2];
                        $newsContent = $newsXml->newsContent;
                        $date = date("d/m/Y $generic_dateAt G:i", filemtime("$path/$news[$i]"));

                        echo ($i == 0) ? "<article class=\"news-preview mb-4\" onclick=\"request_news(this, '$news[$i]')\"><div class=\"row news-preview-title m-0\"><div class=\"col-12 col-sm-6 p-0\"><h3 class=\"display-4 mb-2\">$newsName</h3><span style=\"background: $newsTagColor\" class=\"p-1 news-tag\" onclick=\"canRequestNews = false;select_tag(this, '$newsTagName');\"><i class=\"icon-$newsIcon mr-1\"></i>$newsTagName</span></div><div class=\"col-12 col-sm-6 p-0\"><p class=\"news-modification-text\">$general_lastModification $date</p></div></div><div class=\"news-preview-content\"><p class=\"lead mb-0\"><div class=\"ql-editor news-preview-content-text p-0\">$newsContent</p></div></div></article>" : 
                                         "<article class=\"news-preview mb-4\" onclick=\"request_news(this, '$news[$i]')\"><div class=\"row news-preview-title m-0\"><div class=\"col-12 col-sm-6 p-0\"><h3 class=\"display-4 mb-2\">$newsName</h3><span style=\"background: $newsTagColor\" class=\"p-1 news-tag\" onclick=\"canRequestNews = false;select_tag(this, '$newsTagName');\"><i class=\"icon-$newsIcon mr-1\"></i>$newsTagName</span></div><div class=\"col-12 col-sm-6 p-0\"><p class=\"news-modification-text\">$general_lastModification $date</p></div></div><div class=\"news-preview-content\"><p class=\"lead mb-0\"><div class=\"ql-editor news-preview-content-text p-0\">$newsContent</p></div></div></article>";
                    }
                }
                // *** --------------------------------------------------------------------------- ***
            ?>

            <?php endif ?>
        </main>
        <!-- ** END - MAIN ** -->

        <!-- ** FOOTER ** -->
        <?php include 'include/footer.php'; ?>
        <!-- ** END - FOOTER ** -->

        <script>
            var canRequestNews = true;

            const request_news = (event, newsFileName) => {
                if (!canRequestNews) {
                    canRequestNews = true;
                }
                else {
                    document.location.href = `news.php?news=${newsFileName}`;
                }
            }

            const select_tag = (event, tagName) => {
                $('#tagSelect').val(tagName);

                // Get all the text elements
                const headerElements = document.getElementsByClassName('news-tag');
				const headerElementsCount = headerElements.length;

				// Search on all the headerElements
				for (let i = 0; i < headerElementsCount; i++) 
				{
                    if ($('#tagSelect').val() == 'all')
                        headerElements[i].parentElement.parentElement.parentElement.classList.remove('d-none');
                    else 
                    {
                        if (headerElements[i].textContent.match(new RegExp($('#tagSelect').val(), 'gi'))) {
						    headerElements[i].parentElement.parentElement.parentElement.classList.remove('d-none');
                        }
                        else {
                            headerElements[i].parentElement.parentElement.parentElement.classList.add('d-none');
                        }
                    }
				}
            }

            <?php if (!isset($_GET['news'])): ?>

            document.getElementById('searchTextBox').onkeyup = (elementName) => 
			{
				// Get all the text elements
				const headerElements = document.getElementsByTagName('h3');
				const headerElementsCount = headerElements.length;

				// Search on all the headerElements
				for (let i = 0; i < headerElementsCount; i++) 
				{
					if (headerElements[i].textContent.match(new RegExp(elementName.target.value, 'gi'))) {
						headerElements[i].parentElement.parentElement.parentElement.classList.remove('d-none');
					}
					else {
						headerElements[i].parentElement.parentElement.parentElement.classList.add('d-none');
					}
				}
            };
            
            $('#tagSelect').on('change', (elementName) => {
                // Get all the text elements
                const headerElements = document.getElementsByClassName('news-tag');
				const headerElementsCount = headerElements.length;

				// Search on all the headerElements
				for (let i = 0; i < headerElementsCount; i++) 
				{
                    if (elementName.target.value == 'all')
                        headerElements[i].parentElement.parentElement.parentElement.classList.remove('d-none');
                    else 
                    {
                        if (headerElements[i].textContent.match(new RegExp(elementName.target.value, 'gi'))) {
						    headerElements[i].parentElement.parentElement.parentElement.classList.remove('d-none');
                        }
                        else {
                            headerElements[i].parentElement.parentElement.parentElement.classList.add('d-none');
                        }
                    }
				}
            });

            <?php endif ?>
        </script>
    </body>
</html>