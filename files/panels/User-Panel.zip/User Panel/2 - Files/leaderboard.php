<!--
    Author: Thomas Croizet "Steez"
    Teamspeak 3: ts.the-programmer.com
    Web site: www.the-programmer.com

    Terms of use:
      - This file is forbidden unless you have permission from the author. If you have this file without permission to use it please do not use it and do not share it.
      - If you have permission to use this file, you can use it on your server however it is strictly forbidden to share it.
      - Out of respect for the author please do not delete this information.
-->

<?php
// *** -------------------- (Please do not touch these lines) -------------------- ***
error_reporting(E_ERROR | E_WARNING | E_PARSE);
require 'config/constant.php';
require "app/pdo.php";
require "app/Parser/beautifier.php";
session_start();

if (isset($_GET['steamId']))
{
	// Set the cookie and rediect automaticly the user
	setCookie('steamId', $_GET['steamId'], (time() + 60 * 60 * 24 * 30), '/', $_SERVER['HTTP_HOST'], false, true);
	header("Location: panel.php");
	exit;
}

// If the cookie steamId is not set
if (!isset($_COOKIE['steamId']))
	header('Location: index.php');

// Set the steamId session variable
$_SESSION['steamId'] = $_COOKIE['steamId'];

// Reset the cookie
setCookie('steamId', $_SESSION['steamId'], (time() + 60 * 60 * 24 * 30), '/', $_SERVER['HTTP_HOST'], false, true);
// *** --------------------------------------------------------------------------- ***
?>

<!DOCTYPE html>
<html lang="fr">
	<head>
		<title><?= $generic_namePanel ?> - <?= $navbar_leaderboard ?></title>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="Example of a description">
		<meta name="keywords" content="user, panel, theprogrammer">
		<meta name="author" content="The Programmer">
		<meta name="twitter:site" content="User Panel">
		<meta name="twitter:title" content="User Panel">
		<meta name="twitter:description" content="Example of a description">
		<meta name="twitter:creator" content="The Programmer">
		<meta property="og:title" content="User Panel"/>
		<meta property="og:type" content="Web site"/>
		<meta property="og:url" content="https://example-userpanel.com"/>
		<meta property="og:description" content="Example of a description"/>
		<meta property="og:site_name" content="User Panel"/>
		<meta name="robots" content="index, follow"/>
		<meta name="reply-to" content="example@userpanel.com">
		<meta name="copyright" content="The Programmer">

		<link rel="stylesheet" href="css/panel.css?<?= time() ?>">
		<?php include 'include/header.php'; ?>
	</head>

    <body>
        <!-- ** NAVBAR ** -->
		<?php include 'include/navbar.php'; ?>
		<!-- ** END - NAVBAR ** -->

		<!-- ** MAIN ** -->
		<main class="container animated fadeIn mt-4 mb-4">
			<?php 
				// *** -------------------- (Please do not touch these lines) -------------------- ***
			    $constPanelLeaderboardConfigString = file_get_contents("config/leaderboard.xml");
                $PdoQuery = new App\PdoQuery($constPdoDatabaseName);

                // Get all the categories
                $leaderboardXml = simplexml_load_string($constPanelLeaderboardConfigString);
				$leaderboardCategories = $leaderboardXml->category;
				$leaderboardCategoriesCount = count($leaderboardCategories);

                for ($i = 0; $i < $leaderboardCategoriesCount; $i++) 
                {
                    // Get the data name and the dbName
                    $dataName = $leaderboardCategories[$i]->attributes()->name;
                    $dataDbName = $leaderboardCategories[$i]->attributes()->dbName;
                    $dataField = $leaderboardCategories[$i]->attributes()->field;
                    $dataIdentifier = $leaderboardCategories[$i]->attributes()->identifier;
                    $data = '';
                    
                    // If the listing method is sort
					if ($leaderboardCategories[$i]->attributes()->list == 'sort') 
					{
						// Execute the query
						$categoryQuery = $PdoQuery->query("SELECT $dataIdentifier, $dataField FROM $dataDbName");
						$identifierColumn = [];
						$fieldColumn = [];
						
						// Convert the query array result as a column array instead of a row array
						$identifierColumn = array_column($categoryQuery, $dataIdentifier);
						$fieldColumn = array_column($categoryQuery, $dataField);
						array_multisort($fieldColumn, SORT_DESC, $identifierColumn, SORT_ASC, $categoryQuery);
						//print_r($categoryQuery);

						// Start the beautifier
						$Beautifier = new App\Parser\Beautifier(strval($leaderboardCategories[$i]->attributes()->method));
						$BeautifierToPlayerName = new App\Parser\Beautifier('to-playerName-steamId');

						for ($j = 0; $j < $constPanelLeaderboardMaxDataShowPerCategory; $j++) {
							// Beautify the field
							$fieldBeautify = $Beautifier->parse($categoryQuery[$j][strval($dataField)]);
							// Add the data
							if (isset($leaderboardCategories[$i]->attributes()->toPlayerName))
								$data .= $BeautifierToPlayerName->parse(trim($categoryQuery[$j][strval($dataIdentifier)], " \t\n\r\0\x0B`'\"")).' - '.$fieldBeautify.'<br>';
							else
								$data .= trim($categoryQuery[$j][strval($dataIdentifier)], " \t\n\r\0\x0B`'\"").' - '.$fieldBeautify.'<br>';
						}
					}
					else
					{
						// Execute the query
						$categoryQuery = $PdoQuery->query("SELECT $dataIdentifier FROM $dataDbName");
						$categoryQueryCount = count($categoryQuery);
						$dataArray = [];
						$data = '';

						for ($j = 0; $j < $categoryQueryCount; $j++) {
							// Get the current element
							$currentElement = $categoryQuery[$j][strval($dataIdentifier)];

							// Count it!
							if (!array_key_exists($currentElement, $dataArray))
								$dataArray[$currentElement] = 1;
							else
								$dataArray[$currentElement] += 1;
						}

						// Sort the array numericly
						arsort($dataArray);
						// Get the keys
						$dataArrayKeys = array_keys($dataArray);
						$index = 0;
						// Start the beautifier
						$Beautifier = new App\Parser\Beautifier(strval($leaderboardCategories[$i]->attributes()->method));
						$BeautifierToPlayerName = new App\Parser\Beautifier('to-playerName-steamId');

						foreach ($dataArrayKeys	as $key) 
						{
							if ($index >= $constPanelLeaderboardMaxDataShowPerCategory)
								break;

							$fieldBeautify = $Beautifier->parse($dataArray[$key]);
							// Add the data
							if (isset($leaderboardCategories[$i]->attributes()->toPlayerName))
								$data .= $BeautifierToPlayerName->parse(trim($key, " \t\n\r\0\x0B`'\"")).' - '.$fieldBeautify.'<br>';
							else
								$data .= trim($key, " \t\n\r\0\x0B`'\"").' - '.$fieldBeautify.'<br>';

							$index++;
						}
					}

                    // Display the information
                    $iconHtml = isset($leaderboardCategories[$i]->attributes()->icon) ? '<i class="icon-'.$leaderboardCategories[$i]->attributes()->icon.' mr-1"></i>' : '';
                    echo "<div class=\"information-container m-0 row mb-4\"><div class=\"information-title col-12 col-sm-6\"><h3 class=\"p-0 mb-0\">$iconHtml $dataName</h3></div><div class=\"information-content-no-hover align-self-center col-12 col-sm-6\"><p class=\"p-0 mb-0\">$data</p></div></div>";
				}
				// *** --------------------------------------------------------------------------- ***
            ?>
		</main>
		<!-- ** END - MAIN ** -->

		<!-- ** FOOTER ** -->
		<?php include 'include/footer.php'; ?>
        <!-- ** END - FOOTER ** -->
    </body>
</html>