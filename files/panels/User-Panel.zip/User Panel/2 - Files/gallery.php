<!--
    Author: Thomas Croizet "Steez"
    Teamspeak 3: ts.the-programmer.com
    Web site: www.the-programmer.com

    Terms of use:
      - This file is forbidden unless you have permission from the author. If you have this file without permission to use it please do not use it and do not share it.
      - If you have permission to use this file, you can use it on your server however it is strictly forbidden to share it.
      - Out of respect for the author please do not delete this information.
-->

<?php
// *** -------------------- (Please do not touch these lines) -------------------- ***
require 'config/constant.php';
require "app/pdo.php";
require "app/Parser/beautifier.php";
session_start();

if (isset($_GET['steamId']))
{
	// Set the cookie and rediect automaticly the user
	setCookie('steamId', $_GET['steamId'], (time() + 60 * 60 * 24 * 30), '/', $_SERVER['HTTP_HOST'], false, true);
	header("Location: playerInformation.php?category=$constPanelDefaultCategory");
	exit;
}

// If the cookie steamId is not set
if (!isset($_COOKIE['steamId']))
	header('Location: index.php');

// Set the steamId session variable
$_SESSION['steamId'] = $_COOKIE['steamId'];

// Reset the cookie
setCookie('steamId', $_SESSION['steamId'], (time() + 60 * 60 * 24 * 30), '/', $_SERVER['HTTP_HOST'], false, true);
// *** --------------------------------------------------------------------------- ***
?>

<!DOCTYPE html>
<html lang="fr">
	<head>
		<title><?= $generic_namePanel ?> - <?= $navbar_gallery ?></title>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="Example of a description">
		<meta name="keywords" content="user, panel, theprogrammer">
		<meta name="author" content="The Programmer">
		<meta name="twitter:site" content="User Panel">
		<meta name="twitter:title" content="User Panel">
		<meta name="twitter:description" content="Example of a description">
		<meta name="twitter:creator" content="The Programmer">
		<meta property="og:title" content="User Panel"/>
		<meta property="og:type" content="Web site"/>
		<meta property="og:url" content="https://example-userpanel.com"/>
		<meta property="og:description" content="Example of a description"/>
		<meta property="og:site_name" content="User Panel"/>
		<meta name="robots" content="index, follow"/>
		<meta name="reply-to" content="example@userpanel.com">
		<meta name="copyright" content="The Programmer">

		<link rel="stylesheet" href="css/panel.css?<?= time() ?>">
		<?php include 'include/header.php'; ?>

        <style>
        * {
            box-sizing: border-box;
        }

        body {
            position: relative;
        }

        #gallery 
        {
            display: grid;
            height: auto;
            grid-template-columns: repeat(4, 1fr);
            grid-template-rows: repeat(4, 1fr); 
            grid-gap: 0.5rem;

            margin: 0.5rem;
        }

        @media (max-width: 800px) {
            #gallery {
                display: flex;
                align-items: flex-start;
                flex-wrap: wrap;
            }
            
            #gallery > div {
                width: 48%;
                margin: 1%;
            }
        }
        @media (max-width: 800px) and (max-width: 350px) {
            #gallery > div {
                width: 98%;
            }
        }

        /*#gallery > div:nth-child(6n + 1) {
            grid-column: span 2;
            grid-row: span 2;
        }
        #gallery > div:nth-child(2) {
            grid-column: span 3;
            grid-row: span 3;
        }
        #gallery > div:nth-child(4) {
            grid-column: span 1;
            grid-row: span 2;
        }*/
        #gallery > div > a {
            opacity: 0;
            position: absolute;
            color: #fff;
            background-color: transparent;
            font-size: 2rem;
            font-weight: bold;
            padding: 2rem;
            width: 100%;
            height: 100%;
            transition: all ease 1s;
        }
        #gallery > div > img {
            width: 100%;
            min-height: calc(33.334vh - 62px - (2 * 0.5em));
            max-height: calc(33.334vh - 62px - (2 * 0.5em));
            object-fit: cover;
            transition: all ease 1s;
        }
        /*#gallery > div:hover img {
            filter: blur(4px);
        }*/
        #gallery > div:hover a {
            opacity: 1;
        }
        #gallery > div {
            overflow: hidden;
            position: relative;
            box-shadow: 0 2px 8px 0 rgba(0, 0, 0, 0.2), 0 3px 20px 0 rgba(0, 0, 0, 0.19);

            border-radius: 5px;
        }
        #gallery div,
        #gallery a {
            display: flex;
            justify-content: center;
            align-items: center;
            text-decoration: none;
        }


        [id^="image-"] {
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            background-color: rgba(0, 0, 0, 0.5);
            display: flex;
            opacity: 0;
            transition: opacity 450ms ease-in-out;
            align-items: center;
            justify-content: center;
            pointer-events: none;
        }

        [id^="image-"]:target {
            opacity: 1;
            pointer-events: inherit;
        }

        [id^="image-"]:target img {
            filter: blur(0);
        }

        [id^="image-"] .content {
            max-width: 90%;
            position: relative;
            color: #fff;
        }

        [id^="image-"] .content:hover > a.close {
            opacity: 1;
            transform: scale(1, 1);
        }

        [id^="image-"] .content:hover > .title {
            opacity: 1;
            transform: translateY(-3px);
        }

        [id^="image-"] .content:hover > .title::after {
            opacity: 1;
        }

        [id^="image-"] .content > * {
            transition: all 450ms ease-in-out;
        }

        [id^="image-"] .title {
            display: block;
            margin: 0;
            padding: 1em;
            position: absolute;
            bottom: 0;
            width: 100%;
            transform: translateY(50%);
            font-size: 1.25rem;
            opacity: 0;
        }

        [id^="image-"] .title::after {
            content: ' ';
            background-color: rgba(0, 0, 0, 0.4);
            bottom: 0;
            left: 0;
            height: 100%;
            width: 100%;
            position: absolute;
            transition: all 350ms ease-in-out 250ms;
            opacity: 0;
            transform-origin: bottom;
            mix-blend-mode: soft-light;
        }

        [id^="image-"] img {
            max-height: 90vh;
            max-width: 90vw;
            margin: 0;
            padding: 0;
            filter: blur(50px);
        }

        [id^="image-"] a.close {
            width: 2em;
            height: 2em;
            position: absolute;
            right: 0;
            top: 0;
            background-color: rgba(0, 0, 0, 0.5);
            display: flex;
            align-items: center;
            justify-content: center;
            transform: scale(0, 0);
            opacity: 0;
            transform-origin: right top;
            text-decoration: none;
            color: #fff;
        }

        [id^="image-"] a.close::after {
            content: "X";
        }
        </style>
	</head>

	<body>
		<!-- ** NAVBAR ** -->
		<?php include 'include/navbar.php'; ?>
		<!-- ** END - NAVBAR ** -->

        <!-- ** MAIN ** -->
        <main id="gallery" class="animated fadeIn">
            <?php 
            // *** -------------------- (Please do not touch these lines) -------------------- ***
            $path = 'gallery/';
            $images = scandir($path, 1);
            sort($images,  SORT_NATURAL);
            $images = array_reverse($images);
            $imagesCount = count($images);

            for ($i = 0; $i < $imagesCount; $i++) {
                if (!in_array($images[$i], ['.', '..']) && strpos($images[$i], 'xml') === false) {
                    // Read the XML
                    $imageXml = new SimpleXMLElement(file_get_contents("$path/".pathinfo($images[$i])['filename'].'.xml'));
                    // Get the short description
                    $shortDescription = $imageXml->shortDescription;
                    $longDescription = $imageXml->longDescription;

                    // Write the result
                    echo "<div><img class=\"gallery-image\" src=\"$path/$images[$i]\"/ alt=\"$longDescription\"><a class=\"imageOpen\" href=\"#image-$i\">$shortDescription</a></div>";
                }
            }
            // *** --------------------------------------------------------------------------- ***
            ?>
        </main>
        <!-- ** END - MAIN ** -->

        <!-- ** FOOTER ** -->
        <?php include 'include/footer.php'; ?>
        <!-- ** END - FOOTER ** -->

        <!-- ** IMAGE VIEWER ** -->
        <?php
        // *** -------------------- (Please do not touch these lines) -------------------- ***
        for ($i = 0; $i < $imagesCount; $i++) {
            if (!in_array($images[$i], ['.', '..']) && strpos($images[$i], 'xml') === false) {
                // Read the XML
                $imageXml = new SimpleXMLElement(file_get_contents("$path/".pathinfo($images[$i])['filename'].'.xml'));
                // Get the short description
                $longDescription = $imageXml->longDescription;

                // Write the result
                echo "<div id=\"image-$i\" class=\"image\"><div class=\"content\"><img src=\"$path/$images[$i]\" alt=\"$longDescription\"/><div class=\"title\">$longDescription</div><a class=\"close\" href=\"#\"></a></div></div>";
            }
        }
        // *** --------------------------------------------------------------------------- ***
        ?>
        <!-- ** END - IMAGE VIEWER ** -->

        <script>
        // *** -------------------- (Please do not touch these lines) -------------------- ***
        $('.imageOpen').on('click', event => {
            // Set the new URL
            var mainUrl = location.href; 
            location.href = event.currentTarget.href;
            history.replaceState(null, null, mainUrl);

            // Prevent the event
            event.preventDefault();
        });

        $('.image').on('click', event => {
            // Get the scroll position
            const y = window.scrollY; 
            const x = window.scrollX;

            // Set the new URL
            var mainUrl = location.href; 
            location.href = '#';
            history.replaceState(null, null, mainUrl);

            // Prevent scrolling
            window.scrollTo(x, y);

            // Prevent the event
            event.preventDefault();
        });

        $('.close').on('click', event => {
            // Get the scroll position
            const y = window.scrollY; 
            const x = window.scrollX;

            // Set the new URL
            var mainUrl = location.href; 
            location.href = '#';
            history.replaceState(null, null, mainUrl);

            // Prevent scrolling
            window.scrollTo(x, y);

            // Prevent the event
            event.preventDefault();
        });
        // *** --------------------------------------------------------------------------- ***
        </script>
    </body>
</html>