<!--
    Author: Thomas Croizet "Steez"
    Teamspeak 3: ts.the-programmer.com
    Web site: www.the-programmer.com

    Terms of use:
      - This file is forbidden unless you have permission from the author. If you have this file without permission to use it please do not use it and do not share it.
      - If you have permission to use this file, you can use it on your server however it is strictly forbidden to share it.
      - Out of respect for the author please do not delete this information.
-->

<?php
// *** -------------------- (Please do not touch these lines) -------------------- ***
error_reporting(E_ERROR | E_WARNING | E_PARSE);
require 'config/constant.php';
require "app/pdo.php";
require "app/Parser/beautifier.php";
session_start();

if (isset($_GET['steamId']))
{
	// Set the cookie and rediect automaticly the user
	setCookie('steamId', $_GET['steamId'], (time() + 60 * 60 * 24 * 30), '/', $_SERVER['HTTP_HOST'], false, true);
	header("Location: playerInformation.php?category=$constPanelPlayerInformationDefaultCategory");
	exit;
}

// If the cookie steamId is not set
if (!isset($_COOKIE['steamId']))
	header('Location: index.php');

// Set the steamId session variable
$_SESSION['steamId'] = $_COOKIE['steamId'];

// If the category GET attribute is not set
if (!isset($_GET['category']))
	header("Location: playerInformation.php/?category=$constPanelPlayerInformationDefaultCategory");

// Reset the cookie
setCookie('steamId', $_SESSION['steamId'], (time() + 60 * 60 * 24 * 30), '/', $_SERVER['HTTP_HOST'], false, true);
// *** --------------------------------------------------------------------------- ***
?>

<!DOCTYPE html>
<html lang="fr">
	<head>
		<title><?= $generic_namePanel ?> - <?= $navbar_playerInformation ?></title>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="Example of a description">
		<meta name="keywords" content="user, panel, theprogrammer">
		<meta name="author" content="The Programmer">
		<meta name="twitter:site" content="User Panel">
		<meta name="twitter:title" content="User Panel">
		<meta name="twitter:description" content="Example of a description">
		<meta name="twitter:creator" content="The Programmer">
		<meta property="og:title" content="User Panel"/>
		<meta property="og:type" content="Web site"/>
		<meta property="og:url" content="https://example-userpanel.com"/>
		<meta property="og:description" content="Example of a description"/>
		<meta property="og:site_name" content="User Panel"/>
		<meta name="robots" content="index, follow"/>
		<meta name="reply-to" content="example@userpanel.com">
		<meta name="copyright" content="The Programmer">

		<link rel="stylesheet" href="css/panel.css?<?= time() ?>">
		<?php include 'include/header.php'; ?>
	</head>

	<body>
		<!-- ** NAVBAR ** -->
		<?php include 'include/navbar.php'; ?>
		<!-- ** END - NAVBAR ** -->

		<!-- ** MAIN ** -->
		<?php
			$constPanelDictionnaryString = file_get_contents("config/dictionnary.xml");

			$PdoQuery = new App\PdoQuery($constPdoDatabaseName);
			$resultQuery = false;
			
			// Display all the categories
			for ($i = 0; $i < $categoriesCount; $i++)
			{
				// Get the category dbname
				$categoryDbName = $categories[$i]->attributes()->dbName;
				$categoryIndentifier = (isset($categories[$i]->attributes()->indentifier)) ? $categories[$i]->attributes()->indentifier : '';

				// If the category is the default
				if ($categoryDbName == $constPanelPlayerInformationDefaultCategory)
				{
					// Check if an user exists
					$userQuery = $PdoQuery->query("SELECT $categoryIndentifier FROM $categoryDbName WHERE $categoryIndentifier=$_SESSION[steamId]");
					$resultQuery = (count($userQuery) > 0) ? true : false;
					break;
				}
			}

			if (!$resultQuery): 
		?>

		<main class="animated fadeIn">
			<h1 style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); font-size: 72px"><?= $playerInformation_noDataFound ?> &#x1F622</h1>
		</main>

		<?php else: ?>

		<main class="container animated fadeIn mt-4 mb-4">
			<div id="playerInformation-searcher" class="inner-addon left-addon d-none">
                <input id="searchTextBox" class="form-control" type="text" placeholder="<?= $generic_findData ?>">
                <i class="icon-search"></i>
            </div>

			<hr>
			
			<?php
			// *** -------------------- (Please do not touch these lines) -------------------- ***
			$index = 0;

			// Display all the categories
			for ($i = 0; $i < $categoriesCount; $i++)
			{
				// Get the category dbname
				$categoryDbName = $categories[$i]->attributes()->dbName;
				$categoryIndentifier = (isset($categories[$i]->attributes()->indentifier)) ? $categories[$i]->attributes()->indentifier : '';
				$categoryIndentifierType = (isset($categories[$i]->attributes()->indentifierType)) ? $categories[$i]->attributes()->indentifierType : 'string';
				$categoryListing = (isset($categories[$i]->attributes()->listing)) ? $categories[$i]->attributes()->listing : 'string';

				if ($categoryDbName == $_GET['category'])
				{						
					// If the listing type is a list
					if ($categoryListing == 'list')
					{
						// Get the category information
						$categoryListDatabaseString = '';
						$dataItems = $categories[$i]->data;
						$dataItemsCount = count($dataItems);
						$categoryExceptions = (isset($categories[$i]->attributes()->exceptions)) ? $categories[$i]->attributes()->exceptions : [];
						if ($categoryExceptions != []) $categoryExceptions = explode(',', $categoryExceptions);

						// Construct the database query and the data items array
						for ($j = 0; $j < $dataItemsCount; $j++) {
							if ($categoryListDatabaseString == '') $categoryListDatabaseString = $dataItems[$j]->attributes()->dbName;
							else $categoryListDatabaseString .= ','.$dataItems[$j]->attributes()->dbName;
						}
						if ($categoryListDatabaseString == '') exit;

						// Get the datas
						$dataQuery = ($categoryIndentifier == '') ? $PdoQuery->query("SELECT $categoryListDatabaseString FROM $categoryDbName") : $PdoQuery->query("SELECT $categoryListDatabaseString FROM $categoryDbName WHERE $categoryIndentifier=$_SESSION[steamId]");
						$dataQueryCount = count($dataQuery);

						// Iterate over all the datas
						for ($j = 0; $j < $dataQueryCount; $j++) 
						{
							// Get the data in the selected array
							$dataArray = $dataQuery[$j];
							$dataArray = array_values($dataArray);
							$dataArrayCount = count($dataArray);
							
							// If the data is not in the exceptions
							if (!in_array(trim($dataArray[0], " \t\n\r\0\x0B`'\""), $categoryExceptions))
							{
								// Setup the displays variables
								$dataName = App\Parser\Dictionnary::value(trim($dataArray[0], " \t\n\r\0\x0B`'\""));
								$data = '';

								// Build the data to display
								for ($k = 1; $k < $dataArrayCount; $k++) 
								{
									$dataParsed = App\Parser\Dictionnary::value(trim($dataArray[$k], " \t\n\r\0\x0B`'\""));

									// Get the parsed value with the beautifier
									if (isset($dataItems[$k]->attributes()->method))
									{
										$Beautifier = new App\Parser\Beautifier(strval($dataItems[$k]->attributes()->method));
										$dataParsed = $Beautifier->parse($dataParsed);
									}

									if ($data == '') $data = $dataParsed;
									else $data .= '<br>'.$dataParsed;
								}

								// Display the information
								$iconHtml = isset($categories[$i]->attributes()->icon) ? '<i class="icon-'.$categories[$i]->attributes()->icon.' mr-1"></i>' : '';
								echo "<div class=\"information-container m-0 row mb-4\"><div class=\"information-title col-12 col-sm-6\"><h3 class=\"p-0 mb-0\">$iconHtml $dataName</h3></div><div class=\"information-content align-self-center col-12 col-sm-6\" onclick='copyValueToClipboard(\"element$index\")'><p id='element$index' class=\"p-0 mb-0\">$data</p></div></div>";
								$index++;
							}
						}
					}
					else
					{
						// Get the category datas to display
						$dataToDisplay = $categories[$i]->data;
						$dataToDisplayCount = count($dataToDisplay);
	
						// Display all the datas
						for ($j = 0; $j < $dataToDisplayCount; $j++)
						{
							// Get all the data information
							$dataDbName = $dataToDisplay[$j]->attributes()->dbName;
							$dataName = $dataToDisplay[$j]->attributes()->name;
							$categoryIndentifierValue = '';
							$data = '';

							// If the cache indentfier value is set or no
							if ($categoryIndentifierValue == '')
							{
								if ($categoryIndentifierType == 'string')
									$categoryIndentifierValue = $_SESSION['steamId'];
								else
								{
									// Get the indentifier data from the database
									$indentifierQuery = $PdoQuery->query("SELECT $categoryIndentifier,id FROM $categoryDbName");
									$indentifierQueryCount = count($indentifierQuery);
									$indentifierQueryRegex = ['/[^\]\[]+/i'];

									for ($k = 0; $k < $indentifierQueryCount; $k++)
									{
										// If the regex match
										if (preg_match($indentifierQueryRegex[0], $indentifierQuery[$k]['members']))
										{
											// Apply the regex on the value
											$indentifierValue = [];
											preg_match_all($indentifierQueryRegex[0], $indentifierQuery[$k]['members'], $indentifierValue);
											$indentifierValue = $indentifierValue[0];
											$indentifierValueCount = count($indentifierValue);

											// Try to find the PID
											for ($l = 0; $l < $indentifierValueCount; $l++) 
											{
												// Get the members value
												$indentifierValueArray = explode(',', $indentifierValue[$l]);
												$indentifierValueArrayCount = count($indentifierValueArray);

												// Iterate over all the members
												for ($m = 0; $m < $indentifierValueArrayCount; $m++) 
												{
													if ($indentifierValueArray[$m] != '"' && $indentifierValueArray[$m] != ',' && trim($indentifierValueArray[$m], " \t\n\r\0\x0B`'\"") == $_SESSION['steamId']) 
													{
														// Get the id of the row
														$categoryIndentifierValue = $indentifierQuery[$k]['id'];
														break;
													}
												}
											}
										}
									}
								}
							}

							// If indentifier type equal a string
							if ($categoryIndentifierType == 'string')
								$data = $PdoQuery->query("SELECT $dataDbName FROM $categoryDbName WHERE $categoryIndentifier=$categoryIndentifierValue")["$dataDbName"];
							else
								$data = $PdoQuery->query("SELECT $dataDbName FROM $categoryDbName WHERE id=$categoryIndentifierValue")["$dataDbName"];

							if (trim(gettype($data), " \t\n\r\0\x0B`'\"") == 'NULL')
								$data = App\Parser\Dictionnary::value('noData');
							else 
							{
								// If a method exists, invoke the parser
								if (isset($dataToDisplay[$j]->attributes()->method))
								{
									$Beautifier = new App\Parser\Beautifier(strval($dataToDisplay[$j]->attributes()->method));
									$data = $Beautifier->parse($data);
								}

								$data = App\Parser\Dictionnary::value($data);
							}

							$data = App\Parser\Dictionnary::value($data);
	
							// Display the information
							$iconHtml = isset($dataToDisplay[$j]->attributes()->icon) ? '<i class="icon-'.$dataToDisplay[$j]->attributes()->icon.' mr-1"></i>' : '';
							echo "<div class=\"information-container m-0 row mb-4\"><div class=\"information-title col-12 col-sm-6\"><h3 class=\"p-0 mb-0\">$iconHtml $dataName</h3></div><div class=\"information-content align-self-center col-12 col-sm-6\" onclick='copyValueToClipboard(\"element$index\")'><p id=\"element$index\" class=\"p-0 mb-0\">$data</p></div></div>";
							$index++;
						}
					}
			
					break;
				}
			}
			// *** --------------------------------------------------------------------------- ***
			?>
		</main>
		<!-- ** END - MAIN ** -->
		<?php endif; ?>

		<!-- ** FOOTER ** -->
		<?php include 'include/footer.php'; ?>
        <!-- ** END - FOOTER ** -->

		<script>
			// *** -------------------- (Please do not touch these lines) -------------------- ***
			$('#playerInformation-searcher').removeClass('d-none');

			toastr.options =
			{
				"closeButton": true,
				"debug": false,
				"newestOnTop": true,
				"progressBar": true,
				"positionClass": "toast-top-right",
				"preventDuplicates": false,
				"onclick": null,
				"showDuration": "300",
				"hideDuration": "1000",
				"timeOut": "5000",
				"extendedTimeOut": "1000",
				"showEasing": "swing",
				"hideEasing": "linear",
				"showMethod": "fadeIn",
				"hideMethod": "fadeOut"
			}

			$(function () {
				$('[data-toggle="tooltip"]').tooltip()
			});

			document.getElementById('searchTextBox').onkeyup = (elementName) => 
			{
				// Get all the text elements
				const headerElements = document.getElementsByTagName('h3');
				const headerElementsCount = headerElements.length;

				// Search on all the headerElements
				for (let i = 0; i < headerElementsCount; i++) 
				{
					if (headerElements[i].textContent.match(new RegExp(elementName.target.value, 'gi'))) {
						headerElements[i].parentElement.parentElement.classList.remove('d-none');
					}
					else {
						headerElements[i].parentElement.parentElement.classList.add('d-none');
					}
				}
			};

			const copyValueToClipboard = (elementId) =>
			{
				// Get the value to copy
				var valueToCopy = '';
				// Get all the child nodes
				var valueToCopyElements = document.getElementById(elementId).childNodes;
				const valueToCopyElementsCount = valueToCopyElements.length;

				// Construct the string value to copy
				for (let i = 0; i < valueToCopyElementsCount; i++) 
				{
					if (valueToCopyElements[i].nodeName == '#text')
					{
						// If the text is blank, don't use it
						if (!valueToCopyElements[i].data.trim() == '')
						{
							if (valueToCopy == '') 
								valueToCopy = valueToCopyElements[i].data; 
							else 
								valueToCopy += ' ' + valueToCopyElements[i].data;
						}
					}
					else if (valueToCopyElements[i].nodeName == 'CANVAS')
					{
						// Get the value of the custom attribute rgbColorText
						if (valueToCopy == '') 
							valueToCopy = valueToCopyElements[i].getAttribute('rgbColorText'); 
						else 
							valueToCopy += ' ' + valueToCopyElements[i].getAttribute('rgbColorText');
					}
				}

				// Create the textarea element
				const el = document.createElement('textarea');

				// Set the value to copy
				el.value = valueToCopy;
				el.setAttribute('readonly', '');
				// Set the attribute of the textarea
				el.style.position = 'absolute';
				el.style.left = '-20000px';

				// Append it to the body
				document.body.appendChild(el);
				el.select();

				// Exec the command copy
				document.execCommand('copy');
				document.body.removeChild(el);

				// Set a toastr info
				toastr.info('<?= App\Parser\Dictionnary::value('valueCopy') ?>', 'User Panel');
			};
			// *** --------------------------------------------------------------------------- ***
		</script>
	</body>
</html>