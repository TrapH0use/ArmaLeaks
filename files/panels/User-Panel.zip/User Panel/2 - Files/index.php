<!--
    Author: Thomas Croizet "Steez"
    Teamspeak 3: ts.the-programmer.com
    Web site: www.the-programmer.com

    Terms of use:
      - This file is forbidden unless you have permission from the author. If you have this file without permission to use it please do not use it and do not share it.
      - If you have permission to use this file, you can use it on your server however it is strictly forbidden to share it.
      - Out of respect for the author please do not delete this information.
-->

<?php
// *** -------------------- (Please do not touch these lines) -------------------- ***
// Require the PHP scripts
require 'config/constant.php';
require "app/steamAuth.php";
require "app/pdo.php";
session_start();

if (!is_dir('news')) {
	mkdir('news', 0777);
	chmod('news', 0777);
}
if (!is_dir('guide')) {
	mkdir('guide', 0777);
	chmod('guide', 0777);
}
if (!is_dir('gallery')) {
	mkdir('gallery', 0777);
	chmod('gallery', 0777);
}

// Setup the settings
$steamAuthConfig = array(
    'apikey' => $constSteamApiKey, // Steam API KEY
    'domainname' => '', // Displayed domain in the login-screen
    'loginpage' => '', // Returns to last page if not set
    'logoutpage' => '',
    'skipAPI' => false, // true = dont get the data from steam, just return the steamid64
);

// If the steamid is set
if (isset($_GET['steamId']))
{
	// Set the cookie and rediect automaticly the user
	setCookie('steamId', $_GET['steamId'], (time() + 60 * 60 * 24 * 30), '/', $_SERVER['HTTP_HOST'], false, true);
	header("Location: panel.php");
	exit;
}

if (isset($_COOKIE['steamId']))
{
	// Check if the player is in the database
	$steamId = $_COOKIE['steamId'];
	$PdoQuery = new App\PdoQuery($constPdoDatabaseName);
	$queryPid = $PdoQuery->query("SELECT pid FROM players WHERE pid=$steamId");

	// Redirect to the panel
	if (count($queryPid) > 0)
		header("Location: panel.php");
}

// Create the SteamAuth object
$steam = new App\SteamAuth($steamAuthConfig);
// If the user is logged
if ($steam->loggedIn())
{
	// If the cookie is not set, create it!
	if (!isset($_COOKIE['steamId']))
		setCookie('steamId', $_SESSION['steamdata']['steamid'], (time() + 60 * 60 * 24 * 30), '/', $_SERVER['HTTP_HOST'], false, true);

	// Check if the player is in the database
	$steamId = $_SESSION['steamdata']['steamid'];
	$PdoQuery = new App\PdoQuery($constPdoDatabaseName);
	//$queryPid = $PdoQuery->query("SELECT pid FROM players WHERE pid=$steamId");

	// Redirect to the panel
	//if (count($queryPid) > 0)
	header("Location: panel.php");
}
// *** --------------------------------------------------------------------------- ***
?>

<!DOCTYPE html>
<html lang="fr">
	<head>
		<title><?= $generic_namePanel ?> - <?= $generic_login ?></title>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="Example of a description">
		<meta name="keywords" content="user, panel, theprogrammer">
		<meta name="author" content="The Programmer">
		<meta name="twitter:site" content="User Panel">
		<meta name="twitter:title" content="User Panel">
		<meta name="twitter:description" content="Example of a description">
		<meta name="twitter:creator" content="The Programmer">
		<meta property="og:title" content="User Panel"/>
		<meta property="og:type" content="Web site"/>
		<meta property="og:url" content="https://example-userpanel.com"/>
		<meta property="og:description" content="Example of a description"/>
		<meta property="og:site_name" content="User Panel"/>
		<meta name="robots" content="index, follow"/>
		<meta name="reply-to" content="example@userpanel.com">
		<meta name="copyright" content="The Programmer">
		
		<?php include 'include/header.php'; ?>
		<link rel="stylesheet" href="css/login.css">
	</head>

	<body class="animated fadeIn">
		<!-- ** HEADER ** -->
		<main class="container h-100">
			<div class="row h-100">
				<div class="col-12 my-auto">
					<h1><?= $generic_namePanel ?></h1>
					<h2><?= $generic_welcomeLoginMessage ?></h2>
					<a href="<?= $steam->loginUrl() ?>"><?= $generic_login ?></a>
				</div>

				<div class="col-12">
					<!-- ** FOOTER ** -->
					<footer>
						<p><?= $generic_namePanel ?> <?= $generic_allRightReserved ?></p>
					</footer>
					<!-- ** END - FOOTER ** -->
				</div>
			</div>
		</main>	
	</body>
</html>