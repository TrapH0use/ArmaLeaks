<!--
    Author: Thomas Croizet "Steez"
    Teamspeak 3: ts.the-programmer.com
    Web site: www.the-programmer.com

    Terms of use:
      - This file is forbidden unless you have permission from the author. If you have this file without permission to use it please do not use it and do not share it.
      - If you have permission to use this file, you can use it on your server however it is strictly forbidden to share it.
      - Out of respect for the author please do not delete this information.
-->

<?php
// *** -------------------- (Please do not touch these lines) -------------------- ***
require 'config/constant.php';
require "app/pdo.php";
require "app/Parser/beautifier.php";
session_start();

if (isset($_GET['steamId']))
{
	// Set the cookie and rediect automaticly the user
	setCookie('steamId', $_GET['steamId'], (time() + 60 * 60 * 24 * 30), '/', $_SERVER['HTTP_HOST'], false, true);
	header("Location: panel.php");
	exit;
}

// If the cookie steamId is not set
if (!isset($_COOKIE['steamId']))
	header('Location: index.php');

// Set the steamId session variable
$_SESSION['steamId'] = $_COOKIE['steamId'];

// Reset the cookie
setCookie('steamId', $_SESSION['steamId'], (time() + 60 * 60 * 24 * 30), '/', $_SERVER['HTTP_HOST'], false, true);
// *** --------------------------------------------------------------------------- ***
?>

<!DOCTYPE html>
<html lang="fr">
	<head>
		<title><?= $generic_namePanel ?> - <?= $navbar_usefulInformation ?></title>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="Example of a description">
		<meta name="keywords" content="user, panel, theprogrammer">
		<meta name="author" content="The Programmer">
		<meta name="twitter:site" content="User Panel">
		<meta name="twitter:title" content="User Panel">
		<meta name="twitter:description" content="Example of a description">
		<meta name="twitter:creator" content="The Programmer">
		<meta property="og:title" content="User Panel"/>
		<meta property="og:type" content="Web site"/>
		<meta property="og:url" content="https://example-userpanel.com"/>
		<meta property="og:description" content="Example of a description"/>
		<meta property="og:site_name" content="User Panel"/>
		<meta name="robots" content="index, follow"/>
		<meta name="reply-to" content="example@userpanel.com">
		<meta name="copyright" content="The Programmer">

		<link rel="stylesheet" href="css/panel.css?<?= time() ?>">
		<?php include 'include/header.php'; ?>
	</head>

    <body>
        <!-- ** NAVBAR ** -->
		<?php include 'include/navbar.php'; ?>
		<!-- ** END - NAVBAR ** -->

		<!-- ** MAIN ** -->
		<main class="container animated fadeIn mt-4 mb-4">
			<!-- Main information -->

			<!-- -------------------- (Please do not touch these lines) -------------------- -->
            <article class="information-container mb-4">
				<div class="information-title" style="border-radius: 5px 5px 0px 0px; border-right: 0px;">
					<h3 class="p-0 mb-0"><i class="icon-info mr-1"></i> <?= $usefulInformation_mainInformation ?></h3>
				</div>

				<div class="information-content-no-hover">
					<div class="row m-0 p-0">
						<div class="col-12 col-sm-6 p-0">
							<p class="lead mb-3"><?= $usefulInformation_gameInformation ?></p>

							<p class="mb-1"><?= $usefulInformation_serverName ?><?= $constInformationNameServer ?></p>
							<p class="mb-1"><?= $usefulInformation_serverIp ?><a class="link" href="steam:rungameid/107410"><?= $constInformationIpServer ?></a></p>
							<p class="mb-1"><?= $usefulInformation_serverPort ?><?= $constInformationPortServer ?></p>
							<p class="mb-1"><?= $usefulInformation_serverPassword ?><?= $constInformationPasswordServer ?></p>
						</div>

						<div class="col-12 col-sm-6 p-0">
							<p class="lead mb-3"><?= $usefulInformation_socialLinks ?></p>

							<?php if ($constInformationTeamspeakAddress != ''): ?>
							<p class="mb-1"><?= $usefulInformation_linkTeamspeak ?><a class="link" href="<?= $constInformationTeamspeakAddress ?>"><?= $constInformationTeamspeakAddress ?></a></p>
							<?php endif ?>

							<?php if ($constInformationDiscordAddress != ''): ?>
							<p class="mb-1"><?= $usefulInformation_linkDiscord ?><a class="link" href="<?= $constInformationDiscordAddress ?>" target="_blank"><?= $constInformationDiscordAddress ?></a></p>
							<?php endif ?>

							<?php if ($constInformationFacebookPage != ''): ?>
							<p class="mb-1"><?= $usefulInformation_linkFacebook ?><a class="link" href="<?= $constInformationFacebookPage ?>" target="_blank"><?= $constInformationFacebookPage ?></a></p>
							<?php endif ?>

							<?php if ($constInformationTwitterAccount != ''): ?>
							<p class="mb-1"><?= $usefulInformation_linkTwitter ?><a class="link" href="<?= $constInformationTwitterAccount ?>" target="_blank"><?= $constInformationTwitterAccount ?></a></p>
							<?php endif ?>

							<?php if ($constInformationYoutubeAccount != ''): ?>
							<p class="mb-1"><?= $usefulInformation_linkYoutube ?><a class="link" href="<?= $constInformationYoutubeAccount ?>" target="_blank"><?= $constInformationYoutubeAccount ?></a></p>
							<?php endif ?>

							<?php if ($constInformationTwitchAccount != ''): ?>
							<p class="mb-1"><?= $usefulInformation_linkTwitch ?><a class="link" href="<?= $constInformationTwitchAccount ?>" target="_blank"><?= $constInformationTwitchAccount ?></a></p>
							<?php endif ?>
						</div>
					</div>
				</div>
			</article>

			<?php if ($constInformationLauncherPath != '' || $constInformationTaskforceTeamspeakPath != ''): ?>
			<hr>
			<?php endif ?>

			<?php if ($constInformationLauncherPath != ''): ?>

			<article class="information-container mt-4 mb-4">
				<div class="information-title" style="border-radius: 5px 5px 0px 0px; border-right: 0px;">
					<h3 class="p-0 mb-0"><i class="icon-download mr-1"></i> <?= $usefulInformation_downloadLauncher ?></h3>
				</div>

				<div class="information-content-no-hover">
					<p class="mb-3"><?= $usefulInformation_downloadLauncherDescription ?></p>

					<a class="link" href="<?= $constInformationLauncherPath ?>" download><?= $usefulInformation_downloadLauncherAction ?></a>
				</div>
			</article>
			<?php endif ?>
			
			<?php if ($constInformationTaskforceTeamspeakPath != ''): ?>
			<article class="information-container mt-4 mb-4">
				<div class="information-title" style="border-radius: 5px 5px 0px 0px; border-right: 0px;">
					<h3 class="p-0 mb-0"><i class="icon-download mr-1"></i> <?= $usefulInformation_downloadTfrPlugin ?></h3>
				</div>

				<div class="information-content-no-hover">
					<p class="mb-3"><?= $usefulInformation_downloadTfrPluginDescription ?></p>

					<a class="link" href="<?= $constInformationTaskforceTeamspeakPath ?>" download><?= $usefulInformation_downloadTfrPluginAction ?></a>
				</div>
			</article>
			<?php endif ?>
			<!-- --------------------------------------------------------------------------- -->
		</main>
		<!-- ** END - MAIN ** -->

		<!-- ** FOOTER ** -->
		<?php include 'include/footer.php'; ?>
        <!-- ** END - FOOTER ** -->
    </body>
</html>