<footer class="mt-auto text-center">
    <p class="pt-2 pb-2 mb-0"><?= $generic_namePanel ?> <?= $generic_allRightReserved ?></p>
</footer>