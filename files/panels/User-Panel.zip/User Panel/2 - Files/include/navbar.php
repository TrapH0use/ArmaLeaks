<!--
    Author: Thomas Croizet "Steez"
    Teamspeak 3: ts.the-programmer.com
    Web site: www.the-programmer.com

    Terms of use:
      - This file is forbidden unless you have permission from the author. If you have this file without permission to use it please do not use it and do not share it.
      - If you have permission to use this file, you can use it on your server however it is strictly forbidden to share it.
      - Out of respect for the author please do not delete this information.
-->

<!-- -------------------- (Please do not touch these lines) -------------------- -->
<?php if (in_array($_SESSION['steamId'], $constPanelAdminUsers)): ?>

<?php require 'modal.php'; ?>

<?php endif ?>
<!-- --------------------------------------------------------------------------- -->

<nav class="navbar navbar-expand-xl navbar-dark bg-custom" style="white-space:nowrap;">
    <a class="navbar-brand p-0" href="panel.php"><img src="img/favicon.png" width="30" height="30" alt=""><span class="ml-2"><?= $generic_namePanel ?></span></a>

    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item dropdown">
                <a id="navbarPlayerInformationDropdown" class="nav-link dropdown-toggle" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="icon-info mr-1"></i>
                    <span><?= $navbar_playerInformation ?></span>
                </a>

                <div class="dropdown-menu" aria-labelledby="navbarPlayerInformationDropdown">
                    <?php
                    // *** -------------------- (Please do not touch these lines) -------------------- ***
                    $constPanelPlayerInformationConfigString = file_get_contents(dirname(dirname(__FILE__)).'/config/playerInformation.xml');

                    // Get all the categories from the config
                    $constPanelConfigXml = simplexml_load_string($constPanelPlayerInformationConfigString);
                    $categories = $constPanelConfigXml->category;
                    $categoriesCount = count($categories);

                    // Display all the categories
                    for ($i = 0; $i < $categoriesCount; $i++) 
                    {
                        $categoryDisplayName = $categories[$i]->attributes()->name;
                        $categoryDbName = $categories[$i]->attributes()->dbName;
                        $categoryIcon = (isset($categories[$i]->attributes()->icon)) ? $categories[$i]->attributes()->icon : '';
                        echo "<a class='nav-dropdown-link dropdown-item' href='playerInformation.php?category=$categoryDbName'><i class='icon-$categoryIcon mr-2'></i><span>$categoryDisplayName</span></a>";
                    }
                    // *** --------------------------------------------------------------------------- ***
                    ?>
                </div>
            </li>

            <li class="nav-item"><a class="nav-link" href="leaderboard.php"><i class="icon-list mr-2"></i><span><?= $navbar_leaderboard ?></span></a></li>

            <li class="nav-item"><a class="nav-link" href="gallery.php"><i class="icon-image mr-2"></i><span><?= $navbar_gallery ?></span></a></li>

            <li class="nav-item"><a class="nav-link" href="news.php"><i class="icon-columns mr-2"></i><span><?= $navbar_news ?></span></a></li>

            <li class="nav-item"><a class="nav-link" href="guide.php"><i class="icon-book mr-2"></i><span><?= $navbar_guide ?></span></a></li>

            <li class="nav-item"><a class="nav-link" href="information.php"><i class="icon-info mr-2"></i><span><?= $navbar_usefulInformation ?></span></a></li>

            <?php if ($constForumUrl != ''): ?>

            <li class="nav-item"><a class="nav-link" href="<?= $constForumUrl ?>"><i class="icon-external-link mr-2"></i><span><?= $navbar_forum ?></span></a></li>

            <?php endif ?>
        </ul>
        
        <a id="disconnect" class="nav-link navbar-line" href="disconnect.php"><i class="icon-user-x mr-2"></i><span><?= $navbar_disconnect ?></span></a>

        <?php if (in_array($_SESSION['steamId'], $constPanelAdminUsers)): ?>

        <a id="adminButton" class="nav-link pl-0 pl-xl-3" href="#" data-toggle="modal" data-target="#adminModal"><i class="icon-user mr-2"></i><span><?= $navbar_admin ?></span></a>

        <?php endif ?>
    </div>
</nav>

<script>
/*jQuery(function ($) {
    $.fn.hScroll = function (amount) {
        amount = amount || 120;
        $(this).bind("DOMMouseScroll mousewheel", function (event) {
            var oEvent = event.originalEvent, 
                direction = oEvent.detail ? oEvent.detail * -amount : oEvent.wheelDelta, 
                position = $(this).scrollLeft();
            position += direction > 0 ? -amount : amount;
            $(this).scrollLeft(position);
            event.preventDefault();
        })
    };
});
$(document).ready(function(){
    $("nav").hScroll();
});

$('.dropdown').on('show.bs.dropdown', function () {
    $('nav').css({
        overflow: 'visible',
    });
});

$('.dropdown').on('hidden.bs.dropdown', function () {
    $('nav').css({
        overflow: auto,
    });
});*/
</script>