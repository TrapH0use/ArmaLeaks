<!--
    Author: Thomas Croizet "Steez"
    Teamspeak 3: ts.the-programmer.com
    Web site: www.the-programmer.com

    Terms of use:
      - This file is forbidden unless you have permission from the author. If you have this file without permission to use it please do not use it and do not share it.
      - If you have permission to use this file, you can use it on your server however it is strictly forbidden to share it.
      - Out of respect for the author please do not delete this information.
-->

<!-- -------------------- (Please do not touch the complete file) -------------------- -->
<section id="adminModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="adminModal" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
        <div class="modal-content">
            <!-- Modal header -->
            <section class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle"><?= $adminModal_adminTools ?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </section>

            <!-- Modal content -->
            <section class="modal-body">
                <div style="height: 100%" class="row">
                    <div class="col-12 col-md-3 border-right">
                        <div class="border-top border-bottom">
                            <button type="button" class="mx-auto btn btn-link" onclick="admin_changePage('admin-homePage')"><?= $navbar_homePage ?></button>
                        </div>

                        <div class="border-bottom">
                            <button type="button" class="mx-auto btn btn-link" onclick="admin_changePage('admin-gallery')"><?= $navbar_gallery ?></button>
                        </div>

                        <div class="border-bottom">
                            <button type="button" class="mx-auto btn btn-link" onclick="admin_changePage('admin-news')"><?= $navbar_news ?></button>
                        </div>

                        <div class="border-bottom">
                            <button type="button" class="mx-auto btn btn-link" onclick="admin_changePage('admin-guide')"><?= $navbar_guide ?></button>
                        </div>
                    </div>

                    <!-- Admin tools -->
                    <div class="col-12 col-md-9">
                        <article id="none" class="d-none">
                            <p class="lead"><?= $adminModal_pageIntentionalyBlank ?></p>
                        </article>

                        <!-- Home Page tool -->
                        <article id="admin-homePage" class="">
                            <p class="lead mb-3"><?= $navbar_homePage ?></p>

                            <div id="admin-homePage-editor" class="mb-2"></div>

                            <button id="admin-homePage-setHomePageButton" class="btn btn-primary mb-5"><?= $adminModal_homePage_setHomePage ?></button>
                        </article>

                        <!-- Gallery tool -->
                        <article id="admin-gallery" class="d-none">
                            <!-- Upload images -->
                            <p class="lead mb-3"><?= $adminModal_gallery_uploadImage ?></p>

                            <div class="mb-2">
                                <div class="custom-file">
                                    <input id="admin-gallery-imageToUploadFiles" type="file" class="custom-file-input" multiple>
                                    <label id="admin-gallery-imageToUploadLabel" class="custom-file-label" for="admin-gallery-imageToUpload"><?= $adminModal_chooseFile ?></label>
                                    <small id="admin-gallery-imageToUploadHelp" class="form-text text-muted"><?= $adminModal_gallery_imageFileType ?></small>
                                </div>
                            </div>

                            <div class="mb-2">
                                <input id="admin-gallery-shortDescriptionText" class="form-control" type="text" placeholder="<?= $adminModal_gallery_shortDescriptionPlaceholder ?>">
                                <small id="admin-gallery-shortDescriptionHelp" class="form-text text-muted"><?= $adminModal_gallery_maxShortDescriptionLength ?></small>
                            </div>

                            <div class="mb-2">
                                <input id="admin-gallery-longDescriptionText" class="form-control" type="text" placeholder="<?= $adminModal_gallery_longDescriptionPlaceholder ?>">
                                <small id="admin-gallery-longDescriptionHelp" class="form-text text-muted"><?= $adminModal_gallery_maxLongDescriptionLength ?></small>
                            </div>

                            <button id="admin-gallery-uploadImagesButton" class="btn btn-primary mb-5"><?= $adminModal_gallery_uploadImage ?></button>


                            <!-- Delete images -->
                            <p class="lead mb-3"><?= $adminModal_gallery_deleteImages ?></p>

                            <div id="admin-gallery-imageList" class="mb-2">
                                <?php
                                // Get the gallery images
                                $path = dirname(__DIR__).'/gallery';
                                $images = scandir($path);
                                sort($images,  SORT_NATURAL);
                                $imagesCount = count($images);

                                for ($i = 0; $i < $imagesCount; $i++) 
                                {
                                    if (!in_array($images[$i], ['.', '..']) && strpos($images[$i], '.xml') === false) 
                                    {
                                        // Read the XML
                                        $imageXml = new SimpleXMLElement(file_get_contents("$path/".pathinfo($images[$i])['filename'].'.xml'));
                                        // Get the short description
                                        $shortDescription = $imageXml->shortDescription;
                                        
                                        // Write the result
                                        echo ($i == 2) ? "<p id=\"deleteImage-$images[$i]\" class=\"border-top border-bottom list-link\" onclick=\"gallery_deleteImage('$images[$i]')\">$images[$i] - $shortDescription</p>" : "<p id=\"deleteImage-$images[$i]\" class=\"border-bottom list-link\" onclick=\"gallery_deleteImage('$images[$i]')\">$images[$i] - $shortDescription</p>";
                                    }
                                }
                                ?>
                            </div>
                        </article>

                        <!-- News tool -->
                        <article id="admin-news" class="d-none">
                            <!-- Upload News -->
                            <p class="lead mb-3"><?= $adminModal_news_writeNews ?></p>

                            <select id="admin-news-chooseNews" class="custom-select mb-2">
                                <option value="" selected hidden disabled><?= $adminModal_news_chooseNews ?></option>
                                <?php
                                // Get the gallery images
                                $path = dirname(__DIR__).'/news';
                                $news = scandir($path);
                                sort($news,  SORT_NATURAL);
                                $newsCount = count($news);

                                for ($i = 0; $i < $newsCount; $i++)
                                {
                                    if (!in_array($news[$i], ['.', '..']))
                                    {
                                        // Read the XML
                                        $newsXml = new SimpleXMLElement(file_get_contents("$path/".pathinfo($news[$i])['filename'].'.xml'));
                                        // Get the news information
                                        $newsName = $newsXml->newsName;
                                        $newsTag = $newsXml->newsTag;
                                        $newsContent = $newsXml->newsContent;

                                        echo "<option value=\"$news[$i]\" onclick=\"news_setNews(`$news[$i]`,`$newsTag`,`$newsName`)\">$newsName</option>";
                                    }
                                }
                                ?>
                            </select>

                            <select id="admin-news-chooseNewsTag" class="custom-select mb-2">
                                <option value="" selected disabled hidden><?= $adminModal_news_chooseNewsTag ?></option>
                                <?php 
                                $newsTagCount = count($constNewsTag);
                                // Get the keys and interact with them like an id
                                $newsTagKeys = array_keys($constNewsTag);

                                for ($i = 0; $i < $newsTagCount; $i++) {
                                    $newsTagDisplayName = $constNewsTag[$newsTagKeys[$i]][0];
                                    echo ($i == 0) ? "<option value=\"$newsTagKeys[$i]\" selected>$newsTagDisplayName</option>" : "<option value=\"$newsTagKeys[$i]\">$newsTagDisplayName</option>";
                                }
                                ?>
                            </select>

                            <div class="mb-2">
                                <input id="admin-news-nameNewsText" class="form-control" type="text" placeholder="<?= $adminModal_news_newsName ?>">
                                <small id="admin-news-nameNewsHelp" class="text-muted"><?= $adminModal_news_maxNewsNameLength ?></small>
                            </div>

                            <div id="admin-news-editor" class="mb-2"></div>

                            <button id="admin-news-uploadnewsButton" class="btn btn-primary mb-5"><?= $adminModal_news_uploadNews ?></button>

                            <!-- Delete images -->
                            <p class="lead mb-3"><?= $adminModal_news_deleteNews ?></p>

                            <div id="admin-news-newsList" class="mb-2">
                                <?php
                                for ($i = 0; $i < $newsCount; $i++) 
                                {
                                    if (!in_array($news[$i], ['.', '..'])) 
                                    {
                                        // Read the XML
                                        $newsXml = new SimpleXMLElement(file_get_contents("$path/".pathinfo($news[$i])['filename'].'.xml'));
                                        // Get the short description
                                        $newsName = $newsXml->newsName;
                                        
                                        // Write the result
                                        echo ($i == 2) ? "<p id=\"deleteNews-$news[$i]\" class=\"border-top border-bottom list-link\" onclick=\"news_deleteNews('$news[$i]')\">$news[$i] - $newsName</p>" : 
                                                         "<p id=\"deleteNews-$news[$i]\" class=\"border-bottom list-link\" onclick=\"news_deleteNews('$news[$i]')\">$news[$i] - $newsName</p>";
                                    }
                                }
                                ?>
                            </div>
                        </article>

                        <!-- Guide tool -->
                        <article id="admin-guide" class="d-none">
                            <!-- Create Guide class -->
                            <p class="lead mb-3"><?= $adminModal_guide_createGuideClass ?></p>

                            <input id="admin-guide-guideClassNameText" class="form-control mb-2" type="text" placeholder="<?= $adminModal_guide_guideClassName ?>">

                            <button id="admin-guide-createGuideClassName" class="btn btn-primary mb-5"><?= $adminModal_guide_createGuideClassName ?></button>

                            <?php
                            // Get the gallery images
                            $path = dirname(__DIR__).'/guide';
                            $guideCategories = scandir($path);
                            sort($guideCategories,  SORT_NATURAL);
                            $guideCategoriesCount = count($guideCategories);
                            ?>

                            <div id="admin-guide-masterDiv" <?= ($guideCategoriesCount != 2) ? '' : 'class="d-none"' ?>>
                                <!-- Write Guide -->
                                <p class="lead mb-3"><?= $adminModal_guide_writeGuide ?></p>

                                <select id="admin-guide-chooseGuideClassName" class="custom-select mb-2">
                                    <?php 
                                    for ($i = 0; $i < $guideCategoriesCount; $i++)
                                        if ($guideCategories[$i] != '.' && $guideCategories[$i] != '..')
                                        echo ($i == 2) ? "<option value=\"$guideCategories[$i]\" selected>$guideCategories[$i]</option>" : 
                                                         "<option value=\"$guideCategories[$i]\">$guideCategories[$i]</option>";
                                    ?>
                                </select>

                                <select id="admin-guide-chooseGuide" class="custom-select mb-2">
                                </select>

                                <div class="mb-2">
                                    <input id="admin-guide-guideNameText" class="form-control" type="text" placeholder="<?= $adminModal_guide_guideName ?>">
                                    <small id="admin-guide-guideNameHelp" class="text-muted"><?= $adminModal_guide_maxGuideNameLength ?></small>
                                </div>

                                <div id="admin-guide-editor" class="mb-2"></div>

                                <button id="admin-guide-uploadGuideButton" class="btn btn-primary mb-5"><?= $adminModal_guide_uploadGuide ?></button>

                                <!-- Delete guide -->
                                <p class="lead mb-3"><?= $adminModal_guide_deleteGuide ?></p>

                                <div class="mb-5">
                                <?php
                                for ($i = 0; $i < $guideCategoriesCount; $i++) 
                                {
                                    if ($guideCategories[$i] != '.' && $guideCategories[$i] != '..')
                                    {
                                        $guidesInCategory = scandir($path."/$guideCategories[$i]");
                                        $guidesInCategory = array_splice($guidesInCategory, 2);
                                        $guidesInCategoryCount = count($guidesInCategory);

                                        for ($j = 0; $j < $guidesInCategoryCount; $j++) {
                                            $guideXml = new SimpleXMLElement(file_get_contents("$path/$guideCategories[$i]/".pathinfo($guidesInCategory[$j])['filename'].'.xml'));
                                            $guideName = strval($guideXml->guideName);
                                            echo ($j == 0) ? "<p id=\"deleteGuideName-$guideCategories[$i]-$guidesInCategory[$j]\" class=\"border-top border-bottom list-link\" onclick=\"guide_deleteGuides(`$guideCategories[$i]`, `$guidesInCategory[$j]`)\">$guidesInCategory[$j] - $guideName - $adminModal_guide_category : $guideCategories[$i]</p>" : 
                                                             "<p id=\"deleteGuideName-$guideCategories[$i]-$guidesInCategory[$j]\" class=\"border-top border-bottom list-link\" onclick=\"guide_deleteGuides(`$guideCategories[$i]`, `$guidesInCategory[$j]`)\">$guidesInCategory[$j] - $guideName - $adminModal_guide_category : $guideCategories[$i]</p>";
                                        }
                                    }
                                }
                                ?>
                                </div>

                                <!-- Delete Guide class -->
                                <p class="lead mb-3"><?= $adminModal_guide_deleteGuideClass ?></p>

                                <div id="admin-guide-guideList" class="mb-2">
                                <?php
                                for ($i = 0; $i < $guideCategoriesCount; $i++)
                                    if ($guideCategories[$i] != '.' && $guideCategories[$i] != '..')
                                        echo ($i == 2) ? "<p id=\"deleteGuide-$guideCategories[$i]\" class=\"border-top border-bottom list-link\" onclick=\"guide_deleteGuidesClassName(`$guideCategories[$i]`)\">$adminModal_guide_category : $guideCategories[$i]</p>" : 
                                                         "<p id=\"deleteGuide-$guideCategories[$i]\" class=\"border-bottom list-link\" onclick=\"guide_deleteGuidesClassName(`$guideCategories[$i]`)\">$adminModal_guide_category : $guideCategories[$i]</p>";
                                ?>
                                </div>
                            </div>

                        </article>
                    </div>
                </div>
            </section>
        </div>
    </div>
</section>

<script>
toastr.options =
{
    "closeButton": true,
    "debug": false,
    "newestOnTop": true,
    "progressBar": true,
    "positionClass": "toast-top-right",
    "preventDuplicates": false,
    "onclick": null,
    "showDuration": "300",
    "hideDuration": "1000",
    "timeOut": "5000",
    "extendedTimeOut": "1000",
    "showEasing": "swing",
    "hideEasing": "linear",
    "showMethod": "fadeIn",
    "hideMethod": "fadeOut"
}

var previousPageId = 'admin-homePage';

const admin_changePage = (pageId) => 
{
    if (pageId != previousPageId) 
    {
        $(`#${pageId}`).removeClass('d-none');
        $(`#${previousPageId}`).addClass('d-none');

        previousPageId = pageId;
    }
}
</script>



<script>
var guideClassNameIsValid = true;
var guideNameIsValid = true;
var guideCreated = null;
var guideFileNameSelectedPrevious = null;
var guideClassNameOlder = null;
var guideNameOlder = null;
<?php
$path = dirname(__DIR__).'/guide';
$guideFiles = [];
$guideNames = [];
$guideContents = [];
$guideClassNames = [];
$guideCategories = array_slice(scandir($path), 2);
$guideCategoriesCount = count($guideCategories);

for ($i = 0; $i < $guideCategoriesCount; $i++)
{
    $guidesInGuideClassName = array_slice(scandir($path."/$guideCategories[$i]"), 2);
    $guidesInGuideClassNameCount = count($guidesInGuideClassName);

    for ($j = 0; $j < $guidesInGuideClassNameCount; $j++) 
    {
        // Read the XML
        $guideXml = new SimpleXMLElement(file_get_contents("$path/$guideCategories[$i]/".pathinfo($guidesInGuideClassName[$j])['filename'].'.xml'));
        // Push all the elements
        $guideFiles[] = $guidesInGuideClassName[$j];
        $guideNames[] = strval($guideXml->guideName);
        $guideContents[] = strval($guideXml->guideContent);
        $guideClassNames[] = strval($guideXml->guideClassName);
    }
}

echo 'guideCreated = '.json_encode(['guideFiles' => $guideFiles, 'guideNames' => $guideNames, 'guideContents' => $guideContents, 'guideClassNames' => $guideClassNames]);
?>
//** ADMIN GUIDE METHODS **//
var quillHomePage = new Quill('#admin-guide-editor', {
	modules: {
    	toolbar: [
			[{ 'header': [1, 2, 3, 4, 5, 6, false] }, { 'size': ['small', false, 'large', 'huge'] }], 
            ['bold', 'italic', 'underline', 'strike'],
            [{ align: '' }, { align: 'center' }, { align: 'right' }, { align: 'justify' }],
			[{ 'color': [] }, { 'background': [] }],
			[{ 'list': 'bullet' }, { 'list': 'ordered'}, 'code-block', 'blockquote'],
            [ 'link', 'image', 'video'],
		]
  	},
    theme: 'snow',
});

// Create a guide class name
$('#admin-guide-createGuideClassName').on('click', () => 
{
    // Check if the name is valid
    if (guideClassNameIsValid)
    {
        // Send the request
        $.ajax({
            type: 'POST', // define the type of HTTP verb we want to use (POST for our form)
            url: 'app/Admin/guide.php', // the url where we want to POST
            data: {createGuideClassName: $('#admin-guide-guideClassNameText').val()}, // our data object
            success: (result) => {
                if (result == 'true') {
                    // Update the chooseGuideClassName and show the masterDiv
                    $('#admin-guide-masterDiv').removeClass('d-none');
                    $('#admin-guide-chooseGuideClassName').append($('<option></option>').attr("value", $('#admin-guide-guideClassNameText').val()).text($('#admin-guide-guideClassNameText').val()));
                    document.getElementById('admin-guide-guideList').innerHTML += `<p id=\"deleteGuide-${$('#admin-guide-guideClassNameText').val()}\" class=\"border-bottom list-link\" onclick=\"guide_deleteGuidesClassName('${$('#admin-guide-guideClassNameText').val()}')\"><?= $adminModal_guide_category ?> : ${$('#admin-guide-guideClassNameText').val()}</p>`;

                    toastr.success("<?= $adminModal_guide_guideClassNameCreated ?>", '<?= $generic_namePanel ?>');
                }
                else {
                    toastr.warning("<?= $adminModal_guide_guideClassNameNotCreated ?>", '<?= $generic_namePanel ?>');
                    $('#admin-guide-guideClassNameText').removeClass('is-valid').addClass('is-invalid');
                }
            },
            error: () => {
                toastr.error('<?= $adminModal_internalError ?>', '<?= $generic_namePanel ?>');
            }
        });
    }
});

// Upload a guide
$('#admin-guide-uploadGuideButton').on('click', () => 
{
    // Check if the name is valid
    if (guideNameIsValid)
    {
        if (guideFileNameSelectedPrevious != null && guideNameOlder == $('#admin-guide-guideNameText').val())
        {
            // Save the older news
            $.ajax({
                type: 'POST', // define the type of HTTP verb we want to use (POST for our form)
                url: 'app/Admin/guide.php', // the url where we want to POST
                data: {guideFileName: guideFileNameSelectedPrevious, guideClassName: guideClassNameOlder, guideName: guideNameOlder, guideContent: document.getElementById('admin-guide-editor').childNodes[0].innerHTML}, // our data object
                success: (result) => {
                    toastr.success("<?= $adminModal_guide_guideUploaded ?>", '<?= $generic_namePanel ?>');
                },
                error: () => {
                    toastr.error("<?= $adminModal_internalError ?>", '<?= $generic_namePanel ?>');
                }
            });
        }
        else
        {
            // Send the request
            $.ajax({
                type: 'POST', // define the type of HTTP verb we want to use (POST for our form)
                url: 'app/Admin/guide.php', // the url where we want to POST
                data: {guideName: $('#admin-guide-guideNameText').val(), guideClassName: $('#admin-guide-chooseGuideClassName').val(), guideContent: document.getElementById('admin-guide-editor').childNodes[0].innerHTML}, // our data object
                success: (result) => {
                    guideFileNameSelectedPrevious = result;
                    guideClassNameOlder = $('#admin-guide-guideNameText').val();
                    toastr.success("<?= $adminModal_guide_guideUploaded ?>", '<?= $generic_namePanel ?>');
                },
                error: () => {
                    toastr.error('<?= $adminModal_internalError ?>', '<?= $generic_namePanel ?>');
                }
            });
        }
    }
});

$('#admin-guide-chooseGuideClassName').on('change', () => {
    guide_changeGuide();
});

// Check if the guide name is correct
$('#admin-guide-guideNameText').on('change', () => {
    // Get the news name
    const guideNames = $('#admin-guide-guideNameText').val();

    for (let i = 0; i < guideCreated.guideNames.length; i++)
    {
        if (guideNames == guideCreated.guideNames[i])
        {
            // Update the UI, no News Name
            $('#admin-guide-guideNameText').removeClass('is-valid').addClass('is-invalid');
            $('#admin-guide-guideNameHelp').addClass('invalid-feedback').removeClass('valid-feedback').removeClass('text-muted');

            guideNameIsValid = false;
            return;
        }
    }

    if (guideNames.length > <?= $constNewsMaxNameLength ?> || guideNames.length == 0) {
        // Update the UI, no News Name
        $('#admin-guide-guideNameText').removeClass('is-valid').addClass('is-invalid');
        $('#admin-guide-guideNameHelp').addClass('invalid-feedback').removeClass('valid-feedback').removeClass('text-muted');

        guideNameIsValid = false;
    }
    else {
        // Update the UI
        $('#admin-guide-guideNameText').removeClass('is-invalid').addClass('is-valid');
        $('#admin-guide-guideNameHelp').removeClass('text-muted').removeClass('invalid-feedback').addClass('valid-feedback');
        guideNameIsValid = true;
    }
});

// Check if the guide class name is correct
$('#admin-guide-guideClassNameText').on('change', () => {
    // Get the news name
    const guideClassName = $('#admin-guide-guideClassNameText').val();

    for (let i = 0; i < guideCreated.guideClassNames.length; i++)
    {
        if (guideClassName == guideCreated.guideClassNames[i])
        {
            // Update the UI, no News Name
            $('#admin-guide-guideClassNameText').removeClass('is-valid').addClass('is-invalid');

            guideClassNameIsValid = false;
            return;
        }
    }

    if (guideClassName.length > <?= $constNewsMaxNameLength ?> || guideClassName.length == 0) {
        // Update the UI, no News Name
        $('#admin-guide-guideClassNameText').removeClass('is-valid').addClass('is-invalid');

        guideClassNameIsValid = false;
    }
    else {
        // Update the UI
        $('#admin-guide-guideClassNameText').removeClass('is-invalid').addClass('is-valid');
        guideClassNameIsValid = true;
    }
});

const guide_setGuide = (guideClassName, guideName) => 
{
    // Get the news name
    guideNameOlder = $('#admin-guide-guideNameText').val();

    // Check the news name
    if (guideNameOlder.length > <?= $constNewsMaxNameLength ?> || guideNameOlder.length == 0 || !guideNameIsValid)
    {
        $('#admin-guide-guideNameText').val(guideName);
        for (let i = 0; i < guideCreated.guideNames.length; i++) {
            if (guideName == guideCreated.guideNames[i] && guideClassName == guideCreated.guideClassNames[i]) {
                // Update the news content
                document.getElementById('admin-guide-editor').childNodes[0].innerHTML = guideCreated.guideContents[i];
                guideFileNameSelectedPrevious = guideCreated.guideFiles[i];
                break;
            }
        }

        guideClassNameOlder = guideClassName;
        guideNameIsValid = true;
        guideNameOlder = guideName;

        // Update the UI
        $('#admin-guide-guideNameText').removeClass('is-invalid').addClass('is-valid');
        $('#admin-guide-guideNameHelp').removeClass('text-muted').removeClass('invalid-feedback').addClass('valid-feedback');
    }
    else 
    {
        // Confirm the choice
        if (confirm(`<?= $adminModal_guide_loadGuideAsk ?>`))
        {
            let guideContent = null;
            let newGuideFileNameSelectedPrevious = null;
            for (let i = 0; i < guideCreated.guideNames.length; i++) {
                if (guideName == guideCreated.guideNames[i] && guideClassName == guideCreated.guideClassNames[i]) {
                    // Update the news content
                    guideContent = guideCreated.guideContents[i];
                    newGuideFileNameSelectedPrevious = guideCreated.guideFiles[i];
                    break;
                }
            }

            // Save the older news
            $.ajax({
                type: 'POST', // define the type of HTTP verb we want to use (POST for our form)
                url: 'app/Admin/guide.php', // the url where we want to POST
                data: {guideFileName: guideFileNameSelectedPrevious, guideClassName: guideClassNameOlder, guideName: guideNameOlder, guideContent: document.getElementById('admin-guide-editor').childNodes[0].innerHTML}, // our data object
                success: (result) => {
                    $('#admin-guide-guideNameText').val(guideName);
                    document.getElementById('admin-guide-editor').childNodes[0].innerHTML = guideContent;
                    guideFileNameSelectedPrevious = newGuideFileNameSelectedPrevious;

                    toastr.success("<?= $adminModal_guide_guideUploaded ?>", '<?= $generic_namePanel ?>');
                },
                error: () => {
                    toastr.error("<?= $adminModal_internalError ?>", '<?= $generic_namePanel ?>');
                }
            });
        }
    }
}

const guide_changeGuide = () => 
{
    // Get the class name
    const guideClassName = $('#admin-guide-chooseGuideClassName').val();
    // Empty the guide to choose select
    $("#admin-guide-chooseGuide").empty();
    $("#admin-guide-chooseGuide").append($('<option></option>').attr({value: '', hidden: '', selected: '', disabled: ''}).text('<?= $adminModal_guide_chooseGuide ?>'));

    // Get all the guide in the class name
    for (let i = 0; i < guideCreated.guideNames.length; i++) {
        if (guideClassName == guideCreated.guideClassNames[i])
            $("#admin-guide-chooseGuide").append($('<option></option>').attr("value", guideCreated.guideNames[i]).text(guideCreated.guideNames[i]).on('click', () => { guide_setGuide(guideCreated.guideClassNames[i], guideCreated.guideNames[i]); }));
    }
}
guide_changeGuide();

const guide_deleteGuides = (guideClassName, guideName) => 
{
    if (confirm(`<?= $adminModal_guide_deleteGuideAsk ?>`))
    {
        // Send the request
        $.ajax({
            type: 'POST', // define the type of HTTP verb we want to use (POST for our form)
            url: 'app/Admin/guide.php', // the url where we want to POST
            data: {deleteGuideClassName: guideClassName, deleteGuideName: guideName}, // our data object
            success: (result) => {
                toastr.success("<?= $adminModal_guide_guideDeleted ?>", '<?= $generic_namePanel ?>');
                // Delete the node because the image is removed
                document.getElementById(`deleteGuideName-${guideClassName}-${guideName}`).remove();
            },
            error: () => {
                toastr.error('<?= $adminModal_internalError ?>', '<?= $generic_namePanel ?>');
            }
        });
    }
}

// Delete a guide class name
const guide_deleteGuidesClassName = (guideClassName) => 
{
    if (confirm(`<?= $adminModal_guide_deleteGuideClassNameAsk ?>`))
    {
        // Send the request
        $.ajax({
            type: 'POST', // define the type of HTTP verb we want to use (POST for our form)
            url: 'app/Admin/guide.php', // the url where we want to POST
            data: {deleteGuideClassName: guideClassName}, // our data object
            success: (result) => {
                toastr.success("<?= $adminModal_guide_guideClassNameDeleted ?>", '<?= $generic_namePanel ?>');
                // Delete the node because the image is removed
                document.getElementById(`deleteGuide-${guideClassName}`).remove();
            },
            error: () => {
                toastr.error('<?= $adminModal_internalError ?>', '<?= $generic_namePanel ?>');
            }
        });
    }
}
</script>



<script>
//** ADMIN HOME PAGE METHODS **//
var quillHomePage = new Quill('#admin-homePage-editor', {
	modules: {
    	toolbar: [
			[{ 'header': [1, 2, 3, 4, 5, 6, false] }, { 'size': ['small', false, 'large', 'huge'] }], 
            ['bold', 'italic', 'underline', 'strike'],
            [{ align: '' }, { align: 'center' }, { align: 'right' }, { align: 'justify' }],
			[{ 'color': [] }, { 'background': [] }],
			[{ 'list': 'bullet' }, { 'list': 'ordered'}, 'code-block', 'blockquote'],
            [ 'link', 'image', 'video'],
		]
  	},
    theme: 'snow',
});

<?php
if (file_exists('homePage.html'))
echo "document.getElementById('admin-homePage-editor').childNodes[0].innerHTML =`".file_get_contents('homePage.html')."`";
?>

$('#admin-homePage-setHomePageButton').on('click', () => {
    // Send the request
    $.ajax({
        type: 'POST', // define the type of HTTP verb we want to use (POST for our form)
        url: 'app/Admin/homePage.php', // the url where we want to POST
        data: {homePage: document.getElementById('admin-homePage-editor').childNodes[0].innerHTML}, // our data object
        success: (result) => {
            toastr.success("<?= $adminModal_homePage_homePageUploaded ?>", '<?= $generic_namePanel ?>');
        },
        error: () => {
            toastr.error('<?= $adminModal_internalError ?>', '<?= $generic_namePanel ?>');
        }
    });
});
</script>

<script>
//** ADMIN NEWS METHODS **//
var newsFileNameSelectedPrevious = null;
var newsNameSelectedPrevious = null;
var newsTagSelectedPrevious = null;
var newsValidName = true;
var newsCreated = null;
<?php
$path = dirname(__DIR__).'/news';
$newsFiles = [];
$newsNames = [];
$newsContents = [];

for ($i = 0; $i < $newsCount; $i++)
{
    if (!in_array($news[$i], ['.', '..']))
    {
        // Read the XML
        $newsXml = new SimpleXMLElement(file_get_contents("$path/".pathinfo($news[$i])['filename'].'.xml'));
        // Push all the elements
        $newsFiles[] = $news[$i];
        $newsNames[] = strval($newsXml->newsName);
        $newsContents[] = strval($newsXml->newsContent);
    }
}

echo 'newsCreated = '.json_encode(['newsNames' => $newsNames, 'newsContents' => $newsContents]);
?>

var quillNews = new Quill('#admin-news-editor', {
	modules: {
    	toolbar: [
			[{ 'header': [1, 2, 3, 4, 5, 6, false] }, { 'size': ['small', false, 'large', 'huge'] }], 
			['bold', 'italic', 'underline', 'strike'],
			[{ 'color': [] }, { 'background': [] }],
			[{ 'list': 'bullet' }, { 'list': 'ordered'}, 'code-block', 'blockquote'],
            [ 'link', 'image', 'video'],
		]
  	},
    theme: 'snow',
});

$('#admin-news-uploadnewsButton').on('click', () => 
{
    if (newsValidName)
    {
        // Get the news name
        const newsName = $('#admin-news-nameNewsText').val();
        // Check the news name
        if (newsName.length > <?= $constNewsMaxNameLength ?> || newsName.length == 0) 
        {
            // Update the UI, no News Name
            $('#admin-news-nameNewsText').removeClass('is-valid').addClass('is-invalid');
            $('#admin-news-nameNewsHelp').addClass('invalid-feedback').removeClass('valid-feedback').removeClass('text-muted');
            return;
        }

        // Update the UI
        $('#admin-news-nameNewsText').removeClass('is-invalid').addClass('is-valid');
        $('#admin-news-nameNewsHelp').removeClass('text-muted').removeClass('invalid-feedback').addClass('valid-feedback');

        if (newsFileNameSelectedPrevious != null && newsNameSelectedPrevious != null)
        {
            // Save the older news
            $.ajax({
                type: 'POST', // define the type of HTTP verb we want to use (POST for our form)
                url: 'app/Admin/news.php', // the url where we want to POST
                data: {newsFileName: newsFileNameSelectedPrevious, newsTag: $('#admin-news-chooseNewsTag').val(), newsName: newsName, newsContent: document.getElementById('admin-news-editor').childNodes[0].innerHTML}, // our data object
                success: (result) => {
                    // Update the content in the newsCreated variable
                    for (let i = 0; i < newsCreated.newsNames.length; i++) {
                        if (newsCreated.newsNames[i] == newsName)
                            newsCreated.newsContents[i] = document.getElementById('admin-news-editor').childNodes[0].innerHTML
                    }

                    toastr.success("<?= $adminModal_news_newsUploaded ?>", '<?= $generic_namePanel ?>');
                },
                error: () => {
                    toastr.error('<?= $adminModal_internalError ?>', '<?= $generic_namePanel ?>');
                }
            });
        }
        else 
        {
            // Send the request
            $.ajax({
                type: 'POST', // define the type of HTTP verb we want to use (POST for our form)
                url: 'app/Admin/news.php', // the url where we want to POST
                data: {newsName: newsName, newsTag: $('#admin-news-chooseNewsTag').val(), newsContent: document.getElementById('admin-news-editor').childNodes[0].innerHTML}, // our data object
                success: (result) => {
                    newsFileNameSelectedPrevious = result;
                    // Push the new news into the newsCreated
                    newsCreated.newsNames.push(newsName);
                    newsCreated.newsContents.push(document.getElementById('admin-news-editor').childNodes[0].innerHTML);
                    // Append the new news to chooseNews select
                    $("#admin-news-chooseNews").append($('<option></option>').attr("value", result).text(newsName).on('click', () => { news_setNews(result, $('#admin-news-chooseNewsTag').val(), newsName); }));
                    document.getElementById('admin-news-newsList').innerHTML += `<p id=\"deleteNews-${result}\" class=\"border-bottom list-link\" onclick=\"news_deleteNews('${result}')\">${result} - ${newsName}</p>`;

                    toastr.success("<?= $adminModal_news_newsUploaded ?>", '<?= $generic_namePanel ?>');
                },
                error: () => {
                    toastr.error('<?= $adminModal_internalError ?>', '<?= $generic_namePanel ?>');
                }
            });
        }
    }
});

$('#admin-news-nameNewsText').on('change', () => {
    // Get the news name
    const newsName = $('#admin-news-nameNewsText').val();
    newsNameSelectedPrevious = null;

    for (let i = 0; i < newsCreated.newsNames.length; i++)
    {
        if (newsName == newsCreated.newsNames[i])
        {
            // Update the UI, no News Name
            $('#admin-news-nameNewsText').removeClass('is-valid').addClass('is-invalid');
            $('#admin-news-nameNewsHelp').addClass('invalid-feedback').removeClass('valid-feedback').removeClass('text-muted');

            newsValidName = false;
            return;
        }
    }

    if (newsName.length > <?= $constNewsMaxNameLength ?> || newsName.length == 0) {
        // Update the UI, no News Name
        $('#admin-news-nameNewsText').removeClass('is-valid').addClass('is-invalid');
        $('#admin-news-nameNewsHelp').addClass('invalid-feedback').removeClass('valid-feedback').removeClass('text-muted');

        newsValidName = false;
    }
    else {
        // Update the UI
        $('#admin-news-nameNewsText').removeClass('is-invalid').addClass('is-valid');
        $('#admin-news-nameNewsHelp').removeClass('text-muted').removeClass('invalid-feedback').addClass('valid-feedback');
        newsValidName = true;
    }
});

const news_deleteNews = (newsName) => 
{
    // Confirm the choice
    if (confirm(`<?= $adminModal_news_removedNewsAsk ?>`))
    {
        // If the newsName equal the newsFileNameSelectedPrevious
        if (newsFileNameSelectedPrevious == newsName) {
            // Set the variable to null because that news no longer exists
            newsFileNameSelectedPrevious = null;
            newsNameSelectedPrevious = null;
        }

        // Remove the newe from the chooseNews because that news no longer exists
        $(`#admin-news-chooseNews option[value='${newsName}']`).remove();

        // Send the request
        $.ajax({
            type: 'POST', // define the type of HTTP verb we want to use (POST for our form)
            url: 'app/Admin/news.php', // the url where we want to POST
            data: `deleteNewsName=${newsName}`, // our data object
            success: (result) => {
                toastr.success("<?= $adminModal_news_newsRemoved ?>", '<?= $generic_namePanel ?>');
                // Delete the node because the image is removed
                document.getElementById(`deleteNews-${newsName}`).remove();
            },
            error: () => {
                toastr.error("<?= $adminModal_internalError ?>", '<?= $generic_namePanel ?>');
            }
	    });
    }
}

// Set the news from the select
const news_setNews = (newsFileName, newsTag, newsName) => 
{
    // Get the news name
    const newsNameOlder = $('#admin-news-nameNewsText').val();

    // Check the news name
    if (newsNameOlder.length > <?= $constNewsMaxNameLength ?> || newsNameOlder.length == 0 || !newsValidName)
    {
        $('#admin-news-nameNewsText').val(newsName);
        for (let i = 0; i < newsCreated.newsNames.length; i++) {
            if (newsName == newsCreated.newsNames[i]) {
                // Update the news content
                document.getElementById('admin-news-editor').childNodes[0].innerHTML = newsCreated.newsContents[i];
                break;
            }
        }

        newsFileNameSelectedPrevious = newsFileName;
        newsNameSelectedPrevious = newsName;
        newsTagSelectedPrevious = newsTag;
        newsValidName = true;

        // Update the UI
        $('#admin-news-nameNewsText').removeClass('is-invalid').addClass('is-valid');
        $('#admin-news-nameNewsHelp').removeClass('text-muted').removeClass('invalid-feedback').addClass('valid-feedback');
        $('#admin-news-chooseNewsTag').val(newsTag);
    }
    else 
    {
        // Confirm the choice
        if (confirm(`<?= $adminModal_news_loadNewsAsk ?>`))
        {
            let newsContent = null;
            for (let i = 0; i < newsCreated.newsNames.length; i++) {
                if (newsName == newsCreated.newsNames[i]) {
                    // Update the news content
                    newsContent = newsCreated.newsContents[i];
                    break;
                }
            }

            // Save the older news
            $.ajax({
                type: 'POST', // define the type of HTTP verb we want to use (POST for our form)
                url: 'app/Admin/news.php', // the url where we want to POST
                data: {newsFileName: newsFileNameSelectedPrevious, newsTag: newsTagSelectedPrevious, newsName: newsNameOlder, newsContent: document.getElementById('admin-news-editor').childNodes[0].innerHTML}, // our data object
                success: (result) => {
                    newsFileNameSelectedPrevious = newsFileName;
                    newsTagSelectedPrevious = newsTag;
                    newsNameSelectedPrevious = newsName;

                    $('#admin-news-nameNewsText').val(newsName);
                    $('#admin-news-chooseNewsTag').val(newsTag);
                    document.getElementById('admin-news-editor').childNodes[0].innerHTML = newsContent;

                    toastr.success("<?= $adminModal_news_newsUploaded ?>", '<?= $generic_namePanel ?>');
                },
                error: () => {
                    toastr.error("<?= $adminModal_internalError ?>", '<?= $generic_namePanel ?>');
                }
            });
        }
    }
}
</script>



<script>
//** ADMIN GALLERY METHODS **//
$('#admin-gallery-imageToUploadFiles').change(event => {
    // Get the images
    var imageToUpload = '';
    const images = event.target.files;
    const imagesCount = images.length;
    // Construct the text to display
    for (let i = 0; i < <?= $constGalleryMaxImagesCanSend ?>; i++)
        if (i <= images.length - 1)
            imageToUpload += `${images[i].name}, `;
    
    // Set the text
    $('#admin-gallery-imageToUploadLabel').html(imageToUpload.substring(0, imageToUpload.length - 2));
});

$('#admin-gallery-uploadImagesButton').on('click', () => {
    var canContinue = true;
    var images = document.getElementById('admin-gallery-imageToUploadFiles').files;

    // Update UI
    $('#admin-gallery-imageToUploadFiles').removeClass('is-invalid').addClass('is-valid');
    $('#admin-gallery-imageToUploadHelp').removeClass('text-muted').removeClass('invalid-feedback').addClass('valid-feedback');
    
    
    const shortDescription = $('#admin-gallery-shortDescriptionText').val();
    // Check short description length
    if (shortDescription.length > <?= $constGalleryMaxShortDescriptionLength ?> || shortDescription.length == 0)
    {
        $('#admin-gallery-shortDescriptionText').removeClass('is-valid').addClass('is-invalid');
        $('#admin-gallery-shortDescriptionHelp').addClass('invalid-feedback').removeClass('valid-feedback').removeClass('text-muted');
        return;
    }
    // Update UI
    $('#admin-gallery-shortDescriptionText').removeClass('is-invalid').addClass('is-valid');
    $('#admin-gallery-shortDescriptionHelp').removeClass('text-muted').removeClass('invalid-feedback').addClass('valid-feedback');


    const longDescription = $('#admin-gallery-longDescriptionText').val()
    // Check short description length
    if (longDescription.length > <?= $constGalleryMaxLongDescriptionLength ?> || longDescription.length == 0)
    {
        $('#admin-gallery-longDescriptionText').removeClass('is-valid').addClass('is-invalid');
        $('#admin-gallery-longDescriptionHelp').addClass('invalid-feedback').removeClass('valid-feedback').removeClass('text-muted');
        return;
    }
    // Update UI
    $('#admin-gallery-longDescriptionText').removeClass('is-invalid').addClass('is-valid');
    $('#admin-gallery-longDescriptionHelp').removeClass('text-muted').removeClass('invalid-feedback').addClass('valid-feedback');


    // Prepare the FormData
    var formData = new FormData();
    for (let i = 0; i < <?= $constGalleryMaxImagesCanSend ?>; i++)
    {
        if (i <= images.length - 1) 
            formData.append(images[i].name, images[i]);
    }

    // Append the description
    formData.append('shortDescription', shortDescription);
    formData.append('longDescription', longDescription);

    // Send the files
    $.ajax({
		type: 'POST', // define the type of HTTP verb we want to use (POST for our form)
		url: 'app/Admin/gallery.php', // the url where we want to POST
		data: formData, // our data object
        dataType: 'text',
		processData: false,
		contentType: false,
        success: (result) => 
        {
            const imageFileNames = eval(result);
            imageFileNames.forEach(element => document.getElementById('admin-gallery-imageList').innerHTML += `<p id=\"deleteImage-${element[0]}\" class=\"border-bottom list-link\" onclick=\"gallery_deleteImage('${element[0]}')\">${element[0]} - ${element[1]}</p>`);

            toastr.success("<?= $adminModal_gallery_imageUploaded ?>", '<?= $generic_namePanel ?>');
        },
        error: () => {
            toastr.error('<?= $adminModal_internalError ?>', '<?= $generic_namePanel ?>');
        }
	});
});

// Galery methods
const gallery_deleteImage = (imageName) => 
{
    // Confirm the choice
    if (confirm(`<?= $adminModal_gallery_removedImageAsk ?>`))
    {
        // Send the request
        $.ajax({
            type: 'POST', // define the type of HTTP verb we want to use (POST for our form)
            url: 'app/Admin/gallery.php', // the url where we want to POST
            data: `deleteImageName=${imageName}`, // our data object
            success: (result) => {
                toastr.success("<?= $adminModal_gallery_imageRemoved ?>", '<?= $generic_namePanel ?>');
                // Delete the node because the image is removed
                document.getElementById(`deleteImage-${imageName}`).remove();
            },
            error: () => {
                toastr.error('<?= $adminModal_internalError ?>', '<?= $generic_namePanel ?>');
            }
	    });
    }
}
</script>
<!-- --------------------------------------------------------------------------- -->