<?php
/*
Author: Thomas Croizet "Steez"
Teamspeak 3: ts.the-programmer.com
Web site: www.the-programmer.com

Terms of use:
  - This file is forbidden unless you have permission from the author. If you have this file without permission to use it please do not use it and do not share it.
  - If you have permission to use this file, you can use it on your server however it is strictly forbidden to share it.
  - Out of respect for the author please do not delete this information.
*/

// *** -------------------- (Please do not touch the complete file) -------------------- ***
namespace App\Parser;
require 'dictionnary.php';

class Beautifier
{
    private $methodName;
    private $methodAction;
    private $methodCondition;

    public function __construct($method)
    {
        // Explode all the datas
        $methodInformation = explode('=>', $method);

        // Setup all the information about the method
        $this->methodName = trim($methodInformation[0]);
        $this->methodAction = (count($methodInformation) > 1) ? trim($methodInformation[1]) : '';
        $this->methodCondition = (count($methodInformation) > 2) ? trim($methodInformation[2]) : '';
    }

    // Parse the value with the method
    public function parse($value)
    {
        $value = $this->invokeMethod($value);
        $value = ($this->methodAction != '' && $this->methodName != 'array') ? $this->invokeAction($value) : $value;
        return $value;
    }

    // Invoke the method to the value
    private function invokeMethod($value)
    {
        // Choose the right method
        switch ($this->methodName)
        {
            // Convert number
            case 'number':
                return number_format($value);
                break;

            case 'number-fr':
                return number_format($value, 0, ',', ' ');
                break;

            // Convert value
            case 'to-playerName-steamId':
                $homePath = dirname(dirname(dirname(__FILE__)));
                require "$homePath/config/constant.php";
                $constPanelPlayerInformationConfigString = file_get_contents($homePath.'/config/playerInformation.xml');

                // Get all the categories from the config
                $constPanelConfigXml = simplexml_load_string($constPanelPlayerInformationConfigString);
                $categories = $constPanelConfigXml->category;
                $categoriesCount = count($categories);

                // Display all the categories
				for ($i = 0; $i < $categoriesCount; $i++) 
				{
					// Get the category dbname
					$categoryDbName = $categories[$i]->attributes()->dbName;
					$categoryIndentifier = $categories[$i]->attributes()->indentifier;
					$categoryIndentifierType = (isset($categories[$i]->attributes()->indentifierType)) ? $categories[$i]->attributes()->indentifierType : 'string';

                    if ($categoryDbName == $constPanelPlayerInformationDefaultCategory)
                    {
                        // Get the player name
                        $PdoQuery = new \App\PdoQuery($constPdoDatabaseName);
                        return $PdoQuery->query("SELECT $constPanelPlayerInformationPlayerNameDefaultCategory FROM $categoryDbName WHERE $categoryIndentifier=$value")[$constPanelPlayerInformationPlayerNameDefaultCategory];
                    }
                }

                return $value;
                break;

            case 'to-date':
                return date_format(date_create($value), '\T\h\e m/d/Y \a\t g:ia');
                break;

            case 'to-date-fr':
                return date_format(date_create($value), '\L\e d/m/Y \à H\hi');
                break;

            case 'to-percent':
                return strval(round(floatval($value * 100), 1)).'%';
                break;

            // Parse array
            case 'array':
                $arrayRegex = ['/[^\]\[]+/i'];

                // Test the regex
                if (preg_match($arrayRegex[0], $value))
                {
                    // Apply the regex on the valie
                    $arrayValue = [];
                    preg_match_all($arrayRegex[0], $value, $arrayValue);
                    $arrayValue = $arrayValue[0];
                    $arrayValueCount = count($arrayValue);
                    // Create the display value variable
                    $displayValue = '';

                    // Create the display format
                    for ($i = 0; $i < $arrayValueCount; $i++) 
                    {
                        if ($arrayValue[$i] != '"' && $arrayValue[$i] != ',')
                        {
                            // Get the value information
                            $subArrayValue = explode(',', $arrayValue[$i]);
                            // Trim the information, remove indesirable chars
                            $displayText = Dictionnary::value(trim($subArrayValue[0], " \t\n\r\0\x0B`'\""));
                            $displayTextValue = trim($subArrayValue[1], " \t\n\r\0\x0B`'\"");

                            // Invoke the action, if have an action set
                            $valueToDisplay = ($this->methodAction != '') ? $this->invokeAction($displayText.' - '.$displayTextValue) : $displayText.' - '.$displayTextValue;

                            // Add it to the value
                            if ($displayValue == '') $displayValue = $valueToDisplay;
                            else $displayValue .= '<br>'.$valueToDisplay;
                        }
                    }

                    return $displayValue;
                }
                break;

                case 'array-bool':
                    $arrayRegex = ['/[^\]\[]+/i'];

                    // Test the regex
                    if (preg_match($arrayRegex[0], $value))
                    {
                        // Apply the regex on the valie
                        $arrayValue = [];
                        preg_match_all($arrayRegex[0], $value, $arrayValue);
                        $arrayValue = $arrayValue[0];
                        $arrayValueCount = count($arrayValue);
                        // Create the display value variable
                        $displayValue = '';

                        // Create the display format
                        for ($i = 0; $i < $arrayValueCount; $i++) 
                        {
                            if ($arrayValue[$i] != '"' && $arrayValue[$i] != ',')
                            {
                                // Get the value information
                                $subArrayValue = explode(',', $arrayValue[$i]);
                                // Trim the information, remove indesirable chars
                                $displayText = Dictionnary::value(trim($subArrayValue[0], " \t\n\r\0\x0B`'\""));
                                $displayTextValue = trim($subArrayValue[1], " \t\n\r\0\x0B`'\"");

                                // Prevent conditionnal array
                                if ($displayTextValue != '0' && $displayTextValue != 'false')
                                {
                                    if ($displayTextValue == '1' || $displayTextValue == 'true')
                                    {
                                        // Invoke the action, if have an action set
                                        $displayText = ($this->methodAction != '') ? $this->invokeAction($displayText) : $displayText;

                                        // Add it to the value
                                        if ($displayValue == '') $displayValue = $displayText;
                                        else $displayValue .= '<br>'.$displayText;
                                    }
                                    else
                                    {
                                        // Invoke the action, if have an action set
                                        $valueToDisplay = ($this->methodAction != '') ? $this->invokeAction($displayText.' - '.$displayTextValue) : $displayText.' - '.$displayTextValue;

                                        // Add it to the value
                                        if ($displayValue == '') $displayValue = $valueToDisplay;
                                        else $displayValue .= '<br>'.$valueToDisplay;
                                    }
                                }
                            }
                        }

                        return $displayValue;
                    }
                    break;

                case 'array-to-playerName-steamId':
                    $homePath = dirname(dirname(dirname(__FILE__)));
                    require "$homePath/config/constant.php";
                    $constPanelPlayerInformationConfigString = file_get_contents($homePath.'/config/playerInformation.xml');

                    // Get all the categories from the config
                    $constPanelConfigXml = simplexml_load_string($constPanelPlayerInformationConfigString);
                    $categories = $constPanelConfigXml->category;
                    $categoriesCount = count($categories);

                    // Display all the categories
                    for ($i = 0; $i < $categoriesCount; $i++) 
                    {
                        // Get the category dbname
                        $categoryDbName = $categories[$i]->attributes()->dbName;
                        $categoryIndentifier = $categories[$i]->attributes()->indentifier;
                        $categoryIndentifierType = (isset($categories[$i]->attributes()->indentifierType)) ? $categories[$i]->attributes()->indentifierType : 'string';

                        if ($categoryDbName == $constPanelPlayerInformationDefaultCategory)
                        {
                            // Get all the values from the array with the Regex
                            $arrayValue = [];
                            preg_match_all('/[^\]\[]+/i', $value, $arrayValue);
                            $arrayValue = $arrayValue[0];
                            $arrayValueCount = count($arrayValue);
                            $dataToReturn = '';

                            // Get all the steamId
                            for ($j = 0; $j < $arrayValueCount; $j++) 
                            {
                                if ($arrayValue[$j] != '"' && $arrayValue[$j] != ',')
                                {
                                    // Get the sub array values
                                    $subArrayValue = explode(',', $arrayValue[$j]);
                                    $subArrayValueCount = count($subArrayValue);

                                    // Iterate from all the sub array datas
                                    for ($k = 0; $k < $subArrayValueCount; $k++) 
                                    {
                                        // Get the steamId
                                        $steamId = trim($subArrayValue[$k], " \t\n\r\0\x0B`'\"");

                                        // Get the player name from the default database
                                        $PdoQuery = new \App\PdoQuery($constPdoDatabaseName);
                                        $playerName = $PdoQuery->query("SELECT $constPanelPlayerInformationPlayerNameDefaultCategory FROM $categoryDbName WHERE $categoryIndentifier=$steamId")[$constPanelPlayerInformationPlayerNameDefaultCategory];

                                        // Write it to the $dataToReturn
                                        if (isset($playerName))
                                        {
                                            if ($dataToReturn == '') $dataToReturn = $playerName;
                                            else $dataToReturn .= ', '.$playerName;
                                        }
                                    }
                                }
                            }

                            return $dataToReturn;
                        }
                    }
                    break;

                // Profile function
                case 'altislife-playtime':
                    // Apply the regex on the valie
                    $arrayValue = [];
                    preg_match_all('/[^\]\[]+/i', $value, $arrayValue);
                    $arrayValue = $arrayValue[0];
                    
                    // Explode the result from the regex
                    $arrayValue = explode(',', $arrayValue[1]);
                    return Dictionnary::value('west').$this->toPlayTime($arrayValue[0] * 60).'<br>'.Dictionnary::value('independent').$this->toPlayTime($arrayValue[1] * 60).'<br>'.Dictionnary::value('civ').$this->toPlayTime($arrayValue[2] * 60);
                    break;

                case 'altislife-to-color':
                    // If the value is blank
                    if ($value == -1) return Dictionnary::value('noData');

                    // Get the colors in the format rgba
                    $arrayValue = [];
                    preg_match_all('/[^\(\)]+/i', $value, $arrayValue);
                    $colors = explode(',', $arrayValue[0][3]);

                    // Get the color channel
                    $colorR = round($colors[0] * 255);
                    $colorG = round($colors[1] * 255);
                    $colorB = round($colors[2] * 255);
                    $colorA = round($colors[3], 2);
                    // Canvas id
                    $canvasId = 'canvas'.rand(0,1000);

                    return "<canvas id='$canvasId' width='21' height='21' rgbColorText='rgba: $colorR, $colorG, $colorB, $colorA' style='background-color: white; border-radius: 100%; margin-bottom: -4px;' data-toggle='tooltip' data-placement='top' data-html='true' title='rgba: $colorR, $colorG, $colorB, $colorA'></canvas>
                            <script>
                            var ctx = document.getElementById('$canvasId').getContext('2d');
                            ctx.beginPath();
                            ctx.ellipse(21 / 2, 21 / 2, 21 / 2, 21 / 2, 0, 0, 2 * Math.PI);
                            ctx.fillStyle = 'rgba($colorR, $colorG, $colorB, $colorA)';
                            ctx.fill();
                            </script>";
                    break;

            default:
                return $value;
                break;
        }
    }

    // Invoke the action to the value
    private function invokeAction($value)
    {
        // Get the action name
        $actionInformation = explode(' ', $this->methodAction);
        $actionName = $actionInformation[0];
        $actionParameter = '';

        // Construct the action parameter
        if (count($actionInformation) > 2) {
            for ($i = 1; $i < count($actionInformation); $i++) {
                if ($actionParameter == '') $actionParameter = $actionInformation[$i];
                else $actionParameter .= ' '.$actionInformation[$i];
            }
        }
        else
            $actionParameter = $actionInformation[1];

        // Choose the right action
        switch ($actionName)
        {
            case 'add':
                return $value.' '.$actionParameter;
                break;

            case 'add-before':
                return $actionParameter.' '.$value;
                break;

            default:
                return $value;
                break;
        }
    }

    // Conver the second to a playtime
    private function toPlayTime($value)
    {
        $day = floor($value / (3600 * 24));
        $hour = floor(($value - ($day * (3600 * 24))) / 3600);
        $minutes = ($value - (($day * (3600 * 24)) + $hour * 3600)) / 60;

        return $day.Dictionnary::value('days').$hour.Dictionnary::value('hours').$minutes.Dictionnary::value('minutes');
    }
}
// *** --------------------------------------------------------------------------- ***