<?php
/*
Author: Thomas Croizet "Steez" - Antoine Tétart "Vescoze"
Teamspeak 3: ts.the-programmer.com
Web site: www.the-programmer.com

Terms of use:
  - This file is forbidden unless you have permission from the author. If you have this file without permission to use it please do not use it and do not share it.
  - If you have permission to use this file, you can use it on your server however it is strictly forbidden to share it.
  - Out of respect for the author please do not delete this information.
*/

// *** -------------------- (Please do not touch the complete file) -------------------- ***
namespace App\Parser;

class Dictionnary
{
    public static function value($key)
    {
        // Include the constant.php
        $homePath = dirname(dirname(dirname(__FILE__)));
        require "$homePath/config/constant.php";
        $constPanelDictionnaryString = file_get_contents($homePath.'/config/dictionnary.xml');

        // Get all the entry tag
        $constPanelDictionnaryXml = simplexml_load_string($constPanelDictionnaryString);
        $entries = $constPanelDictionnaryXml->entry;
        $entriesCount = count($entries);

        // Find the value by the key
        for ($i = 0; $i < $entriesCount; $i++) {
            $entry = $entries[$i];
            if ($entry->attributes()->key == $key)
                // Return the value
                return $entry->attributes()->value;
        }

        return $key;
    }
}
// *** --------------------------------------------------------------------------- ***