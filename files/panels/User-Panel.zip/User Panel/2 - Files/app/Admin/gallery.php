<?php
/*
Author: Thomas Croizet "Steez"
Teamspeak 3: ts.the-programmer.com
Web site: www.the-programmer.com

Terms of use:
  - This file is forbidden unless you have permission from the author. If you have this file without permission to use it please do not use it and do not share it.
  - If you have permission to use this file, you can use it on your server however it is strictly forbidden to share it.
  - Out of respect for the author please do not delete this information.
*/

// *** -------------------- (Please do not touch the complete file) -------------------- ***
require '../xml.php';
require '../../config/constant.php';
session_start();

if (!in_array($_SESSION['steamId'], $constPanelAdminUsers))
    exit;

if (isset($_POST['shortDescription'], $_POST['longDescription']))
{
    $path = dirname(dirname(__DIR__)).'/gallery';
    $imageFileNames = [];
    // Scan the directory
    $images = scandir($path, 1);
    sort($images,  SORT_NATURAL);
    $images = array_splice($images, 2);

    // Get the number of images
    $galleryImagesCount = ((count($images) - 2) / 2) + intval(str_replace('image_', '', pathinfo($images[0])['filename']));
    $index = 1;

    // Iterate over all the files sended
    foreach ($_FILES as $file) 
    {
        // Set the new $currentImageNumber
        $currentImageNumber = $galleryImagesCount + $index;

        // Set the image and the xml file
        move_uploaded_file($file['tmp_name'], "$path/image_$currentImageNumber.".pathinfo($file['name'])['extension']);
        $filePtr = fopen("$path/image_$currentImageNumber.xml", 'w');
        fwrite($filePtr, xml_encode(['UserPanel' => ['shortDescription' => $_POST['shortDescription'], 'longDescription' => $_POST['longDescription']]]));
        fclose($filePtr);

        // Update the index
        $imageFileNames[] = ["image_$currentImageNumber.".pathinfo($file['name'])['extension'], $_POST['shortDescription']];
        $index++;
    }

    echo json_encode($imageFileNames);
}

if (isset($_POST['deleteImageName']))
{
    // Get the path of the image
    $path = dirname(dirname(__DIR__)).'/gallery';
    $xmlFileName = pathinfo($_POST['deleteImageName'])['filename'].'.xml';

    // Delete the image and it description
    unlink("$path/$_POST[deleteImageName]");
    unlink("$path/$xmlFileName");
}
// *** --------------------------------------------------------------------------- ***