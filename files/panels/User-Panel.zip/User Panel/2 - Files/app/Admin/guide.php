<?php
/*
Author: Thomas Croizet "Steez"
Teamspeak 3: ts.the-programmer.com
Web site: www.the-programmer.com

Terms of use:
  - This file is forbidden unless you have permission from the author. If you have this file without permission to use it please do not use it and do not share it.
  - If you have permission to use this file, you can use it on your server however it is strictly forbidden to share it.
  - Out of respect for the author please do not delete this information.
*/

// *** -------------------- (Please do not touch the complete file) -------------------- ***
require '../xml.php';
require '../../config/constant.php';
session_start();

if (!in_array($_SESSION['steamId'], $constPanelAdminUsers))
    exit;

function delete_files($target) 
{
    if(is_dir($target)) {
        $files = glob($target . '*', GLOB_MARK); //GLOB_MARK adds a slash to directories returned

        foreach($files as $file) {
            delete_files($file);      
        }

        rmdir($target);
    } elseif (is_file($target)) {
        unlink($target);  
    }
}


if (isset($_POST['createGuideClassName']))
{
    $path = dirname(dirname(__DIR__)).'/guide/'.$_POST['createGuideClassName'];
    // If the folder exists
    if (is_dir($path)) {
        // Can't create the folder
        echo 'false';
    }
    else
    {
        // Create the folder
        mkdir($path);
        echo 'true';
    }
}
else if (isset($_POST['guideFileName'], $_POST['guideClassName'], $_POST['guideName'], $_POST['guideContent']))
{
    $path = dirname(dirname(__DIR__)).'/guide/'.$_POST['guideClassName'].'/'.$_POST['guideFileName'];

    // Get the content of the xml file
    $guideXml = new SimpleXMLElement(file_get_contents($path));
    $guideXml->guideName = $_POST['guideName'];
    $guideXml->guideClassName = $_POST['guideClassName'];
    $guideXml->guideContent = $_POST['guideContent'];
    // Remove the file in order to save it...
    
    unlink($path);
    $guideXml->asXML($path);
}
else if (isset($_POST['guideName'], $_POST['guideContent'], $_POST['guideClassName']))
{
    $path = dirname(dirname(__DIR__)).'/guide/'.$_POST['guideClassName'];
    // Scan the directory
    $guides = scandir($path, 1);
    sort($guides,  SORT_NATURAL);

    // Get the number of guides in it
    $guidesCount = ((count($guides) - 2)) + intval(str_replace("guide_$_POST[guideClassName]_", '', pathinfo($news[0])['filename']));
    // Write the guide xml file
    $filePtr = fopen("$path/guide_$_POST[guideClassName]_$guidesCount.xml", 'w');
    fwrite($filePtr, xml_encode(['UserPanel' => ['guideName' => $_POST['guideName'], 'guideClassName' => $_POST['guideClassName'], 'guideContent' => $_POST['guideContent']]]));
    fclose($filePtr);

    echo "guide_$_POST[guideClassName]_$guidesCount.xml";
}
else if (isset($_POST['deleteGuideClassName'], $_POST['deleteGuideName']))
{
    // Delete the guide
    $path = dirname(dirname(__DIR__)).'/guide/'.$_POST['deleteGuideClassName'].'/'.$_POST['deleteGuideName'];
    unlink($path);
}
else if (isset($_POST['deleteGuideClassName']))
{
    // Delete the category
    $path = dirname(dirname(__DIR__)).'/guide/'.$_POST['deleteGuideClassName'].'/';
    delete_files($path);
}
// *** --------------------------------------------------------------------------- ***