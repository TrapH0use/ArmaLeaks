<?php
/*
Author: Thomas Croizet "Steez"
Teamspeak 3: ts.the-programmer.com
Web site: www.the-programmer.com

Terms of use:
  - This file is forbidden unless you have permission from the author. If you have this file without permission to use it please do not use it and do not share it.
  - If you have permission to use this file, you can use it on your server however it is strictly forbidden to share it.
  - Out of respect for the author please do not delete this information.
*/

// *** -------------------- (Please do not touch the complete file) -------------------- ***
require '../xml.php';
require '../../config/constant.php';
session_start();

if (!in_array($_SESSION['steamId'], $constPanelAdminUsers))
    exit;

if (isset($_POST['newsFileName'], $_POST['newsName'], $_POST['newsContent'], $_POST['newsTag']))
{
    $path = dirname(dirname(__DIR__)).'/news/'.$_POST['newsFileName'];
    // Get the content of the xml file
    $newsXml = new SimpleXMLElement(file_get_contents($path));
    $newsXml->newsName = $_POST['newsName'];
    $newsXml->newsTag = $_POST['newsTag'];
    $newsXml->newsContent = $_POST['newsContent'];
    // Remove the file in order to save it...
    unlink($path);
    $newsXml->asXML($path);
}
else if (isset($_POST['newsName'], $_POST['newsContent'], $_POST['newsTag']))
{
    $path = dirname(dirname(__DIR__)).'/news';
    // Scan the directory
    $news = scandir($path, 1);
    sort($news,  SORT_NATURAL);

    // Get the number of images
    $newsCount = ((count($news) - 2)) + intval(str_replace('news_', '', pathinfo($news[0])['filename']));
    // Write the news xml file
    $filePtr = fopen("$path/news_$newsCount.xml", 'w');
    fwrite($filePtr, xml_encode(['UserPanel' => ['newsName' => $_POST['newsName'], 'newsTag' => $_POST['newsTag'], 'newsContent' => $_POST['newsContent']]]));
    fclose($filePtr);

    echo "news_$newsCount.xml";
}
else if (isset($_POST['deleteNewsName']))
{
    // Get the path of the image
    $path = dirname(dirname(__DIR__)).'/news';
    // Delete the news
    unlink("$path/$_POST[deleteNewsName]");
}
// *** --------------------------------------------------------------------------- ***