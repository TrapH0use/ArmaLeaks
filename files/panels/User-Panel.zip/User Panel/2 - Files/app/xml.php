<?php
/*
Author: Thomas Croizet "Steez"
Teamspeak 3: ts.the-programmer.com
Web site: www.the-programmer.com

Terms of use:
  - This file is forbidden unless you have permission from the author. If you have this file without permission to use it please do not use it and do not share it.
  - If you have permission to use this file, you can use it on your server however it is strictly forbidden to share it.
  - Out of respect for the author please do not delete this information.
*/

// *** -------------------- (Please do not touch the complete file) -------------------- ***
function xml_encode($mixed, $domElement=null, $DOMDocument=null) {
    if (is_null($DOMDocument)) {
        $DOMDocument = new DOMDocument('1.0', 'utf-8');
        $DOMDocument->formatOutput = true;
        xml_encode($mixed, $DOMDocument, $DOMDocument);
        return $DOMDocument->saveXML();
    }
    else {
        if (is_array($mixed)) {
            foreach ($mixed as $index => $mixedElement) {
                if (is_int($index)) {
                    if ($index === 0) {
                        $node = $domElement;
                    }
                    else {
                        $node = $DOMDocument->createElement($domElement->tagName);
                        $domElement->parentNode->appendChild($node);
                    }
                }
                else {
                    $plural = $DOMDocument->createElement($index);
                    $domElement->appendChild($plural);
                    $node = $plural;
                    if (!(rtrim($index, 's') === $index)) {
                        $singular = $DOMDocument->createElement(rtrim($index, 's'));
                        $plural->appendChild($singular);
                        $node = $singular;
                    }
                }
 
                xml_encode($mixedElement, $node, $DOMDocument);
            }
        }
        else {
            $domElement->appendChild($DOMDocument->createTextNode($mixed));
        }
    }
}
// *** --------------------------------------------------------------------------- ***