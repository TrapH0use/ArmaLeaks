<?php
/*
Author: Thomas Croizet "Steez"
Teamspeak 3: ts.the-programmer.com
Web site: www.the-programmer.com

Terms of use:
  - This file is forbidden unless you have permission from the author. If you have this file without permission to use it please do not use it and do not share it.
  - If you have permission to use this file, you can use it on your server however it is strictly forbidden to share it.
  - Out of respect for the author please do not delete this information.
*/

// *** -------------------- (Please do not touch the complete file) -------------------- ***
namespace App;

// PdoQuery class
class PdoQuery
{
    private $type;
    private $server;
    private $username;
    private $password;
    private $database;
    private $pdo;

    private $databaseSchema;
    private $columnCount;
    private $rowCount;

    private $error;

    public function __construct($database)
    {
        // Include the constant.php
        $homePath = dirname(dirname(__FILE__));
        require "$homePath/config/constant.php";

        try
        {
            // Set all the PDO information
            $this->type = $constPdoSgbd;
            $this->server = $constPdoHost;
            $this->database = $database;
            $this->username = $constPdoUsername;
            $this->password = $constPdoPassword;

            // Create the PDO object
            $this->pdo = new \PDO("$constPdoSgbd:host=$constPdoHost;dbname=$database;charset=utf8", $constPdoUsername, $constPdoPassword);
        }
        catch (Exception $e) {
            // Set the error and exit the script
            $this->error = $e->getMessage();
            die('Erreur : ' . $e->getMessage());
        }
    }

    /*
      * Get all the columns name of a table
      *
      * @param string $table: the table to get columns name
      *
      * @return array: all the column infos
    */
    private function getDatabaseSchema($table)
    {
        // Prepare and execute the query
        $queryReturn = $this->pdo->prepare("SHOW COLUMNS FROM $table");
        $queryReturn->execute();

        // Get the database schema
        $returnValues = [];
        while ($data = $queryReturn->fetch()) { array_push($returnValues, $data[0]); }
        return $returnValues;
    }

    /*
      * Exec a sql query and return a result if the query is a SELECT
      *
      * @param array $dataArray: a query result
      *
      * @return array: the query result is organize line per line
      *
      * NOTE: work only with a query result
    */
    private function organizeData($dataArray)
    {
        // Get all the data and the database schema
        $dataOrganized = [];
        $dataArrayCount = count($dataArray) -1;
        $databaseSchemaCount = count($this->databaseSchema) -1;

        // Iterate over all the data
        for ($i = 0; $i <= $databaseSchemaCount; $i++)
        {
            $tmpDataOrganized = [];

            // Reorganize it!
            for ($ii = 0; $ii <= $dataArrayCount; $ii++) { array_push($tmpDataOrganized, $dataArray[$ii][$i]); /* Change row model to a column model */ }
            array_push($dataOrganized, $tmpDataOrganized);
        }

        return $dataOrganized;
    }

    /*
      * Execute a sql query and return a result if the query is a SELECT
      *
      * @param string $query: the sql query,
               bool $organizeData: if the result must be organize to column
      *
      * @return null: query is not a select
                array: query is a select
      *
      * NOTE: can only take query per query
    */
    public function query($query, $organizeData = false, $returnAtRaw = false)
    {
        // Prepare and execute the query
        $queryReturn = $this->pdo->prepare($query);
        $queryReturn->execute();

        // Get all the column and the row affected by the query
        $this->columnCount = $queryReturn->columnCount();
        $this->rowCount = $queryReturn->rowCount();

        // If we return raw data
        if ($returnAtRaw) { return $queryReturn; }

        // If the query is a select
        if (strpos($query, "SELECT") !== false)
        {
            $databaseSchema = [];

            // If we get all the data
            if (!(strpos($query, '*')))
            {
                // Get all the informations from the query
                $tableBase = explode('SELECT', $query);
                $tableBase = explode('FROM', $tableBase[1]);
                $dataToReturn = explode(',', $tableBase[0]);
                $tableName = explode('WHERE', $tableBase[1])[0];
                // Get the database schema
                $rowDatabaseSchema = $this->getDatabaseSchema($tableName);

                for ($i = 0; $i <= count($dataToReturn) - 1; $i++)
                {
                    $datasReturns = explode(' ', $dataToReturn[$i]);
                    foreach ($datasReturns as $data) { if ($data != '') { $dataToReturn[$i] = $data; } }
                }

                // Prepare the column
                foreach ($dataToReturn as $return)
                {
                    // Set the column properly
                    foreach ($rowDatabaseSchema as $property)
                    {
                        if ($return == $property)
                        {
                            array_push($databaseSchema, $property);
                            break;
                        }
                    }
                }
            }
            else
            {
                // Explode the query
                $tableBase = explode('SELECT', $query);
                $tableBase = explode('FROM', $tableBase[1]);

                // Get the table name
                $dataToReturn = explode(',', $tableBase[0]);
                $tableName = explode('WHERE', $tableBase[1])[0];
                // Get the database schema
                $rowDatabaseSchema = $this->getDatabaseSchema($tableName);

                // Set the column properly
                foreach ($rowDatabaseSchema as $property) { array_push($databaseSchema, $property); }
            }

            // Set the database schema
            $this->databaseSchema = $databaseSchema;
            $returnValues = [];

            // Set the data properly
            while ($data = $queryReturn->fetch())
            {
                $tmpReturnValues = [];
                foreach ($databaseSchema as $property) { $tmpReturnValues[$property] = $data[$property]; }

                array_push($returnValues, $tmpReturnValues);
            }

            // Close the PDO
            $queryReturn->closeCursor();
            // If we just have a row affected
            if (count($returnValues) == 1) $returnValues = $returnValues[0];

            // If organizeData
            if ($organizeData) return $this->organizeData($returnValues);
            else return $returnValues;
        }
        // If the query is SHOW
        else if (strpos($query, 'SHOW') !== false)
        {
            // Just return the raw data
            $returnValues = [];
            while ($data = $queryReturn->fetch()) { array_push($returnValues, $data); }
            return $returnValues;
        }
        else { return null; }
    }

    public function exportDatabase($databaseArray = [])
    {
        // Set some variables
        $date = date('Y-m-d H:i:s');
        $databaseToExport = $databaseArray;
        // If the $databaseToExport is an array type
        if ($databaseToExport === []) { array_push($databaseToExport, $this->database); /* Push the database */ }
        $databaseToExportCount = count($databaseToExport);

        // Set the SQL file header
        $sqlBackup = '-- pdo.php dump'.PHP_EOL."-- Genreate at: $date".PHP_EOL.PHP_EOL;
        $sqlBackup .= 'SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";'.PHP_EOL.'SET time_zone = "+00:00";'.PHP_EOL.PHP_EOL.PHP_EOL.PHP_EOL;

        // Get all the database
        foreach ($databaseToExport as $database)
        {
            $tables = [];
            $bufferContent = '';

            // If the export is an array
            if ($databaseToExportCount != 0) { $this->__construct($database); /* Generat another instance of the constructor */ }

            // Set the database header
            $sqlBackup .= '--'.PHP_EOL.'-- Database `'.$database.'`'.PHP_EOL.'--'.PHP_EOL.PHP_EOL;
            $sqlBackup .= '-- --------------------------------------------------------'.PHP_EOL.PHP_EOL;

            // Show all the tables
            $tableQuery = $this->query('SHOW TABLES');
            foreach ($tableQuery as $table) { array_push($tables, $table[0]); /* Push each table in the array */ }

            // Iterate over all the table
            foreach ($tables as $table)
            {
                // Set the table header
                $sqlBackup .= '--'.PHP_EOL."-- Table structure of `$table`".PHP_EOL.'--'.PHP_EOL.PHP_EOL;
                // Prepare the buffer content
                $bufferContent = PHP_EOL."INSERT INTO `$table`".'(';

                // Get the table structure
                $sqlBackup .= $this->query("SHOW CREATE TABLE $table")[0][1].';'.PHP_EOL;
                $sqlBackup .= PHP_EOL.'--'.PHP_EOL."-- Data content of `$table`".PHP_EOL.'--'.PHP_EOL;
                $columnQuery = $this->query("SHOW COLUMNS FROM $table");

                // Iterave over all the column
                foreach ($columnQuery as $column)
                {
                    // Set the column name
                    $columnName = $column[0];
                    $bufferContent .= "`$columnName`, ";
                }

                // Remove the 2 last characters
                $bufferContent = substr($bufferContent, 0, -2).') VALUES '.PHP_EOL;
                // Add the bufferContent to the SQL backup
                $sqlBackup .= $bufferContent;
                $bufferContent = '';

                // Get all the data from the table
                $dataQuery = $this->query("SELECT * FROM $table");

                // Iterate over all the data
                foreach ($dataQuery as $datas)
                {
                    $bufferContent = '(';

                    // Iterave over all the sub-data in the array
                    foreach ($datas as $data)
                    {
                        // If the data is a number
                        if (ctype_digit($data)) { $bufferContent .= "$data, "; }
                        // If the data is null
                        else if ($data == '') { $bufferContent .= "NULL, "; }
                        else { $bufferContent .= "'$data', "; }
                    }

                    // Remove the last 2 characters and complete it
                    $bufferContent = substr($bufferContent, 0, -2).'),'.PHP_EOL;
                    $sqlBackup .= $bufferContent;
                }

                // Final SQL file
                $sqlBackup = substr($sqlBackup, 0, -2).';'.PHP_EOL.PHP_EOL.PHP_EOL.PHP_EOL;
            }
        }

        // Remove the four last line, because the new lines are useless
        $sqlBackup = substr($sqlBackup, 0, -4);
        return $sqlBackup;
    }
}
// *** --------------------------------------------------------------------------- ***