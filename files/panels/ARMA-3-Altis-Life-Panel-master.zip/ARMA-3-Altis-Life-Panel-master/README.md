# ARMA-3-Altis-Life-Panel
This is a fully working Arma 3 Altis Life Web panel, manage Money, Cars, Houses and even SMS online! 
It could be possible that for newer Versions of Altsi Life you need to update the DB manually, but shouldnt be a problem ;)
