/*--------------------------------------------------------------------------
    Author:		Maverick Applications
    Website:	https://maverick-applications.com

    You're not allowed to use this file without permission from the author!
---------------------------------------------------------------------------*/

class Maverick_WeaponShop {
	tag = "MAV_shop";
	class functions {
		file = "maverick\weaponshops";
		class initWeaponShop {};
		class weaponCompatibleItems {};
		class addGear {};
		class containerAdd {};
		class handleGear {};
		class hasSpace {};
		class itemInfo {};
		class index {};
		class openWeaponShop {};
	};
};