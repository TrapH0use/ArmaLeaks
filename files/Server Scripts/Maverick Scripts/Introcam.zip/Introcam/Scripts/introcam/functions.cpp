class Maverick_IntroCam {
	tag = "mav_introcam";
	class functions {
		file = "maverick\introcam";
		class startCinematicCam {};
		class updateCinematicStatus {};
		class finishCinematicCam {};
	};
};