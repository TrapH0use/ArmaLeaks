class VehiclePurchased {
    expToAdd = 5;
	message = "Vehicle Purchased";
};

class ItemProcessed {
    expToAdd = 2;
	message = "Items Processed";
};

class VehicleLockpicked {
    expToAdd = 5;
	message = "Vehicle Lockpicked";
};

class Example {
    expToAdd = 100;
	message = "Customizable Message";
};