class ExpSys {
	class Actions {
		#include "..\configuration\actions.hpp"
	};

	class Levels {
		#include "..\configuration\levels.hpp"
	};

	class Perks {
		#include "..\configuration\perks.hpp"
	};
};
