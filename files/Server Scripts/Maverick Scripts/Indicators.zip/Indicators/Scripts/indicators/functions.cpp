class Maverick_Indicators {
	tag = "mav_indicator";
	class functions {
		file = "maverick\indicators";
		class getVehicleIndicatorOffsets {};
		class enableIndicator {};
		class disableIndicator {};
		class init { postInit = 1; };
	};
};