class mav_indicator_fnc_enableIndicator {
    allowedTargets = 1;
};
class mav_indicator_fnc_disableIndicator {
    allowedTargets = 1;
};