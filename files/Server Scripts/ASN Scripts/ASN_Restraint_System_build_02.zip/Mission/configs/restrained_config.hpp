#define true 1
#define false 0


class restrained_config {
	
    version = 4; // 4.0 - 4.3 -> 4 | version 4.4+ -> 5

	EnableSprinting = "True"; // Enable Sprinting while handcuffed.
	
	EnableWarnings = "True"; // Display the warning below then the player tries to do somthing he cant while handcuffed
	handcuffed = "Your handcuffed you cant do this"; 

};