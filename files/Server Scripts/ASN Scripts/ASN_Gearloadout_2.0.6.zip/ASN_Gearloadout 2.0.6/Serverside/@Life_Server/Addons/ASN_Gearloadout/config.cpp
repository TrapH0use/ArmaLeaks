class CfgPatches {
    class ASN_Gearloadout {
        units[] = {};
        weapons[] = {};
        requiredAddons[] = {
            "A3_UI_F",
            "A3_Data_F",
            "asn_core"
        };
        author[] = {
            "Blue alias C0kkie"
        };
    };
};
class ASN_config_ASN_Gearloadout {
    version = "2.0.6";
};
class CfgFunctions {
    class ASN_Gearloadout {
        tag = "ASN";
        class Client_Init {
            file = "\ASN_Gearloadout";
            class initgearloadout {
                preinit = 1;
            };
        };
        class Gearloadout_Server {
            file = "\ASN_Gearloadout\Server_Functions";
            class Getloadouts_serv {};
            class Savegear_serv {};
            class gearupdateentry_serv {};
            class deletegear_serv {};
        };
    };
};
delete RscDisplayFunctionsViewer;
delete RscDisplayDebugPublic;
delete RscDisplayDebug;
delete RscDisplayConfigViewer;