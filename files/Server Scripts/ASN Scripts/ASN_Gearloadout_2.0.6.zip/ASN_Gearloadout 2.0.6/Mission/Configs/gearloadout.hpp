class ASN_Gearloadout
{
	//Translations
	error = "Something went wrong!";
	price = "Price";
	currency = "€";
	title = "Gearloadouts";
	loadoutloaded = "Loadout successfully loaded!";

	dialog_buy = "Buy";
	dialog_Close = "Close";
	dialog_gearname = "Enter the gearname";
	dialog_delete = "Delete Entry";
	dialog_entry = "Rename entry";
	dialog_saveyitems = "Save Gear (with y-Item)";
	dialog_savegear = "Save Gear";
	dialog_onetimesave = "1 time save";
	dialog_onetimesave2 = "1 time save (with y-Item)";
	dialog_onetimesavetooltip = "Save the current gear once, and you will get it for free next time";

	//Settings
	cash_var = "life_cash";	//--Your money variable
	closebuy = 1;	//Close the Loadout Window after Buy? -- 1 = true -- 0 = false

	//-- Price Settings
	price_per_uniform = 500; //-- Price per Uniform
	price_per_vest = 100; //-- Price per Vest
	price_per_backpack = 200; //-- Price per Backpack
	price_per_google = 10; //-- Price per Google Item
	price_per_headgear = 100; //-- Price per Headgear Item
	price_per_rifles = 1000; //-- Price per Rifle
	price_per_handguns = 900; //-- Price per Handgun
	price_per_launcher = 100; //-- Price per Rocketlauncher
	price_per_magazine = 5; //-- Price per Magazine
	price_per_weaponitem = 15; //-- Price per Weapon Accessory
	price_per_items = 10; //-- Price per Item which is not listen above
};