DROP TABLE IF EXISTS `gearloadouts`;
CREATE TABLE IF NOT EXISTS `gearloadouts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` varchar(30) NOT NULL DEFAULT '0',
  `side` varchar(30) NOT NULL DEFAULT '0',
  `gearname` varchar(128) NOT NULL DEFAULT '0',
  `gearitems` longtext NOT NULL,
  `yitems` longtext NOT NULL,
  `tmp` int(2) NOT NULL DEFAULT 0,
  `insert_time` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;