CREATE TABLE IF NOT EXISTS `asn_fuelstations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sqmvar` varchar(50) DEFAULT NULL,
  `rented` int(11) DEFAULT '0',
  `rentername` varchar(50) DEFAULT NULL,
  `renteruid` varchar(50) DEFAULT NULL,
  `oilamount` decimal(10,2) DEFAULT '0.00',
  `fuelprice` int(11) DEFAULT '0',
  `rentdue` timestamp NULL DEFAULT NULL,
  `currentbank` int(11) DEFAULT '0',
  `inserted` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `active` int(11) DEFAULT '1',
  `oilsellprice` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;