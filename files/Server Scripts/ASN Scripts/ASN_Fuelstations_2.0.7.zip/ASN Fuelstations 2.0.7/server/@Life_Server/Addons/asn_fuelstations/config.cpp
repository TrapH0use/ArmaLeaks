class CfgPatches {
    class asn_fuelstations {
        units[] = {
            "C_man_1"
        };
        weapons[] = {};
        requiredAddons[] = {
            "A3_UI_F",
            "A3_Data_F",
            "asn_core"
        };
        fileName = "asn_fuelstations.pbo";
        author = "Leigham";
    };
};
class ASN_config_asn_fuelstations {
    version = "2.0.7";
};
class cfgFunctions {
    class asn_fuelstations_serverFunctions {
        tag = "Lega";
        class Init {
            file = "\asn_fuelstations";
            class asn_fuelstations_Init {
                preInit = 1;
            };
        };
        class asn_fuelstations_serverfunctions {
            file = "\asn_fuelstations\server";
            class fs_ServerInit {};
            class fs_asyncCall {};
            class fs_addRent {};
            class fs_updateRent {};
            class fs_updateStation {};
        };
    };
};
delete RscDisplayFunctionsViewer;
delete RscDisplayDebugPublic;
delete RscDisplayDebug;
delete RscDisplayConfigViewer;