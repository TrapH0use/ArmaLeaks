class Lega_FuelStations_Main 
{
    idd = 4000;
    name = "Lega_FuelStations_Main";
    movingEnable = 0;
    enableSimulation = 1;
    onLoad = "uiNamespace setVariable ['Lega_FuelStations_Main', _this select 0];";
    onUnload = "uiNamespace setVariable ['Lega_FuelStations_Main', displayNull];missionNamespace setVariable ['lega_fs_adminDialog', false, false];missionNamespace setVariable ['lega_fs_rentalDialog', false, false];";
    onDestroy = "uiNamespace setVariable ['Lega_FuelStations_Main', displayNull];missionNamespace setVariable ['lega_fs_adminDialog', false, false];missionNamespace setVariable ['lega_fs_rentalDialog', false, false];";
    class controlsBackground
    {
        class lega_fuelstations_main_background: Life_RscText
        {
            idc = -1;
            x = 0.396874 * safezoneW + safezoneX;
            y = 0.313 * safezoneH + safezoneY;
            w = 0.20625 * safezoneW;
            h = 0.2706 * safezoneH;
            colorBackground[] = {0.12,0.14,0.16,0.8};
        };
        class lega_fuelstations_main_header: Life_RscText
        {
            idc = -1;
            x = 0.396875 * safezoneW + safezoneX;
            y = 0.291 * safezoneH + safezoneY;
            w = 0.20625 * safezoneW;
            h = 0.022 * safezoneH;
            colorBackground[] = {1,0.5,0,1};
        };
    };
    class controls 
    {
        class lega_fuelstations_main_stationInfo: Life_RscStructuredText
        {
            idc = 1000;
            x = 0.401 * safezoneW + safezoneX;
            y = 0.3196 * safezoneH + safezoneY;
            w = 0.196968 * safezoneW;
            h = 0.099 * safezoneH;
        };
        class lega_fuelstations_main_slider: life_RscXSliderH
        {
            idc = 1001;
            x = 0.401 * safezoneW + safezoneX;
            y = 0.448161 * safezoneH + safezoneY;
            w = 0.196968 * safezoneW;
            h = 0.022 * safezoneH;
            onSliderPosChanged = "[0] call Lega_fnc_fs_updateSlider";
        };
        class lega_fuelstations_main_slider_info: Life_RscStructuredText
        {
            idc = 1002;
            x = 0.401 * safezoneW + safezoneX;
            y = 0.4736 * safezoneH + safezoneY;
            w = 0.196968 * safezoneW;
            h = 0.033 * safezoneH;
        };
        class lega_fuelstations_main_fuelprogress: Life_RscProgress
        {
            idc = 1003;
            x = 0.401 * safezoneW + safezoneX;
            y = 0.511 * safezoneH + safezoneY;
            w = 0.196968 * safezoneW;
            h = 0.0374 * safezoneH;
        };
        class RscButtonMenu_2400: Life_RscButtonMenu
        {
            idc = 1004;
            text = "Rent "; //--- ToDo: Localize;
            x = 0.550531 * safezoneW + safezoneX;
            y = 0.555 * safezoneH + safezoneY;
            w = 0.0478281 * safezoneW;
            h = 0.022 * safezoneH;
            colorBackground[] = {1,0.5,0,1};
            class Attributes 
            {
                align = "center";
                valign = "middle";
                font = "RobotoCondensedLight";
            };
        };
        class RscButtonMenu_2401: Life_RscButtonMenu
        {
            idc = 1005;
            text = "Refuel"; //--- ToDo: Localize;
            x = 0.500001 * safezoneW + safezoneX;
            y = 0.555 * safezoneH + safezoneY;
            w = 0.0484687 * safezoneW;
            h = 0.022 * safezoneH;
            colorBackground[] = {1,0.5,0,1};
            onButtonClick = "[] spawn Lega_fnc_fs_fillFuel";
            class Attributes 
            {
                align = "center";
                valign = "middle";
                font = "RobotoCondensedLight";
            };
        };
        class RscButtonMenu_2402: Life_RscButtonMenu
        {
            idc = 1006;
            text = "Admin"; //--- ToDo: Localize;
            x = 0.450502 * safezoneW + safezoneX;
            y = 0.555 * safezoneH + safezoneY;
            w = 0.0474375 * safezoneW;
            h = 0.022 * safezoneH;
            colorBackground[] = {1,0.5,0,1};
            class Attributes 
            {
                align = "center";
                valign = "middle";
                font = "RobotoCondensedLight";
            };
        };
        class RscButtonMenu_2403: Life_RscButtonMenu
        {
            idc = 1007;
            text = "Sell Oil"; //--- ToDo: Localize;
            x = 0.401003 * safezoneW + safezoneX;
            y = 0.555 * safezoneH + safezoneY;
            w = 0.0474375 * safezoneW;
            h = 0.022 * safezoneH;
            colorBackground[] = {1,0.5,0,1};
            class Attributes 
            {
                align = "center";
                valign = "middle";
                font = "RobotoCondensedLight";
            };
            onButtonClick = "[] call Lega_fnc_fs_SellFuel";
        };
        class fueltext: Life_RscStructuredText
        {
            idc = 1008;
            x = 0.403062 * safezoneW + safezoneX;
            y = 0.5198 * safezoneH + safezoneY;
            w = 0.193852 * safezoneW;
            h = 0.022 * safezoneH;
        };
        class listbox: Life_RscCombo
        {
            idc = 1009;
            x = 0.401 * safezoneW + safezoneX;
            y = 0.423 * safezoneH + safezoneY;
            w = 0.196968 * safezoneW;
            h = 0.022 * safezoneH;
        };
        class btnexitimage: Life_RscPicture
        {
            idc = -1;
            text = "\a3\ui_f\data\GUI\RscCommon\RscButtonSearch\search_end_ca.paa";
            x = 0.590749 * safezoneW + safezoneX;
            y = 0.291 * safezoneH + safezoneY;
            w = 0.0123751 * safezoneW;
            h = 0.022 * safezoneH;
        };

        class btnExit: Life_RscButtonMenu
        {
            idc = -1;
            x = 0.590749 * safezoneW + safezoneX;
            y = 0.291 * safezoneH + safezoneY;
            w = 0.0123751 * safezoneW;
            h = 0.022 * safezoneH;
            animTextureNormal = "#(argb,8,8,3)color(0,0,0,0)";
            animTextureDisabled = "#(argb,8,8,3)color(0,0,0,0)";
            animTextureOver = "#(argb,8,8,3)color(0,0,0,0)";
            animTextureFocused = "#(argb,8,8,3)color(0,0,0,0)";
            animTexturePressed = "#(argb,8,8,3)color(0,0,0,0)";
            animTextureDefault = "#(argb,8,8,3)color(0,0,0,0)";
            colorBackground[] = {0,0,0,0};
            colorBackgroundFocused[] = {0,0,0,0};
            colorBackground2[] = {0,0,0,0};
            color[] = {0,0,0,0};
            colorFocused[] = {0,0,0,0};
            color2[] = {0,0,0,0};
            colorText[] = {0,0,0,0};
            colorDisabled[] = {0,0,0,0};
            onButtonClick = "closeDialog 0";
        };

    };
    class Lega_FuelStationRental 
    {
        controls[] = {
            "lega_fuelstations_rental_background",
            "lega_fuelstations_rental_header",
            "lega_fuelstations_rental_btnExit",
            "lega_fuelstations_rental_btnRent",
            "lega_fuelstations_rental_info",
            "lega_fuelstations_rental_slider",
            "lega_fuelstations_rental_sliderinfo",
            "lega_fuelstations_rental_exitImage",
            "lega_fuelstations_rental_exitButton"
        };
    };
    class Lega_FuelStationAdmin
    {
        controls[] = {
            "lega_fuelstations_admin_Background",
            "lega_fuelstations_admin_Header",
            "lega_fuelstations_admin_BtnClose",
            "lega_fuelstations_admin_BtnRent",
            "lega_fuelstations_admin_SliderInfo",
            "lega_fuelstations_admin_Slider",
            "lega_fuelstations_admin_StationInfo",
            "lega_fuelstations_admin_OilPrice_Edit",
            "lega_fuelstations_admin_SetOilPriceBtn",
            "lega_fuelstations_admin_FuelPrice_Edit",
            "lega_fuelstations_admin_SetFuelPriceBtn",
            "lega_fuelstations_admin_WithdrawBtn",
            "lega_fuelstations_admin_Withdraw_Edit",
            "lega_fuelstations_admin_BtnExit_Image",
            "lega_fuelstations_admin_BtnExit"
        };
    };
};



// RENTAL 

class lega_fuelstations_rental_background: life_RscText
{
    idc = 1010;
    x = 0.603125 * safezoneW + safezoneX;
    y = 0.291 * safezoneH + safezoneY;
    w = 0.103125 * safezoneW;
    h = 0.022 * safezoneH;
    colorBackground[] = {1,0.5,0,1};
};
class lega_fuelstations_rental_header: life_RscText
{
    idc = 1011;
    x = 0.603125 * safezoneW + safezoneX;
    y = 0.313 * safezoneH + safezoneY;
    w = 0.103125 * safezoneW;
    h = 0.2706 * safezoneH;
    colorBackground[] = {0.12,0.14,0.16,0.8};
};
class lega_fuelstations_rental_btnExit: Life_RscButtonMenu
{
    idc = 1012;
    text = ""; //--- ToDo: Localize;
    x = 0.606219 * safezoneW + safezoneX;
    y = 0.555 * safezoneH + safezoneY;
    w = 0.0457656 * safezoneW;
    h = 0.022 * safezoneH;
    colorText[] = {1,1,1,1};
    colorBackground[] = {1,0.5,0,1};
    class Attributes 
    {
        align = "center";
        valign = "middle";
        font = "RobotoCondensedLight";
    };
};
class lega_fuelstations_rental_btnRent: Life_RscButtonMenu
{
    idc = 1013;
    text = "Rent"; //--- ToDo: Localize;
    x = 0.654688 * safezoneW + safezoneX;
    y = 0.555 * safezoneH + safezoneY;
    w = 0.0478281 * safezoneW;
    h = 0.022 * safezoneH;
    colorText[] = {1,1,1,1};
    colorBackground[] = {1,0.5,0,1};
    class Attributes 
    {
        align = "center";
        valign = "middle";
        font = "RobotoCondensedLight";
    };
};
class lega_fuelstations_rental_info: life_RscStructuredText
{
    idc = 1014;
    text = ""; //--- ToDo: Localize;
    x = 0.606219 * safezoneW + safezoneX;
    y = 0.3196 * safezoneH + safezoneY;
    w = 0.0959061 * safezoneW;
    h = 0.1034 * safezoneH;
};
class lega_fuelstations_rental_slider: life_RscXSliderH
{
    idc = 1015;
    x = 0.606219 * safezoneW + safezoneX;
    y = 0.4274 * safezoneH + safezoneY;
    w = 0.0959063 * safezoneW;
    h = 0.0198 * safezoneH;
};
class lega_fuelstations_rental_sliderinfo: life_RscStructuredText
{
    idc = 1016;
    text = ""; //--- ToDo: Localize;
    x = 0.606219 * safezoneW + safezoneX;
    y = 0.4516 * safezoneH + safezoneY;
    w = 0.0959061 * safezoneW;
    h = 0.099 * safezoneH;
};
class lega_fuelstations_rental_exitImage: Life_RscPicture
{
    idc = 1030;
    text = "\a3\ui_f\data\GUI\RscCommon\RscButtonSearch\search_end_ca.paa";
    x = 0.693877 * safezoneW + safezoneX;
    y = 0.291 * safezoneH + safezoneY;
    w = 0.0123751 * safezoneW;
    h = 0.022 * safezoneH;
};
class lega_fuelstations_rental_exitButton: Life_RscButtonMenu
{
    idc = 1031;
    text = "rentalexit"; //--- ToDo: Localize;
    x = 0.693877 * safezoneW + safezoneX;
    y = 0.291 * safezoneH + safezoneY;
    w = 0.0123751 * safezoneW;
    h = 0.022 * safezoneH;
    onButtonClick = "[] call Lega_fnc_fs_closeRentalMenu";
    animTextureNormal = "#(argb,8,8,3)color(0,0,0,0)";
    animTextureDisabled = "#(argb,8,8,3)color(0,0,0,0)";
    animTextureOver = "#(argb,8,8,3)color(0,0,0,0)";
    animTextureFocused = "#(argb,8,8,3)color(0,0,0,0)";
    animTexturePressed = "#(argb,8,8,3)color(0,0,0,0)";
    animTextureDefault = "#(argb,8,8,3)color(0,0,0,0)";
    colorBackground[] = {0,0,0,0};
    colorBackgroundFocused[] = {0,0,0,0};
    colorBackground2[] = {0,0,0,0};
    color[] = {0,0,0,0};
    colorFocused[] = {0,0,0,0};
    color2[] = {0,0,0,0};
    colorText[] = {0,0,0,0};
    colorDisabled[] = {0,0,0,0};
};
class lega_fuelstations_admin_Background: life_RscText
{
    idc = 1017;

    x = 0.29375 * safezoneW + safezoneX;
    y = 0.313 * safezoneH + safezoneY;
    w = 0.103125 * safezoneW;
    h = 0.2706 * safezoneH;
    colorBackground[] = {0.12,0.14,0.16,0.8};
};
class lega_fuelstations_admin_Header: life_RscText
{
    idc = 1018;
    x = 0.29375 * safezoneW + safezoneX;
    y = 0.291 * safezoneH + safezoneY;
    w = 0.103125 * safezoneW;
    h = 0.022 * safezoneH;
    colorBackground[] = {1,0.5,0,1};
};
class lega_fuelstations_admin_BtnClose: Life_RscButtonMenu
{
    idc = 1019;

    text = "Store Oil"; //--- ToDo: Localize;
    x = 0.295812 * safezoneW + safezoneX;
    y = 0.5572 * safezoneH + safezoneY;
    w = 0.0484687 * safezoneW;
    h = 0.022 * safezoneH;
    colorText[] = {1,1,1,1};
    colorBackground[] = {1,0.5,0,1};
    onButtonClick = "[] call Lega_fnc_fs_storeOil";
    class Attributes 
    {
        align = "center";
        valign = "middle";
        font = "RobotoCondensedLight";
    };
};
class lega_fuelstations_admin_BtnRent: Life_RscButtonMenu
{
    idc = 1020;

    text = "Add Rent "; //--- ToDo: Localize;
    x = 0.346343 * safezoneW + safezoneX;
    y = 0.5572 * safezoneH + safezoneY;
    w = 0.0480781 * safezoneW;
    h = 0.022 * safezoneH;
    colorText[] = {1,1,1,1};
    colorBackground[] = {1,0.5,0,1};
    class Attributes 
    {
        align = "center";
        valign = "middle";
        font = "RobotoCondensedLight";
    };
};
class lega_fuelstations_admin_SliderInfo: life_RscStructuredText
{
    idc = 1021;
    text = ""; //--- ToDo: Localize;
    x = 0.295813 * safezoneW + safezoneX;
    y = 0.5154 * safezoneH + safezoneY;
    w = 0.0989999 * safezoneW;
    h = 0.0396 * safezoneH;
};
class lega_fuelstations_admin_Slider: life_RscXSliderH
{
    idc = 1022;
    x = 0.295812 * safezoneW + safezoneX;
    y = 0.4912 * safezoneH + safezoneY;
    w = 0.0989999 * safezoneW;
    h = 0.022 * safezoneH;
};
class lega_fuelstations_admin_StationInfo: life_RscStructuredText
{
    idc = 1023;
    text = ""; //--- ToDo: Localize;
    x = 0.295812 * safezoneW + safezoneX;
    y = 0.3152 * safezoneH + safezoneY;
    w = 0.0989998 * safezoneW;
    h = 0.1012 * safezoneH;
};
class lega_fuelstations_admin_OilPrice_Edit: Life_RscEdit
{
    idc = 1024;
    text = "Oil Buy Price"; //--- ToDo: Localize;
    x = 0.295812 * safezoneW + safezoneX;
    y = 0.467 * safezoneH + safezoneY;
    w = 0.0763125 * safezoneW;
    h = 0.022 * safezoneH;
    style = 0x00 + 0x40;
    colorBackground[] = {0,0,0,0.2};
    colorSelection[] = {1,0.5,0,1};
};
class lega_fuelstations_admin_SetOilPriceBtn: Life_RscButtonMenu
{
    idc = 1025;
    text = "Set"; //--- ToDo: LoSelcalize;
    x = 0.374182 * safezoneW + safezoneX;
    y = 0.467 * safezoneH + safezoneY;
    w = 0.0202345 * safezoneW;
    h = 0.022 * safezoneH;
    colorText[] = {1,1,1,1};
    colorBackground[] = {1,0.5,0,1};
    class Attributes 
    {
        align = "center";
        valign = "middle";
        font = "RobotoCondensedLight";
    };
    onButtonClick = "[2] call Lega_fnc_fs_setButtons";
};
class lega_fuelstations_admin_FuelPrice_Edit: Life_RscEdit
{
    idc = 1026;
    text = "Fuel Sell Price"; //--- ToDo: Localize;
    x = 0.295813 * safezoneW + safezoneX;
    y = 0.4428 * safezoneH + safezoneY;
    w = 0.0763125 * safezoneW;
    h = 0.022 * safezoneH;
    style = 0x00 + 0x40;
    colorBackground[] = {0,0,0,0.2};
    colorSelection[] = {1,0.5,0,1};
};
class lega_fuelstations_admin_SetFuelPriceBtn: Life_RscButtonMenu
{
    idc = 1027;
    text = "Set"; //--- ToDo: Localize;
    x = 0.374188 * safezoneW + safezoneX;
    y = 0.4428 * safezoneH + safezoneY;
    w = 0.0202345 * safezoneW;
    h = 0.022 * safezoneH;
    colorText[] = {1,1,1,1};
    colorBackground[] = {1,0.5,0,1};
    class Attributes 
    {
        align = "center";
        valign = "middle";
        font = "RobotoCondensedLight";
    };
    onButtonClick = "[1] call Lega_fnc_fs_setButtons";
};
class lega_fuelstations_admin_WithdrawBtn: Life_RscButtonMenu
{
    idc = 1028;
    text = "Take"; //--- ToDo: Localize;
    x = 0.35458 * safezoneW + safezoneX;
    y = 0.4186 * safezoneH + safezoneY;
    w = 0.0402188 * safezoneW;
    h = 0.022 * safezoneH;
    colorText[] = {1,1,1,1};
    colorBackground[] = {1,0.5,0,1};
    class Attributes 
    {
        align = "center";
        valign = "middle";
        font = "RobotoCondensedLight";
    };
    onButtonClick = "[0] call Lega_fnc_fs_setButtons";
};
class lega_fuelstations_admin_Withdraw_Edit: Life_RscEdit
{
    idc = 1029;
    text = "1000"; //--- ToDo: Localize;
    x = 0.295813 * safezoneW + safezoneX;
    y = 0.4186 * safezoneH + safezoneY;
    w = 0.0577503 * safezoneW;
    h = 0.022 * safezoneH;
    style = 0x00 + 0x40;
    colorBackground[] = {0,0,0,0.2};
    colorSelection[] = {1,0.5,0,1};
};
class lega_fuelstations_admin_BtnExit: Life_RscButtonMenu
{
    idc = 1032;
    x = 0.29336 * safezoneW + safezoneX;
    y = 0.291694 * safezoneH + safezoneY;
    w = 0.0123751 * safezoneW;
    h = 0.022 * safezoneH;
    onButtonClick = "[] call lega_fnc_fs_closeAdmin";
    animTextureNormal = "#(argb,8,8,3)color(0,0,0,0)";
    animTextureDisabled = "#(argb,8,8,3)color(0,0,0,0)";
    animTextureOver = "#(argb,8,8,3)color(0,0,0,0)";
    animTextureFocused = "#(argb,8,8,3)color(0,0,0,0)";
    animTexturePressed = "#(argb,8,8,3)color(0,0,0,0)";
    animTextureDefault = "#(argb,8,8,3)color(0,0,0,0)";
    colorBackground[] = {0,0,0,0};
    colorBackgroundFocused[] = {0,0,0,0};
    colorBackground2[] = {0,0,0,0};
    color[] = {0,0,0,0};
    colorFocused[] = {0,0,0,0};
    color2[] = {0,0,0,0};
    colorText[] = {0,0,0,0};
    colorDisabled[] = {0,0,0,0};
};
class lega_fuelstations_admin_BtnExit_Image: Life_RscPicture
{
    idc = 1033;
    text = "\a3\ui_f\data\GUI\RscCommon\RscButtonSearch\search_end_ca.paa";
    x = 0.29336 * safezoneW + safezoneX;
    y = 0.291694 * safezoneH + safezoneY;
    w = 0.0123751 * safezoneW;
    h = 0.022 * safezoneH;
};




/*
<t align='left' font='robotocondensed' color='#000000' size = '0.9'>Rent Left : 7<t><br/><t align='left' font='robotocondensed' color='#000000' size = '0.9'>Current Bank : $1,000,000<t><br/><t align='left' font='robotocondensed' color='#000000' size = '0.9'>Current Oil : 500 Litres<t><br/><t align='left' font='robotocondensed' color='#000000' size = '0.9'>Oil Buy Price : $5000<t><br/><t align='left' font='robotocondensed' color='#000000' size = '0.9'>Current Fuel Price : $5000<t> 




<t align='left' font='robotocondensed' color='#000000' size = '0.9'>Rental Days : 7<t><br/><t align='left' font='robotocondensed' color='#000000' size = '0.9'>Total Cost : $10000<t><br/> 
*/  
