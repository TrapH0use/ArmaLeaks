class lega_fuelstation_config 
{   
    //Main Settings. 
    extdbVersion = 3;//what version of extdb. // extdb3 == 3 // extdb2 == 2 //  only 2 + 3 supported
    stationObjects[] = {"station_shop_1","station_shop_2","station_shop_3","station_shop_4","station_shop_5","station_shop_6","station_shop_7","station_shop_8","station_shop_9","station_shop_10","station_shop_11","station_shop_12","station_shop_13","station_shop_14","station_shop_15","station_shop_16","station_shop_17","station_shop_18","station_shop_19","station_shop_20","station_shop_21","station_shop_22","station_shop_23"};//Objects for the actions for fuel stations.

    pumpTypes[] = {//Pump objects we are going to use to get nearby vehicles
        "Land_fs_feed_F","Land_FuelStation_01_pump_F","Land_FuelStation_02_pump_F"
    };

    vehicleDistance = 10; // how far the vehicle can be from the fuel pumps
    maxrentaltime = 7;//time in days for people to be able to rent maximum
    distanceToSearch = 100; //how far to search from the station object for fuel pumps.
    pricePerDay = 10000;//price per day to rent a station.
    fillPerLoop = 0.01; // how much fuel to put in the vehicle per loop 0.01 means it will fill in 100 loops with a 0.1 second sleep 
    defaultPrice = 90; // default price per litre for unowned stations.
    ownableStations = 1;// how many stations you want a player to be able to own.

    //Robbery Settings.
    robbableStations = true;//do you want people to be able to rob the owned stations
    maxRobberyPercentage = 20; // only if `robbableStations = true`// the max% of the fuel stations bank the player can get out with ?
    robberyDistance = 100;
    lockinAnimation = false; 
    animation = "";
    neededItem = "";
    needsWeapon = false;
    copsNeeded = 0;
    requiredLicenses[] = {
        {"license_civ_trucking", "Trucking License"}
    };
    timebetweenrobberys = 600;// time in seconds between robberys // 600 / 60 = 10 minutes 
    timetoRob = 60; // time in seconds it takes to rob a fuel station

    //Fuel Supply Settings. 
    supplyOil = true;//do you want the player to have to supply oil.

    // Below is only used if supply oil is on.
    oilItem = "oil_processed";
    sellOil = true; // do you want people to be able to sell oil at the stations to refill fuel.
    litrePerOil = 100;
    defaultOilSellPrice = 50; // only applicable if `sellOil` is true
    allowNegative = true; // if fuel reaches 0, then apply a negative bank balance, if the player doesn't pay, remove his ownership
    pricepernegativelitre = 50;

    class strings 
    {
        notenoughcashfordays = "You don't have enough cash on your for that many days";
        nooiltostore = "You do not have any oil to store";
        errorremovingitems = "There was an error removing the items, please check and try again";
        oilStored = "You have stored %1 %2 (s) which has been converted into %3 fuel";
        err_oilprice = "You must enter an amount you want to change the oil buy price to!";
        succ_oilPrice = "You have changed the buy price for oil in your station to $%1";
        err_fuelprice = "You must enter an amount you want to change the fuel price to!";
        succ_fuelPrice = "You have changed the price of fuel in your station to $%1";
        withdrawn = "You have withdrawn $%1 from the fuel stations account";
        err_notEnoughWithdraw = "There is not enough in the fuel stations account to withdraw!";
        err_withdrawamount = "You must enter an amount you want to withdraw";
        rentLeft = "Rent Left : %1 Days";
        currentBank = "Current Bank : $%1";
        fuelCount = "Fuel : %1 Litres";
        oilBuyPrice = "Oil Buy Price : $%1";
        na = "N/A";
        fuelstr = "Fuel";
        fuelPrice = "Current Fuel Price : $%1";
        rentalDays = "Rental Days : ";
        totalRentalPrice = "Rental Price : ";
        alreadyRobbing = "Someone else is already robbing the fuel station";
        litres = "Litres";
        price = "Price";
        recentlyRobbed = "The fuel station has recently been robbed!";
        ownerNotOnline = "The fuel station owner must be online to rob it!";
        noMoney = "The fuel station does not have any money to steal!";
        missinglicensesheader = "Missing Licenses";
        missinglicenses = "You are missing the following licenses needed to rob this fuel station";
        needsWeapon = "You must have a weapon out to rob the fuel station";
        needsItem = "You need a %1 to rob the gas station!";
        stationRobbery = "A Fuel Station robbery is in progress near ";
        yourStationRobbery = "Your Fuel Station is being robbed near ";
        toofar = "You have moved to far from the station and the robbery has failed";
        robberyCancelled = "You have cancelled the fuel station robbery";
        notfromvehicle = "You cant rob the fuel station from a vehicle";
        yourobbedamount = "You have robbed $%1 from the fuel station";
        nooiltosell = "You do not have any oil to sell";
        yousolditems = "You have sold %1 %2 (s) for $%3";
        youRented = "You have rented the fuel station for %1 days";
        unabletorent = "You are unable to add rent to that station, as it is already rented by someone else";
        addedRent = "You have added %1 days to your rent.";
        fuelstation = "Fuel Station";
        robfuelStation = "Rob Fuel Station";
        driversSeat = "You must get into the drivers seat before trying to refil the vehicle";
        engineOff = "Then engine can't be running whilst refuling the vehicle";
        min1litre = "You must refuel by more then 1 litre";
        notenoughcash = "You do not have enough cash for this much fuel!";
        outofFuel = "The fuel station has ran out of fuel after delivering %1 litres, you have been refunded $%2";
        youfilledfuel = "You have refueled your %1 by %2 litres";
        stationOwner = "Station Owner";
        priceperlitre = "Price Per Litre";
        RentPerday = "Rent (Per Day)";
        maxDays = "Maximum Days";
        maxStation = "You already own the maximum amount of fuel stations";
        notenoughstationmoney = "The station does not have that much money!";
        notenoughmoney = "You do not have enough money to rent that fuel station for that long.";
    };
};

#include "dialogs.hpp"
