//fuel station 
F(lega_fnc_fs_addRent, SERVER)
F(Lega_fnc_fs_updateRent, SERVER)
F(lega_fnc_fs_updatestation, SERVER)