class ASN_MobileSpeedcam
{
	//Translations
	no50m = "In a 50m Range is only 1 speedcam allowed!";
	placespeedcam = "Place mobile speed camera";
	notanumber = "You didn't enter an actual number format.";
	error = "Something went wrong!";
	placesuccess = "You placed the Speedcam successfully, if you are more then 100 Meters away, the speedcam will be disable!";
	floating = "The speedcam is floating!";
	tofaraway = "The mobile speedcam got disabled, you are to far away!";
	activateagain = "The mobile speedcam enabled!";
	vehiclenumberplate = "Number Plate";
	vehspeed = "Speed";
	speedcamreset = "Reset Speedcam";
	deletespeedcam = "Remove Mobile Speedcam";
	result = "Speedcam Result";
	maxspeeddialog = "Set maximum Speed";
	maxspeeddialog2 = "Maximum Speed";

	//Settings
	MobileSpeedcams = 50;	//Every how many meters is a speedcam allowed?
	metersaway = 100;	//How many Meters can the guy which placed the speedcam away?
	vitemclassname = "mobile_speedcam";
	removeitemonuse = 1;	//Should the vitem been removed after usage? -- 1 / yes -- 0 / no
};