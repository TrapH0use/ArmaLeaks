class ALT_SelectOption {
   idd = 1246;
   name = "ALT_SelectOption";
   movingenable = false;
   enablesimulation = true;
   class controlsBackground
   {
   	   class ALT_Background: Life_RscText
       {
           x = 0.376041666666667 * safezoneW + safezoneX;
           y = 0.379277286135693 * safezoneH + safezoneY;
           w = 0.311458333333333 * safezoneW;
           h = 0.184144542772861 * safezoneH;
           idc = 1000;
           show = 0;
           colorBackground[] = {0,0,0,0.7};
       };

       class ALT_TopBar: Life_RscText
       {
           x = 0.376041666666667 * safezoneW + safezoneX;
           y = 0.345132743362832 * safezoneH + safezoneY;
           w = 0.311458333333333 * safezoneW;
           h = 0.0340585054080632 * safezoneH;
           idc = 1001;
           show = 0;
           colorBackground[] = {0,0,0,0.8};
       };

       class ALT_TitleText: Life_RscText
       {
          x = 0.38125 * safezoneW + safezoneX;
          y = 0.345132743362832 * safezoneH + safezoneY;
          h = 0.0340585054080632 * safezoneH;
          w = 0.302083333333333 * safezoneW;
          text = "ALT Transfer Ownership Menu";
          show = 0;
          idc = 1002;
       };
   };
   class controls
   {
       class ALT_Question : Life_RscText
       {
           x = 0.38125 * safezoneW + safezoneX;
           y = 0.398412487708948 * safezoneH + safezoneY;
           h = 0.037 * safezoneH;
           w = 0.3 * safezoneW;
           text = "What would you like to transfer?";
           idc = 1003;
           show = 0;
       };
       class ALT_Vehicles : Life_RscButtonMenu
       {
           idc = 1004;
           text = "Vehicles";
           x = 0.38125 * safezoneW + safezoneX;
           y = 0.452368401179941 * safezoneH + safezoneY;
           w = 0.298958333333333 * safezoneW;
           h = 0.039216 * safezoneH;
           colorBackground[] = {0,0,0,0.8};
           show = 0;
       };
       class ALT_Houses : Life_RscButtonMenu
       {
           idc = 1005;
           text = "Houses";
           x = 0.38125 * safezoneW + safezoneX;
           y = 0.501532609636185 * safezoneH + safezoneY;
           w = 0.298958333333333 * safezoneW;
           h = 0.039216 * safezoneH;
           colorBackground[] = {0,0,0,0.8};
           show = 0;
       };
       class ALT_Close : Life_RscButtonMenu
       {
           idc = 1006;
           text = "Close";
           onButtonClick = "closeDialog 0;";
           x = 0.376041666666667 * safezoneW + safezoneX;
           y = 0.562496228121927 * safezoneH + safezoneY;
           w = 0.311458333333333 * safezoneW;
           h = 0.0343572625368731 * safezoneH;
           colorBackground[] = {0,0,0,0.8};
           show = 0;
       };
   };
};

class ALT_TransferMenu {
   idd = 1247;
   name = "ALT_TransferMenu";
   movingenable = false;
   enablesimulation = true;
   class controlsBackground
   {
       class ALT_Background : Life_RscText
       {
           x = 0.376041666666667 * safezoneW + safezoneX;
           y = 0.347099311701082 * safezoneH + safezoneY;
           w = 0.311458333333333 * safezoneW;
           h = 0.216322517207472 * safezoneH;
           idc = 1000;
           colorbackground[] = {0,0,0,0.7};
           show = 0;
       };
       class ALT_TopBar : Life_RscText
       {
           x = 0.376041666666667 * safezoneW + safezoneX;
           y = 0.313667649950836 * safezoneH + safezoneY;
           w = 0.311458333333333 * safezoneW;
           h = 0.0344149459193706 * safezoneH;
           idc = 1001;
           colorbackground[] = {0,0,0,0.8};
           show = 0;
       };
       class ALT_TitleText : Life_RscText
       {
          x = 0.38125 * safezoneW + safezoneX;
          y = 0.314650934119961 * safezoneH + safezoneY;
          h = 0.0334316617502457 * safezoneH;
          w = 0.3015625 * safezoneW;
          text = "ALT Transfer Ownership Menu";
          idc = 1002;
          show = 0;
       };
   };
   class controls
   {
       class ALT_PlayerList : Life_RscCombo
       {
           x = 0.38125 * safezoneW + safezoneX;
           y = 0.521140609636185 * safezoneH + safezoneY;
           w = 0.197395833333333 * safezoneW;
           h = 0.0304241258603737 * safezoneH;
           idc = 1004;
           show = 0;
       };
       class ALT_Listbox : Life_RscListBox
       {
           idc = 1500;
           w = 0.3015625 * safezoneW;
           h = 0.155358898721731 * safezoneH;
           x = 0.38125 * safezoneW + safezoneX;
           y = 0.355948869223206 * safezoneH + safezoneY;
           show = 0;
       };
       class ALT_Transfer : Life_RscButtonMenu
       {
           idc = 1005;
           text = "Transfer Ownership";
           x = 0.584375 * safezoneW + safezoneX;
           y = 0.52212389380531 * safezoneH + safezoneY;
           w = 0.0979166666666667 * safezoneW;
           h = 0.0304241258603737 * safezoneH;
           colorbackground[] = {0,0,0,0.8};
           show = 0;
       };
       class ALT_Close : Life_RscButtonMenu
       {
           idc = 1006;
           text = "Close";
           onButtonClick = "closeDialog 0;";
           x = 0.376041666666667 * safezoneW + safezoneX;
           y = 0.562496228121927 * safezoneH + safezoneY;
           w = 0.311458333333333 * safezoneW;
           h = 0.0343572625368731 * safezoneH;
           colorbackground[] = {0,0,0,0.8};
           show = 0;
       };
   };
};