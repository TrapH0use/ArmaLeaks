/*
    File: ALT_TransferOwnership.hpp
    Author: Arma Love Team (Armaservices.net)
    Description: Master config for ALT_TransferOwnership.hpp
*/
#include "..\dialog\ALT_VehicleOwnership.hpp"
#define true 1
#define false 0

class ALT_TransferOwnership_Config {
	version = 5; // version 3.x -> 3 | 4.0 - 4.3 -> 4 | version 4.4+ -> 5
	DialogFade = "true"; // Dialog Fade In and Out -> true | Dialog Instant -> false
};