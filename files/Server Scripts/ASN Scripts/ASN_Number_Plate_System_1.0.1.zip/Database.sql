CREATE TABLE IF NOT EXISTS `vehicleplates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vid` int(11) NOT NULL DEFAULT 0,
  `pid` varchar(17) NOT NULL,
  `city` int(10) NOT NULL,
  `letter1` int(10) NOT NULL,
  `letter2` int(10) NOT NULL,
  `number1` int(10) NOT NULL,
  `number2` int(10) NOT NULL,
  `number3` int(10) NOT NULL,
  `red` int(10) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;