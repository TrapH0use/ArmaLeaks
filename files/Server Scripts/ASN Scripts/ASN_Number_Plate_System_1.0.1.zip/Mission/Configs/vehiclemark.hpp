class ASN_Vehiclemarksystem
{

	//Translations
	novehicle = "There is no vehicle in the near!";
	alreadyaplate = "This vehicle has already a vehicle plate!";
	notalive = "This vehicle is not alive!";
	notvalide = "This was not valide, we have corrected it for you, please check again!";
	notsofast = "Not so fast!";
	notaviable = "This plate number isn't aviable!";
	searchplate = "Please wait...searching for vehicle plate number...";
	nothingfound = "Could not find a vehicle with this plate number.";
	error = "Something went wrong...";
	computerclosed = "You closed the computer, search stopped!";
	searchfinish = "The search has been finished";

	//Country
	//Will be used to set on the vehicle plate number -> e.g https://i.imgur.com/HmXomrV.png
	//Aviable are: DE (Germany), GB (Great Britian), CZ (Czech Republic), FR (France), MEX (Mexico), I (Italy), E (Spain),  A (Altis), S (Stratis), T (Tanoa), M (Malden)
	country = "DE";

	//Here can you enter citynames and shortnames
	citys[] = {
		//Name to show in police computer and vehicle registration | how to show on plate
		{"City1", {"nothing", "C", "1"}},
		{"City2", {"nothing", "C", "2"}},
		{"City3", {"nothing", "C", "3"}}
	};

	//Positions of the vehicle plate number on the vehicle
	class C_Van_01_transport_F
	{
		position_front[] = {0, 2.1, -0.64};
		position_back[] = {0, -3.15, -1.08};
	};
};