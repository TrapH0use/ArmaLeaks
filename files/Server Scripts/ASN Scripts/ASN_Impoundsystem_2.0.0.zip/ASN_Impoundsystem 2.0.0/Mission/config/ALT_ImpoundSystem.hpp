/*
    File: ALT_ImpoundSystem.hpp
    Author: Arma Love Team (Armaservices.net)
    Description: Master config for ALT_ImpoundSystem.hpp
*/
#include "..\dialog\ALT_ImpoundMenu.hpp"
#define true 1
#define false 0

class ALT_ImpoundSystem_Config {
	version = 5; // version 3.x -> 3 | 4.0 - 4.3 -> 4 | version 4.4+ -> 5
	DialogFade = "true"; // Dialog Fade In and Out -> true | Dialog Instant -> false
	CashVariable = "life_cash"; // Cash Variable to give the player money after impound
	CashDivided = 2; // Amount divided off of cars original price
	NumOfTowTrucks = 2; // Number of tow truck drivers needed for normal impound to be replaced with tow truck drivers
};