
    class playerHUD {
    idd = 645343;
    duration = 10e10;
    movingEnable = 0;
    enableSimulation = 1;
    fadein = 0;
    fadeout = 0;
    name = "playerHUD"; 
    onLoad = "uiNamespace setVariable ['playerHUD',_this select 0]";
        class controls
        {
            class fondo: lobo_IGUIBack
            {
                idc = 2200;
                x = 0.01325 * safezoneW + safezoneX;
                y = 0.775 * safezoneH + safezoneY;
                w = 0.162937 * safezoneW;
                h = 0.2222 * safezoneH;
                colorBackground[] = {-1,-1,-1,0.8};
            };
            class bars: lobo_RscProgress {
                colorFrame[] = {0,0,0,1};
                y = 0.972223 * safezoneH + safezoneY;
                w = 0.0462964 * safezoneW;
                h = 0.0222222 * safezoneH;
            };

            class vidaprogressbar: bars
            {
                idc = 1100;
                style = 0x01;
                colorBar[] = {0,0.722,0.58,1};
                x = 0.0153125 * safezoneW + safezoneX;
                y = 0.9708 * safezoneH + safezoneY;
                w = 0.04125 * safezoneW;
                h = 0.0264 * safezoneH;
            };
            class comidaprogressbar: bars
            {
                idc = 1101;
                style = 0x01;
                colorBar[] = {0.992,0.796,0.431,1};
                x = 0.100906 * safezoneW + safezoneX;
                y = 0.9708 * safezoneH + safezoneY;
                w = 0.0226875 * safezoneW;
                h = 0.0264 * safezoneH;
            };
            class aguaprogressbar: bars
            {
                idc = 1102;
                style = 0x01;
                colorBar[] = {0.098,0.165,0.337,1};
                x = 0.125656 * safezoneW + safezoneX;
                y = 0.9708 * safezoneH + safezoneY;
                w = 0.0237188 * safezoneW;
                h = 0.0264 * safezoneH;
            };

            class staminaprogressbar: bars
            {
                idc = 1103;
                style = 0x01;
                colorBar[] = {0.424,0.361,0.906,1};
                x = 0.151437 * safezoneW + safezoneX;
                y = 0.9708 * safezoneH + safezoneY;
                w = 0.0226875 * safezoneW;
                h = 0.0264 * safezoneH;
            };

            class escudoprogressbar: bars
            {
                idc = 1104;
                style = 0x01;
                colorBar[] = {0.035,0.518,0.89,1};
                x = 0.0575937 * safezoneW + safezoneX;
                y = 0.9708 * safezoneH + safezoneY;
                w = 0.0412501 * safezoneW;
                h = 0.0264 * safezoneH;
            };

            class iconoescudo: lobo_RscPicture
            {
                idc = 1200;
                text = "Lobo\GTAHUD\images\escudo.paa";
                x = 0.0730627 * safezoneW + safezoneX;
                y = 0.973 * safezoneH + safezoneY;
                w = 0.0113434 * safezoneW;
                h = 0.0176 * safezoneH;
            };
            class iconovida: lobo_RscPicture
            {
                idc = 1201;
                text = "Lobo\GTAHUD\images\vida.paa";
                x = 0.0297497 * safezoneW + safezoneX;
                y = 0.9752 * safezoneH + safezoneY;
                w = 0.0103122 * safezoneW;
                h = 0.0154 * safezoneH;
            };
            class iconocomida: lobo_RscPicture
            {
                idc = 1202;
                text = "Lobo\GTAHUD\images\foo.paa";
                x = 0.107094 * safezoneW + safezoneX;
                y = 0.9752 * safezoneH + safezoneY;
                w = 0.0103122 * safezoneW;
                h = 0.0154 * safezoneH;
            };
            class iconoagua: lobo_RscPicture
            {
                idc = 1203;
                text = "Lobo\GTAHUD\images\aguaa.paa";
                x = 0.131844 * safezoneW + safezoneX;
                y = 0.9752 * safezoneH + safezoneY;
                w = 0.0103122 * safezoneW;
                h = 0.0154 * safezoneH;
            };
            class iconostamina: lobo_RscPicture
            {
                idc = 1204;
                text = "Lobo\GTAHUD\images\stamina.paa";
                x = 0.157625 * safezoneW + safezoneX;
                y = 0.973 * safezoneH + safezoneY;
                w = 0.0113435 * safezoneW;
                h = 0.0176 * safezoneH;
            };

            class dineroefectivo: lobo_RscStructuredText
            {
                idc = 98981;
                text = "Error Loading"; //--- ToDo: Localize;
                x = 0.923119 * safezoneW + safezoneX;
                y = 0.00500001 * safezoneH + safezoneY;
                w = 0.0876563 * safezoneW;
                h = 0.044 * safezoneH;
                class Attributes
                {
                    color = "#FFFFFF";
                    align = "center";
                    valign = "middle";
                    underline = false;
                };
            };
            class dineroretiradoefectivo: lobo_RscStructuredText
            {
                idc = 98982;
                text = "Error Loading"; //--- ToDo: Localize;
                x = 0.923119 * safezoneW + safezoneX;
                y = 0.0300 * safezoneH + safezoneY;
                w = 0.0876563 * safezoneW;
                h = 0.044 * safezoneH;
                class Attributes
                {
                    color = "#FFFFFF";
                    align = "center";
                    valign = "middle";
                    underline = false;
                };
            };
            class dinerobanco: lobo_RscStructuredText
            {
                idc = 98983;
                text = ""; //--- ToDo: Localize;
                x = 0.923119 * safezoneW + safezoneX;
                y = 0.0554 * safezoneH + safezoneY;
                w = 0.0876563 * safezoneW;
                h = 0.044 * safezoneH;
                class Attributes
                {
                    color = "#FFFFFF";
                    align = "center";
                    valign = "middle";
                    underline = false;
                };
            };
            class dinerobancoretirado: lobo_RscStructuredText
            {
                idc = 98984;
                text = ""; //--- ToDo: Localize;
                x = 0.923119 * safezoneW + safezoneX;
                y = 0.0800 * safezoneH + safezoneY;
                w = 0.0876563 * safezoneW;
                h = 0.044 * safezoneH;
                class Attributes
                {
                    color = "#FFFFFF";
                    align = "center";
                    valign = "middle";
                    underline = false;
                };
            };

            class minimap : lobo_RscMapControl
            {

                idc = 38555;
                type = 101;
                style = 48;
                moveOnEdges = 0;
                x = 0.0153125 * safezoneW + safezoneX;
                y = 0.7794 * safezoneH + safezoneY;
                w = 0.158812 * safezoneW;
                h = 0.187 * safezoneH;
                onDraw = "_this call fnc_updateMiniMap";
            };

        };
    };